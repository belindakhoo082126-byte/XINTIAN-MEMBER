/* 心田花園 · API 對接層
 * 集中配置 API_BASE 與登入方式，避免每個請求分別改地址。
 *
 * 【測試聯調】API_BASE = "/dev-api"      （需後台管理員認證）
 * 【正式上線】API_BASE = "/api"           （Telegram 身份驗證）
 */
const CONFIG = {
  // ↓↓↓ 上線時只改這一行 ↓↓↓
  API_BASE: "/dev-api",
  DEV_LOGIN: true,          // true=開發登入(會員編號)；false=Telegram initData
  LOGIN_TIMEOUT: 5000,
};

const API = {
  base: CONFIG.API_BASE,
  token: null,
  useReal: false,

  async login(code){
    const url = (CONFIG.DEV_LOGIN)
      ? this.base + "/member/auth/dev-login"
      : this.base + "/member/auth/telegram";
    try{
      const body = CONFIG.DEV_LOGIN
        ? JSON.stringify({member_code: code})
        : JSON.stringify({init_data: (window.Telegram&&window.Telegram.WebApp&&window.Telegram.WebApp.initData)||""});
      const r = await fetch(url, {
        method:"POST", credentials:"same-origin", headers:{"Content-Type":"application/json"},
        body: body, signal: AbortSignal.timeout(CONFIG.LOGIN_TIMEOUT)
      });
      if(!r.ok) throw new Error("login failed " + r.status);
      const d = await r.json();
      this.token = d.access_token;
      this.useReal = true;
      return {ok:true};
    }catch(e){
      this.useReal = false;
      return {ok:false, fallback:true, err: e.message};
    }
  },

  headers(){
    const h = {"Content-Type":"application/json"};
    if(CONFIG.DEV_LOGIN){
      h["X-Xintian-Member-Token"] = this.token;
    } else {
      h["Authorization"] = "Bearer " + this.token;
    }
    return h;
  },


  // 測試模擬任務（階段1）：寫入測試庫積分
  async mockTask(taskKey, reqId){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base + "/member/game/mock-task", {
        method:"POST", credentials:"same-origin",
        headers: Object.assign({"Content-Type":"application/json"}, this.headers ? this.headers() : {}),
        body: JSON.stringify({task_key: taskKey, request_id: reqId})
      });
      if(!r.ok) return null;
      return await r.json();
    }catch(e){ return null; }
  },


  async reloadMe(){
    if(!this.useReal) return null;
    return await this.me();
  },

  async me(){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/member/me",{credentials:"same-origin",headers:this.headers()});
      if(!r.ok) return null;
      return await r.json();
    }catch(e){ return null; }
  },

  async points(page=1, kind="all"){
    if(!this.useReal) return null;
    try{
      const r = await fetch(`${this.base}/member/points?page=${page}&kind=${kind}`,{credentials:"same-origin",headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async rebateBatches(page=1){
    if(!this.useReal) return null;
    try{
      const r = await fetch(`${this.base}/member/rebate-batches?page=${page}`,{credentials:"same-origin",headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async rewards(){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/member/rewards",{credentials:"same-origin",headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async gameState(){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/member/game",{credentials:"same-origin",headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async startPlant(key, reqId){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/member/game/start",{
        method:"POST", credentials:"same-origin", headers:this.headers(),
        body: JSON.stringify({plant_key:key, request_id:reqId})
      });
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async observe(plantId, checkType){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/member/game/observe",{
        method:"POST", credentials:"same-origin", headers:this.headers(),
        body: JSON.stringify({plant_id:plantId, check_type:checkType})
      });
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async redeem(rewardId, reqId, note){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/member/reward-requests",{
        method:"POST", credentials:"same-origin", headers:this.headers(),
        body: JSON.stringify({reward_id:rewardId, quantity:1, note:note||"", request_id:reqId})
      });
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  }
};

function uuid(){ return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,c=>{const r=Math.random()*16|0;return (c==="x"?r:(r&0x3|0x8)).toString(16);}); }
