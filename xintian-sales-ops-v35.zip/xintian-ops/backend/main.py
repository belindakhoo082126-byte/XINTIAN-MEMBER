#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""心田營運儀表板 — 後端 API"""
import os, json, sqlite3, io, csv, re
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Form, Body, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import sys as _sys, os as _os, importlib.util as _ilu
_here = _os.path.dirname(_os.path.abspath(__file__))
_spec = _ilu.spec_from_file_location("analyze", _os.path.join(_here, "analyze.py"))
analyze = _ilu.module_from_spec(_spec); _spec.loader.exec_module(analyze)

BASE = os.path.dirname(os.path.abspath(__file__))
DB   = os.path.join(BASE, "..", "data", "ops.db")
FRONT= os.path.join(BASE, "..", "frontend")

app = FastAPI(title="心田營運儀表板")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def db():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS uploads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT, period_start TEXT, period_end TEXT,
      created_at TEXT, summary TEXT, raw TEXT);
    CREATE TABLE IF NOT EXISTS orders (
      order_no TEXT, product TEXT, keyword TEXT, qty REAL,
      revenue REAL, cost REAL, profit REAL,
      date TEXT, month TEXT, status TEXT, state TEXT,
      shipping_method TEXT, shipping_fee REAL, post_url TEXT,
      first_seen TEXT, updated_at TEXT,
      PRIMARY KEY (order_no, product));
    CREATE TABLE IF NOT EXISTS ads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT, campaign TEXT, amount REAL,
      target_type TEXT,   -- product / keyword / live / brand
      target TEXT,        -- 商品名 / 關鍵字 / 空
      live_revenue REAL,
      note TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS shipping (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      month TEXT, amount REAL, provider TEXT, note TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vendor TEXT, amount REAL, arrival_date TEXT, pay_date TEXT,
      invoice TEXT, note TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS cost_map (
      product TEXT PRIMARY KEY, unit_cost REAL, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, date TEXT,
      amount REAL, note TEXT, sku TEXT, created_at TEXT);
    """)
    c.commit(); c.close()


def _norm_type(t):
    """統一廣告類型：中英/繁簡/簡寫 一律轉成 product/keyword/live/brand"""
    x = (t or "").strip().lower()
    m = {
        "product":"product","商品":"product","產品":"product","推广商品":"product","商品推廣":"product",
        "keyword":"keyword","品類":"keyword","品类":"keyword","關鍵字":"keyword","关键字":"keyword",
        "推广品类":"keyword","推廣品類":"keyword","推廣":"keyword",
        "live":"live","直播":"live","直播帶貨":"live","直播带貨":"live",
        "brand":"brand","品牌":"brand","門市":"brand","门店":"brand","無對應":"brand","无对应":"brand",
    }
    return m.get(x, x if x in ("product","keyword","live","brand") else (x or ""))


def _migrate():
    """自動補欄位（表結構變動時）"""
    c = db()
    fixes = [
        ("ads", "live_revenue", "REAL DEFAULT 0"),
        ("orders", "keyword", "TEXT"),
        ("orders", "first_seen", "TEXT"),
        ("orders", "updated_at", "TEXT"),
        ("shipping", "provider", "TEXT"),
        ("purchases", "pay_date", "TEXT"),
        ("purchases", "invoice", "TEXT"),
        ("purchases", "note", "TEXT"),
    ]
    for tbl, col, typ in fixes:
        try:
            cols = [r["name"] for r in c.execute("PRAGMA table_info(%s)" % tbl).fetchall()]
            if col not in cols:
                c.execute("ALTER TABLE %s ADD COLUMN %s %s" % (tbl, col, typ))
                print("[migrate] %s.%s added" % (tbl, col))
        except Exception:
            pass
    # 清理 ads.target_type 髒資料（中文 → 代碼）
    try:
        rows = c.execute("SELECT id,target_type FROM ads").fetchall()
        for r in rows:
            nt = _norm_type(r["target_type"])
            if nt != (r["target_type"] or ""):
                c.execute("UPDATE ads SET target_type=? WHERE id=?", (nt, r["id"]))
    except Exception:
        pass
    c.commit(); c.close()


init_db()
_migrate()

DEFAULT_SETTINGS = {
    "fixed_cost": "15350",
    "fixed_items": json.dumps([
        {"name":"租金","amount":2800},{"name":"Wifi","amount":300},
        {"name":"軟件","amount":500},{"name":"水電","amount":500},
        {"name":"薪資","amount":6000},{"name":"Ulive","amount":300},
        {"name":"包裝","amount":450},
    ], ensure_ascii=False),
}

@app.get("/api/settings")
def get_settings():
    c = db()
    out = {}
    for k, dv in DEFAULT_SETTINGS.items():
        row = c.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone()
        out[k] = row["value"] if row else dv
    c.close()
    out["fixed_items"] = json.loads(out.get("fixed_items") or "[]")
    return out

@app.post("/api/settings")
def save_settings(payload: dict = Body(...)):
    c = db()
    if "fixed_cost" in payload:
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_cost',?)", (str(payload["fixed_cost"]),))
    if "fixed_items" in payload:
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_items',?)",
                  (json.dumps(payload["fixed_items"], ensure_ascii=False),))
        total = sum(float(i.get("amount",0)) for i in payload["fixed_items"])
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_cost',?)", (str(total),))
    c.commit(); c.close()
    return {"ok": True}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    raw = (await file.read()).decode("utf-8-sig", errors="ignore")
    c = db()
    # 載入成本對照
    _rows = c.execute("SELECT product, unit_cost FROM cost_map").fetchall()
    cost_map = {r["product"]: r["unit_cost"] for r in _rows}

    # ★ 展開訂單明細 → 去重累積
    items = analyze.explode_orders(raw, cost_map)
    if not items:
        c.close()
        raise HTTPException(400, "無法解析 CSV")
    now = datetime.now().isoformat()
    before = c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    for it in items:
        c.execute("""INSERT OR REPLACE INTO orders
                     (order_no,product,keyword,qty,revenue,cost,profit,date,month,status,state,
                      shipping_method,shipping_fee,post_url,first_seen,updated_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT first_seen FROM orders WHERE order_no=? AND product=?),?),?)""",
                  (it["order_no"],it["product"],it.get("keyword",""),it["qty"],it["revenue"],it["cost"],it["profit"],
                   it["date"],it["month"],it["status"],it["state"],it["shipping_method"],
                   it["shipping_fee"],it["post_url"],it["order_no"],it["product"],now,now))
    c.commit()
    after = c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    added = after - before
    updated = len(items) - added

    # 記上傳記錄（不存 raw，省空間）
    dates = [it["date"] for it in items if it.get("date")]
    p_start, p_end = (min(dates) if dates else ""), (max(dates) if dates else "")
    c.execute("""INSERT INTO uploads (filename, period_start, period_end, created_at, summary, raw)
                 VALUES (?,?,?,?,?,?)""",
              (file.filename, p_start, p_end, now, "{}", ""))
    c.commit()

    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost)
    c.close()
    return {"ok": True, "summary": s, "period": [p_start, p_end],
            "added": added, "updated": updated}


def _summarize_buffer(c, fixed_cost=15350.0, month=None):
    """從 orders 表算彙總（可選月份）"""
    q = "SELECT * FROM orders"
    args = []
    if month:
        q += " WHERE month=?"; args = [month]
    rows = [dict(r) for r in c.execute(q, args).fetchall()]
    rev = sum(r["revenue"] or 0 for r in rows)
    cost = sum(r["cost"] or 0 for r in rows)
    prof = rev - cost
    rate = (prof / rev * 100) if rev else 0
    # ★ 廣告費（與損益表一致）
    if month:
        ads = c.execute("SELECT SUM(amount) a FROM ads WHERE substr(date,1,7)=?", (month,)).fetchone()["a"] or 0
        shp = c.execute("SELECT SUM(amount) a FROM shipping WHERE month=?", (month,)).fetchone()["a"] or 0
        ex = c.execute("SELECT kind, SUM(amount) a FROM expenses WHERE substr(date,1,7)=? GROUP BY kind", (month,)).fetchall()
    else:
        ads = c.execute("SELECT SUM(amount) a FROM ads").fetchone()["a"] or 0
        shp = c.execute("SELECT SUM(amount) a FROM shipping").fetchone()["a"] or 0
        ex = c.execute("SELECT kind, SUM(amount) a FROM expenses GROUP BY kind").fetchall()
    ex_map = {e["kind"]: e["a"] for e in ex}
    death = ex_map.get("plant_death",0)
    refund = ex_map.get("refund_issue",0) + ex_map.get("refund_overpay",0)
    extra_pur = ex_map.get("purchase",0)
    other = ex_map.get("other",0)
    # ★ 淨利 = 毛利 - 固定 - 廣告 - 運費 - 死亡 - 退款 - 額外採購 - 其他（與損益表一致）
    net = prof - fixed_cost - ads - shp - death - refund - extra_pur - other
    total_fixed = fixed_cost + ads + shp + death + refund + extra_pur + other
    be = (total_fixed / (rate/100)) if rate > 0 else 0

    from collections import defaultdict
    skus = defaultdict(lambda: {"qty":0,"revenue":0.0,"cost":0.0,"profit":0.0,"name":"","promo":False,"missing_cost":False})
    states = defaultdict(lambda: {"n":0,"rev":0.0})
    posts = defaultdict(lambda: {"n":0,"rev":0.0,"profit":0.0})
    free_ship = paid_ship = 0; ship_cust = 0; extra=0
    missing = set()
    # 已填成本的商品（含 0）→ 不算漏
    cm_set = set(x["product"] for x in c.execute("SELECT product FROM cost_map").fetchall())
    for r in rows:
        k = r["product"] or "(未知)"
        sk = skus[k]; sk["qty"] += r["qty"] or 0; sk["revenue"] += r["revenue"] or 0
        sk["cost"] += r["cost"] or 0; sk["profit"] += r["profit"] or 0; sk["name"] = k
        if re.search(r"特價|特价|促销|促銷|優惠|优惠|promo|sale", k, re.I): sk["promo"]=True
        if (r["cost"] or 0) <= 0 and (r["revenue"] or 0) > 0 \
           and k not in cm_set \
           and not re.search(r"GIFT|贈品|赠品|FREE", k, re.I):
            sk["missing_cost"] = True; missing.add(k)
        st = r["state"] or "(未填)"
        states[st]["n"] += 1; states[st]["rev"] += r["revenue"] or 0
        pu = r["post_url"] or "(無)"
        posts[pu]["n"] += 1; posts[pu]["rev"] += r["revenue"] or 0; posts[pu]["profit"] += r["profit"] or 0
        sf = r["shipping_fee"] or 0
        if sf > 0: paid_ship += 1; ship_cust += sf
        elif "自取" not in (r["shipping_method"] or "") and "SELF" not in (r["shipping_method"] or "").upper():
            free_ship += 1

    top = sorted(skus.items(), key=lambda kv: kv[1]["revenue"], reverse=True)
    return {
        "orders_n": len(set(r["order_no"] for r in rows)),
        "revenue": round(rev,2), "cost": round(cost,2),
        "gross_profit": round(prof,2), "gross_rate": round(rate,2),
        "fixed_cost": round(fixed_cost,2), "net_profit": round(net,2),
        "ads": round(ads,2), "shipping": round(shp,2), "total_fixed": round(total_fixed,2),
        "breakeven_revenue": round(be,2), "is_profit": net >= 0,
        "ship_to_customer": round(ship_cust,2), "extra_fee": round(extra,2),
        "free_ship_n": free_ship, "paid_ship_n": paid_ship,
        "missing_cost": sorted(missing),
        "by_state": dict(states),
        "top_skus": [{"sku":k, **v} for k,v in top],
        "by_post": dict(list(posts.items())[:20]),
    }



@app.get("/api/pnl")
def pnl(month: str = None):
    """完整損益表"""
    c = db()
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0

    # 營業額 / 商品成本
    if month:
        r = c.execute("SELECT SUM(revenue) rev, SUM(cost) cost FROM orders WHERE month=?", (month,)).fetchone()
    else:
        r = c.execute("SELECT SUM(revenue) rev, SUM(cost) cost FROM orders").fetchone()
    rev = r["rev"] or 0; cost = r["cost"] or 0
    gross = rev - cost

    # 廣告
    if month:
        ads = c.execute("SELECT SUM(amount) a FROM ads WHERE substr(date,1,7)=?", (month,)).fetchone()["a"] or 0
    else:
        ads = c.execute("SELECT SUM(amount) a FROM ads").fetchone()["a"] or 0

    # 運費月結
    if month:
        shp = c.execute("SELECT SUM(amount) a FROM shipping WHERE month=?", (month,)).fetchone()["a"] or 0
    else:
        shp = c.execute("SELECT SUM(amount) a FROM shipping").fetchone()["a"] or 0

    # 支出（死亡/退款/採購）
    if month:
        ex = c.execute("SELECT kind, SUM(amount) a FROM expenses WHERE substr(date,1,7)=? GROUP BY kind", (month,)).fetchall()
    else:
        ex = c.execute("SELECT kind, SUM(amount) a FROM expenses GROUP BY kind").fetchall()
    ex_map = {e["kind"]: e["a"] for e in ex}

    # 進貨
    if month:
        pur = c.execute("SELECT SUM(amount) a FROM purchases WHERE substr(arrival_date,1,7)=?", (month,)).fetchone()["a"] or 0
    else:
        pur = c.execute("SELECT SUM(amount) a FROM purchases").fetchone()["a"] or 0
    c.close()

    death = ex_map.get("plant_death",0)
    refund = ex_map.get("refund_issue",0) + ex_map.get("refund_overpay",0)
    extra_pur = ex_map.get("purchase",0)
    other = ex_map.get("other",0)

    net = gross - fcost - ads - shp - death - refund - extra_pur - other
    return {"ok": True, "month": month or "全部",
        "revenue": round(rev,2), "cost": round(cost,2),
        "gross": round(gross,2),
        "gross_rate": round((gross/rev*100) if rev else 0, 2),
        "fixed": round(fcost,2),
        "ads": round(ads,2),
        "shipping": round(shp,2),
        "death": round(death,2),
        "refund": round(refund,2),
        "extra_purchase": round(extra_pur,2),
        "other": round(other,2),
        "purchase": round(pur,2),
        "net": round(net,2),
        "is_profit": net >= 0}

@app.get("/api/months")
def months():
    c = db()
    rows = c.execute("SELECT DISTINCT month FROM orders WHERE month!='' ORDER BY month DESC").fetchall()
    c.close()
    return {"ok": True, "items": [r["month"] for r in rows]}


@app.get("/api/orders/summary")
def orders_summary(month: str = None):
    c = db()
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost, month)
    c.close()
    return {"ok": True, "summary": s, "month": month or "全部"}

@app.get("/api/latest")
def latest(month: str = None):
    c = db()
    cnt = c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    if not cnt:
        c.close(); return {"ok": True, "summary": None}
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost, month)
    up = c.execute("SELECT filename, created_at FROM uploads ORDER BY id DESC LIMIT 1").fetchone()
    c.close()
    return {"ok": True, "summary": s, "month": month or "全部",
            "filename": up["filename"] if up else "", "created_at": up["created_at"] if up else ""}

@app.get("/api/uploads")
def uploads_list():
    c = db()
    rows = c.execute("SELECT id,filename,period_start,period_end,created_at FROM uploads ORDER BY id DESC LIMIT 50").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}


# ── 商品成本對照（補填漏成本）──
@app.get("/api/costs")
def get_costs():
    c = db()
    rows = c.execute("SELECT product, unit_cost FROM cost_map").fetchall()
    c.close()
    return {"ok": True, "items": {r["product"]: r["unit_cost"] for r in rows}}

@app.post("/api/costs")
def save_costs(payload: dict = Body(...)):
    """payload: {"items": [{"product": "...", "unit_cost": 12.5}, ...]}"""
    c = db()
    for it in payload.get("items", []):
        prod = (it.get("product") or "").strip()
        if not prod: continue
        c.execute("""INSERT INTO cost_map (product, unit_cost, updated_at) VALUES (?,?,?)
                     ON CONFLICT(product) DO UPDATE SET unit_cost=excluded.unit_cost, updated_at=excluded.updated_at""",
                  (prod, float(it.get("unit_cost", 0)), datetime.now().isoformat()))
    c.commit()

    # ★ 用新成本重算 orders 表（把成本套到每一筆訂單）
    cm = {r["product"]: r["unit_cost"] for r in c.execute("SELECT product, unit_cost FROM cost_map").fetchall()}
    upd = 0
    for r in c.execute("SELECT order_no, product, qty, revenue FROM orders").fetchall():
        k = r["product"] or ""
        if k in cm:
            new_cost = float(cm[k]) * (r["qty"] or 0)
            new_profit = (r["revenue"] or 0) - new_cost
            c.execute("UPDATE orders SET cost=?, profit=? WHERE order_no=? AND product=?",
                      (new_cost, new_profit, r["order_no"], r["product"]))
            upd += 1
    c.commit()

    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s2 = _summarize_buffer(c, fcost)
    c.close()
    return {"ok": True, "n": len(payload.get("items", [])), "reanalyzed": True,
            "orders_updated": upd, "summary": s2}

@app.get("/api/missing-costs")
def missing_costs():
    c = db()
    if not c.execute("SELECT 1 FROM orders LIMIT 1").fetchone():
        c.close(); return {"ok": True, "items": []}
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost)
    c.close()
    return {"ok": True, "items": s.get("missing_cost", []),
            "skus": [{"name": t.get("name"), "sku": t.get("sku")} for t in s.get("top_skus", [])]}




# ── 運費月結 ──
@app.get("/api/shipping")
def list_shipping(month: str = None):
    c = db()
    if month:
        rows = c.execute("SELECT * FROM shipping WHERE month=? ORDER BY id DESC", (month,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM shipping ORDER BY id DESC").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.post("/api/shipping")
def add_shipping(payload: dict = Body(...)):
    c = db()
    c.execute("INSERT INTO shipping (month,amount,provider,note,created_at) VALUES (?,?,?,?,?)",
              (payload.get("month",""), float(payload.get("amount",0)),
               payload.get("provider",""), payload.get("note",""), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}

@app.put("/api/shipping/{sid}")
def edit_shipping(sid: int, payload: dict = Body(...)):
    c = db()
    c.execute("UPDATE shipping SET month=?,amount=?,provider=?,note=? WHERE id=?",
              (payload.get("month",""), float(payload.get("amount",0) or 0),
               payload.get("provider",""), payload.get("note",""), sid))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/shipping/{sid}")
def del_shipping(sid: int):
    c = db(); c.execute("DELETE FROM shipping WHERE id=?", (sid,)); c.commit(); c.close()
    return {"ok": True}

@app.post("/api/shipping/parse-pdf")
async def parse_shipping_pdf(file: UploadFile = File(...)):
    """解析 AXVEL/ParcelDaily 月結單 → 取 Grand Total"""
    try:
        from pypdf import PdfReader
        import io as _io
        data = await file.read()
        r = PdfReader(_io.BytesIO(data))
        txt = "\n".join((p.extract_text() or "") for p in r.pages)
    except Exception as e:
        raise HTTPException(400, "PDF 解析失敗：" + str(e))
    total = None
    period = ""
    for l in txt.split("\n"):
        m = re.search(r"Grand\s*Total\s*[:：]\s*([\d,]+\.\d+)\s*([\d,]+\.\d+)", l)
        if m:
            # 第 2 個數字 = 郵寄費用總數
            total = float(m.group(2).replace(",","")); break
    m2 = re.search(r"STATEMENT PERIOD\s*[:：]\s*(.+)", txt)
    if m2: period = m2.group(1).strip()
    # 從「01 NOVEMBER - 30 NOVEMBER」抓月份 → 2026-11（用 statement date 的年份）
    month = ""
    MON = {"JAN":"01","FEB":"02","MAR":"03","APR":"04","MAY":"05","JUN":"06",
           "JUL":"07","AUG":"08","SEP":"09","OCT":"10","NOV":"11","DEC":"12"}
    mm = re.search(r"\d{1,2}\s+([A-Z]{3})", period.upper())
    ym = re.search(r"STATEMENT DATE\s*[:：]\s*\d{2}/\d{2}/(\d{4})", txt)
    if mm and ym:
        month = ym.group(1) + "-" + MON.get(mm.group(1), "")
    return {"ok": True, "total": total, "period": period, "month": month,
            "raw_text": txt[:1500]}

# ── 進貨記錄（總額）──
@app.get("/api/purchases")
def list_purchases(month: str = None):
    c = db()
    if month:
        rows = c.execute("SELECT * FROM purchases WHERE substr(arrival_date,1,7)=? ORDER BY id DESC", (month,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM purchases ORDER BY id DESC").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.post("/api/purchases")
def add_purchase(payload: dict = Body(...)):
    c = db()
    c.execute("""INSERT INTO purchases (vendor,amount,arrival_date,pay_date,invoice,note,created_at)
                 VALUES (?,?,?,?,?,?,?)""",
              (payload.get("vendor",""), float(payload.get("amount",0)),
               payload.get("arrival_date",""), payload.get("pay_date",""),
               payload.get("invoice",""), payload.get("note",""), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}


@app.put("/api/purchases/{pid}")
def edit_purchase(pid: int, payload: dict = Body(...)):
    c = db()
    c.execute("""UPDATE purchases SET vendor=?,amount=?,arrival_date=?,pay_date=?,invoice=?,note=?
                 WHERE id=?""",
              (payload.get("vendor",""), float(payload.get("amount",0)),
               payload.get("arrival_date",""), payload.get("pay_date",""),
               payload.get("invoice",""), payload.get("note",""), pid))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/purchases/{pid}")
def del_purchase(pid: int):
    c = db(); c.execute("DELETE FROM purchases WHERE id=?", (pid,)); c.commit(); c.close()
    return {"ok": True}

@app.get("/api/purchases/summary")
def purchases_summary(month: str = None):
    c = db()
    if month:
        prows = c.execute("SELECT * FROM purchases WHERE substr(arrival_date,1,7)=?", (month,)).fetchall()
        srows = c.execute("SELECT SUM(cost) c, SUM(revenue) r FROM orders WHERE month=?", (month,)).fetchone()
    else:
        prows = c.execute("SELECT * FROM purchases").fetchall()
        srows = c.execute("SELECT SUM(cost) c, SUM(revenue) r FROM orders").fetchone()
    c.close()
    total_in = sum(r["amount"] or 0 for r in prows)
    unpaid = sum(r["amount"] or 0 for r in prows if not (r["pay_date"] or "").strip())
    sell_cost = srows["c"] or 0
    return {"ok": True, "total_purchase": round(total_in,2), "unpaid": round(unpaid,2),
            "sell_cost": round(sell_cost,2), "stock_change": round(total_in - sell_cost,2),
            "n": len(prows)}

# ── 廣告記錄 + ROAS ──
@app.get("/api/ads")
def list_ads(month: str = None):
    c = db()
    if month:
        rows = c.execute("SELECT * FROM ads WHERE substr(date,1,7)=? ORDER BY id DESC", (month,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM ads ORDER BY id DESC").fetchall()
    rows2 = c.execute("""SELECT product name, keyword, SUM(revenue) revenue FROM orders
                         GROUP BY product, keyword""").fetchall()
    skus = [{"name": r["name"], "keyword": r["keyword"], "revenue": r["revenue"]} for r in rows2]
    c.close()
    items = []
    for r in rows:
        d = dict(r)
        d["revenue"] = _ads_revenue(d, skus)
        d["roas"] = round(d["revenue"] / d["amount"], 2) if d["amount"] else 0
        items.append(d)
    return {"ok": True, "items": items}


# 簡繁對照（常用）
_TC2SC = str.maketrans({
    "黃":"黄","薑":"姜","藥":"药","蟲":"虫","爛":"烂","葉":"叶","種":"种","養":"养",
    "開":"开","發":"发","紅":"红","綠":"绿","藍":"蓝","開":"开","這":"这","個":"个",
    "與":"与","為":"为","會":"会","來":"来","時":"时","後":"后","點":"点","選":"选",
    "業":"业","專":"专","價":"价","賣":"卖","買":"买","貨":"货","實":"实","單":"单",
    "總":"总","額":"额","數":"数","據":"据","訂":"订","費":"费","運":"运","遞":"递",
    "長":"长","門":"门","體":"体","關":"关","係":"系","備":"备","註":"注","盤":"盘",
    "栽": "栽", "種":"种",
})

def _norm(txt):
    """正規化：去空白 + 全形轉半形 + 繁轉簡 + 小寫"""
    t = (txt or "").strip().lower()
    t = re.sub(r"\s+", "", t)
    # 全形→半形
    out = []
    for ch in t:
        o = ord(ch)
        if 0xFF01 <= o <= 0xFF5E:
            out.append(chr(o - 0xFEE0))
        else:
            out.append(ch)
    t = "".join(out)
    return t.translate(_TC2SC)

def _ads_revenue(ad, skus):
    """依廣告類型算對應業績"""
    t, tg = _norm_type(ad.get("target_type")), (ad.get("target") or "").strip()
    if t == "brand":
        return 0.0
    if t == "live":
        return float(ad.get("live_revenue") or 0)
    if not tg:
        return 0.0
    ntg = _norm(tg)
    if not ntg:
        return 0.0
    # product / keyword：都「智慧包含」（去空格+繁簡+全形）
    # ★ 同時比對「商品名」與 CSV 的「Product Keyword」欄
    return sum(sk.get("revenue", 0.0) for sk in skus
               if ntg in _norm(sk.get("name")) or ntg in _norm(sk.get("keyword")))

@app.post("/api/ads")
def add_ad(payload: dict = Body(...)):
    c = db()
    c.execute("""INSERT INTO ads (date,campaign,amount,target_type,target,live_revenue,note,created_at)
                 VALUES (?,?,?,?,?,?,?,?)""",
              (payload.get("date",""), payload.get("campaign",""),
               float(payload.get("amount",0)), _norm_type(payload.get("target_type")),
               payload.get("target",""), float(payload.get("live_revenue",0) or 0),
               payload.get("note",""), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}


@app.post("/api/ads/bulk")
def add_ads_bulk(payload: dict = Body(...)):
    """payload: {"items": [{campaign, amount, date, target_type, target, live_revenue, note}]}"""
    c = db()
    n = 0
    for it in payload.get("items", []):
        c.execute("""INSERT INTO ads (date,campaign,amount,target_type,target,live_revenue,note,created_at)
                     VALUES (?,?,?,?,?,?,?,?)""",
                  (it.get("date",""), it.get("campaign",""),
                   float(it.get("amount",0)), _norm_type(it.get("target_type")),
                   it.get("target",""), float(it.get("live_revenue",0) or 0),
                   it.get("note",""), datetime.now().isoformat()))
        n += 1
    c.commit(); c.close()
    return {"ok": True, "n": n}


@app.post("/api/ads/merge")
def merge_ads(payload: dict = Body(...)):
    """合併兩筆廣告（例：同一場直播斷線）"""
    id1 = payload.get("id1"); id2 = payload.get("id2")
    rev = float(payload.get("live_revenue",0) or 0)
    camp = payload.get("campaign","")
    c = db()
    r1 = c.execute("SELECT * FROM ads WHERE id=?", (id1,)).fetchone()
    r2 = c.execute("SELECT * FROM ads WHERE id=?", (id2,)).fetchone()
    if not r1 or not r2:
        c.close(); return {"ok": False, "error": "找不到"}
    total = (r1["amount"] or 0) + (r2["amount"] or 0)
    c.execute("UPDATE ads SET amount=?, campaign=?, target_type=?, live_revenue=?, note=? WHERE id=?",
              (total, camp or (r1["campaign"]+" + "+r2["campaign"]), "live", rev,
               (r1["note"] or "")+" 合併", id1))
    c.execute("DELETE FROM ads WHERE id=?", (id2,))
    c.commit(); c.close()
    return {"ok": True}


@app.put("/api/ads/{aid}")
def edit_ad(aid: int, payload: dict = Body(...)):
    c = db()
    c.execute("""UPDATE ads SET date=?,campaign=?,amount=?,target_type=?,target=?,live_revenue=?,note=?
                 WHERE id=?""",
              (payload.get("date",""), payload.get("campaign",""),
               float(payload.get("amount",0)), _norm_type(payload.get("target_type")),
               payload.get("target",""), float(payload.get("live_revenue",0) or 0),
               payload.get("note",""), aid))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/ads/{aid}")
def del_ad(aid: int):
    c = db(); c.execute("DELETE FROM ads WHERE id=?", (aid,)); c.commit(); c.close()
    return {"ok": True}

@app.post("/api/ads/parse-pdf")
async def parse_ad_pdf(file: UploadFile = File(...)):
    """解析 Meta 廣告 PDF → 列出廣告系列 + 金額"""
    try:
        from pypdf import PdfReader
        import io as _io
        data = await file.read()
        r = PdfReader(_io.BytesIO(data))
        txt = "\n".join((p.extract_text() or "") for p in r.pages)
    except Exception as e:
        raise HTTPException(400, "PDF 解析失敗：" + str(e))
    # ★ 存檔（供診斷）
    try:
        import os as _os
        updir = _os.path.join(BASE, "..", "data", "uploads")
        _os.makedirs(updir, exist_ok=True)
        with open(_os.path.join(updir, "last_ad.pdf"), "wb") as f:
            f.write(data)
        with open(_os.path.join(updir, "last_ad.txt"), "w", encoding="utf-8") as f:
            f.write(txt)
    except Exception:
        pass
    lines = [l.strip() for l in txt.split("\n") if l.strip()]
    # 解析：以「展示次[数數]」切段 → 往前取名、往後取 MYR 金額
    flat = re.sub(r"\s+", " ", txt)
    segs = re.split(r"展示次[数數]", flat)
    names = []
    for seg in segs[:-1]:
        m = re.search(r"([A-Za-z0-9\u4e00-\u9fff#\"：:/\-]+(?:\s+[A-Za-z0-9\u4e00-\u9fff#\"：:/\-]+)*?)\s+[\d,]+\s*$", seg)
        if m:
            nm = m.group(1).strip()
            nm = re.sub(r"^[\d,]+\.?\d*\s*", "", nm)  # 去殘留數字
            names.append(nm)
    amts = re.findall(r"展示次[数數]\s*MYR\s*([\d,]+\.\d+)", flat)
    items = []
    for n, a in zip(names, amts):
        try: amt = float(a.replace(",",""))
        except: amt = 0
        if n and amt > 0:
            items.append({"campaign": n, "amount": amt, "date": ""})
    # SST（稅）→ 自動多一筆
    msst = re.search(r"SST\s*[:：]\s*(\d+[\d,]*\.\d+)\s*MYR", flat)
    if msst:
        sst = float(msst.group(1).replace(",",""))
        if sst > 0:
            items.append({"campaign": "廣告費 SST", "amount": sst, "date": "", "target_type": "brand"})
    # 年月 → date = 2026-11
    ym = ""
    mym = re.search(r"(\d{4})年(\d{1,2})月", flat)
    if mym:
        ym = "%s-%02d" % (mym.group(1), int(mym.group(2)))
    for it in items:
        it["date"] = ym

    return {"ok": True, "items": items, "raw_lines": len(lines),
            "raw_text": txt[:2000]}


@app.get("/api/ads/last-text")
def ads_last_text():
    import os as _os
    fp = _os.path.join(BASE, "..", "data", "uploads", "last_ad.txt")
    if not _os.path.exists(fp):
        return {"ok": True, "text": ""}
    with open(fp, encoding="utf-8") as f:
        return {"ok": True, "text": f.read()[:3000]}

@app.get("/api/ads/products")
def ads_products():
    """回傳商品清單（從 orders 表，全部）"""
    c = db()
    rows = c.execute("""SELECT product name, SUM(revenue) revenue FROM orders
                        GROUP BY product ORDER BY revenue DESC""").fetchall()
    c.close()
    return {"ok": True, "items": [{"name": r["name"], "revenue": r["revenue"]} for r in rows]}

# ── 支出（植物死亡 / 退款 / 額外採購）──
@app.get("/api/expenses")
def expenses(kind: str = None, month: str = None):
    c = db()
    if kind and month:
        rows = c.execute("SELECT * FROM expenses WHERE kind=? AND substr(date,1,7)=? ORDER BY id DESC", (kind,month)).fetchall()
    elif kind:
        rows = c.execute("SELECT * FROM expenses WHERE kind=? ORDER BY id DESC", (kind,)).fetchall()
    elif month:
        rows = c.execute("SELECT * FROM expenses WHERE substr(date,1,7)=? ORDER BY id DESC", (month,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 200").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.post("/api/expenses")
def add_expense(payload: dict = Body(...)):
    c = db()
    c.execute("""INSERT INTO expenses (kind,date,amount,note,sku,created_at)
                 VALUES (?,?,?,?,?,?)""",
              (payload.get("kind","other"), payload.get("date",""),
               float(payload.get("amount",0)), payload.get("note",""),
               payload.get("sku",""), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/expenses/{eid}")
def del_expense(eid: int):
    c = db(); c.execute("DELETE FROM expenses WHERE id=?", (eid,)); c.commit(); c.close()
    return {"ok": True}

@app.get("/api/expenses/summary")
def expenses_summary():
    c = db()
    rows = c.execute("SELECT kind, SUM(amount) amt, COUNT(*) n FROM expenses GROUP BY kind").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.get("/health")
def health(): return {"ok": True, "service": "xintian-ops"}

# 前端靜態檔
if os.path.isdir(FRONT):
    app.mount("/", StaticFiles(directory=FRONT, html=True), name="front")
