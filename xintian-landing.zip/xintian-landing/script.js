document.getElementById('year').textContent = new Date().getFullYear();

const io = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (!e.isIntersecting) return;
    e.target.animate(
      [{ opacity: 0, transform: 'translateY(26px)' }, { opacity: 1, transform: 'none' }],
      { duration: 640, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'both' }
    );
    io.unobserve(e.target);
  });
}, { threshold: 0.1 });

document.querySelectorAll('.card, .stat, .step, .split__text, .split__media').forEach((el) => {
  el.style.opacity = '0';
  io.observe(el);
});

window.addEventListener('DOMContentLoaded', () => {
  const inner = document.querySelector('.hero__inner');
  if (inner) inner.animate(
    [{ opacity: 0, transform: 'translateY(30px)' }, { opacity: 1, transform: 'none' }],
    { duration: 900, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'both' }
  );
});
