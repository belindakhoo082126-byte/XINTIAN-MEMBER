#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""訂單 CSV 分析引擎"""
import csv, io, re
from collections import defaultdict
from datetime import datetime

def _f(v, default=0.0):
    try:
        return float(str(v).replace(",", "").strip() or 0)
    except Exception:
        return default

def is_promo(name):
    """商品名含『特價/特价/促销/優惠/Promo』視為特價"""
    return bool(re.search(r"特價|特价|促销|促銷|優惠|优惠|promo|sale", str(name), re.I))

STATE_MAP = {
    "johor":"Johor", "selangor":"Selangor", "selangor darul ehsan":"Selangor",
    "negeri sembilan":"Negeri Sembilan", "perak":"Perak", "melaka":"Melaka",
    "pahang":"Pahang", "penang":"Penang", "pulau pinang":"Penang",
    "kuala lumpur":"Kuala Lumpur", "kl":"Kuala Lumpur", "sabah":"Sabah",
    "sarawak":"Sarawak", "kedah":"Kedah", "kelantan":"Kelantan",
    "terengganu":"Terengganu", "perlis":"Perlis", "putrajaya":"Putrajaya",
}

def norm_state(v):
    """州屬標準化：。統一大寫/空白"""
    v = (v or "").strip()
    if not v or v == "-":
        return "(未填)"
    key = v.lower().strip().replace("  ", " ")
    return STATE_MAP.get(key, v.strip().title())


def parse_csv(text, cost_map=None):
    """解析 ECO_Orders CSV → dict。cost_map: {商品名: 單位成本} 用於補漏成本"""
    rows = list(csv.reader(io.StringIO(text)))
    if not rows: return None
    hdr = rows[0]
    idx = {h.strip(): i for i, h in enumerate(hdr)}

    def g(row, key, default=""):
        i = idx.get(key)
        return row[i] if (i is not None and i < len(row)) else default

    orders = {}   # order_no -> dict
    skus = defaultdict(lambda: {"qty":0,"revenue":0.0,"cost":0.0,"profit":0.0,"name":"","promo":False,"missing_cost":False})
    no_cost = set()

    for r in rows[1:]:
        if not r or not r[0]: continue
        if r[0].strip().lower().startswith("total"): continue
        ono = g(r,"Order Number").strip()
        if not ono: continue

        qty  = _f(g(r,"Product Qty"))
        price= _f(g(r,"Product Unit Price"))
        cost = _f(g(r,"Product Unit Cost"))
        pname0 = g(r,"Product Name").strip()
        # 若 CSV 沒成本 → 用 cost_map 補
        if cost <= 0 and cost_map:
            cm = cost_map.get(pname0) or cost_map.get(g(r,"Product SKU").strip())
            if cm: cost = _f(cm)
        tprice=_f(g(r,"Product Total Price"))
        tcost= _f(g(r,"Product Total Cost"))
        tprof= _f(g(r,"Product Total Profit"))
        # 若有補成本 → 重算
        if cost > 0 and tcost <= 0 and qty > 0:
            tcost = cost * qty
            tprof = tprice - tcost
        sku  = g(r,"Product SKU").strip() or g(r,"Product Name").strip() or "(未知商品)"
        pname= g(r,"Product Name").strip()
        ship = _f(g(r,"Shipping Fee"))
        extra= _f(g(r,"Extra Fee"))
        disc = _f(g(r,"Discount"))
        promo= _f(g(r,"Promo Total"))
        pnt  = _f(g(r,"Point Discount"))
        state= norm_state(g(r,"State"))
        smeth= g(r,"Shipping Method").strip()
        status=g(r,"Status").strip()
        date = g(r,"Purchase Date").strip()
        post = g(r,"Post URL").strip()

        o = orders.setdefault(ono, {
            "order_no": ono, "date": date, "state": state, "shipping": smeth,
            "status": status, "post_url": post,
            "revenue":0.0,"cost":0.0,"profit":0.0,"qty":0,"items":[],
            "shipping_fee":0.0,"extra_fee":0.0,"discount":0.0,
        })
        o["revenue"] += tprice; o["cost"] += tcost; o["profit"] += tprof
        o["qty"] += qty
        o["shipping_fee"] += ship; o["extra_fee"] += extra
        o["discount"] += disc + promo + pnt
        o["items"].append({"sku":sku,"name":pname,"qty":qty,"price":price,"cost":cost})

        s = skus[sku]; s["qty"] += qty; s["revenue"] += tprice
        s["cost"] += tcost; s["profit"] += tprof
        s["name"] = pname or s["name"]
        if is_promo(pname) or is_promo(sku): s["promo"] = True
        if cost <= 0 and qty > 0 and tprice > 0 and not re.search(r"GIFT|贈品|赠品|FREE", pname, re.I):
            s["missing_cost"] = True
            no_cost.add(sku)

    return {"orders": list(orders.values()), "skus": dict(skus), "missing_cost": sorted(no_cost)}

def summarize(parsed, fixed_cost=15350.0):
    """彙總 → 損益"""
    orders = parsed["orders"]
    rev = sum(o["revenue"] for o in orders)
    cost= sum(o["cost"] for o in orders)
    prof= sum(o["profit"] for o in orders)
    ship_to_customer = sum(o["shipping_fee"] for o in orders)
    extra = sum(o["extra_fee"] for o in orders)
    disc  = sum(o["discount"] for o in orders)

    gross_amt = rev - cost
    gross_rate = (gross_amt / rev * 100) if rev else 0
    net = gross_amt - fixed_cost
    breakeven = (fixed_cost / (gross_rate/100)) if gross_rate > 0 else 0

    # 免運（我承擔）：運送方式非自取 且 shipping_fee<=0
    free_ship_orders = [o for o in orders if o["shipping_fee"] <= 0 and "自取" not in o["shipping"] and "SELF" not in o["shipping"].upper()]
    paid_ship_orders = [o for o in orders if o["shipping_fee"] > 0]

    # 依州
    by_state = defaultdict(lambda: {"n":0,"rev":0.0})
    for o in orders:
        st = o["state"] or "(未知)"
        by_state[st]["n"] += 1; by_state[st]["rev"] += o["revenue"]

    # 依商品（按業績排序）
    top_skus = sorted(parsed["skus"].items(), key=lambda kv: kv[1]["revenue"], reverse=True)

    # 依 Post URL（content 效果）
    by_post = defaultdict(lambda: {"n":0,"rev":0.0,"profit":0.0})
    for o in orders:
        p = o["post_url"] or "(無)"
        by_post[p]["n"] += 1; by_post[p]["rev"] += o["revenue"]; by_post[p]["profit"] += o["profit"]

    return {
        "orders_n": len(orders),
        "revenue": round(rev,2),
        "cost": round(cost,2),
        "gross_profit": round(gross_amt,2),
        "gross_rate": round(gross_rate,2),
        "fixed_cost": round(fixed_cost,2),
        "net_profit": round(net,2),
        "breakeven_revenue": round(breakeven,2),
        "is_profit": net >= 0,
        "ship_to_customer": round(ship_to_customer,2),
        "extra_fee": round(extra,2),
        "discount": round(disc,2),
        "free_ship_n": len(free_ship_orders),
        "paid_ship_n": len(paid_ship_orders),
        "missing_cost": parsed["missing_cost"],
        "by_state": dict(by_state),
        "top_skus": [{"sku":k, **v} for k,v in top_skus[:20]],
        "by_post": {k:v for k,v in list(by_post.items())[:20]},
    }
