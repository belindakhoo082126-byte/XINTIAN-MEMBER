/* 心田花園 · 肥料 / 位置 / 知識卡 資料 */

// ===== 肥料清單 =====
const FERTILIZERS = {
  "16G":     {name:"Ferti 16G 富贵花肥", note:"专为富贵花、沙漠玫瑰、多肉设计，促开花花色艳丽"},
  "23":      {name:"Ferti 23 玫瑰专用肥", note:"玫瑰专用，含鱼骨肥与镁，促根壮苗、催花促果"},
  "42G":     {name:"Ferti 42G 蔬果肥",   note:"蔬菜辣椒专用，膨果增产、提升品质"},
  "53":      {name:"Ferti 53 开花肥",     note:"高磷促花配方，促花芽分化、花量更多"},
  "FE17":    {name:"Ferti FE17 绿又亮",   note:"观叶植物专用，叶色更鲜艳、叶片更大"},
  "FE170":   {name:"FE170 荷花睡莲肥",    note:"水生植物专用，促开花根壮叶绿，养鱼可用"},
  "ECO21":   {name:"Eco21 果肥",         note:"有机果肥，果实更甜更大、提高坐果率"},
  "SOYA":    {name:"有机黄豆肥",          note:"微量元素肥，适合多年生与树类，根壮叶绿"},
  "FRASS":   {name:"虫沙肥",              note:"天然有机，改善土壤有益菌、促花促根"},
  "WORM":    {name:"蚯蚓肥",              note:"富含有机质与微生物，养根壮根、育苗扦插"},
  "WOOD":    {name:"木醋液",              note:"辅助用，配合主肥使用，改善土壤环境"},
  "ORCHID":  {name:"泰国兰花肥",          note:"兰花专用，水状/颗粒，促根促花"},
};

// ===== 每種植物的施肥選項（B=正確，A/C=干擾）=====
const FERT_QUIZ = {
  p01: {A:"53", B:["16G"], C:"ECO21", tip:"多肉/富贵花类用 Ferti 16G，促开花且不烧根。"},
  p02: {A:"53", B:["16G","WOOD","SOYA"], C:"ECO21", tip:"沙漠玫瑰用 Ferti 16G，可搭配木醋液与黄豆肥。真实养护时这些需 2 星期轮流使用，次序可自行安排，不可一次全用，避免烧根。"},
  p03: {A:"42G", B:["53","SOYA"], C:"16G", tip:"薰衣草用 Ferti 53 配黄豆肥。真实养护时 2 星期交替使用，不可一次全用。"},
  p04: {A:"ECO21", B:["FE17"], C:"16G", tip:"红财神属观叶，用 FE17 绿又亮，叶色更鲜艳。"},
  p05: {A:"ECO21", B:["53","FRASS"], C:"42G", tip:"大岩桐用 Ferti 53 配虫沙肥。2 星期交替使用。"},
  p06: {A:"ECO21", B:["53","FRASS"], C:"16G", tip:"百万小铃用 Ferti 53 配虫沙肥。2 星期交替使用。"},
  p07: {A:"42G", B:["23","WOOD"], C:"ECO21", tip:"英式月季用 Ferti 23 玫瑰肥配木醋液。真实养护时 2 星期轮流使用。"},
  p08: {A:"53", B:["FE170"], C:"42G", tip:"睡莲荷花用 FE170 荷花睡莲肥，养鱼也可用，每 2 星期一次。"},
  p09: {A:"53", B:["ORCHID"], C:"42G", tip:"万代兰用泰国水状兰花肥，稀薄喷施。"},
  p10: {A:"53", B:["ORCHID"], C:"ECO21", tip:"蝴蝶兰用泰国颗粒兰花肥，薄肥勤施。"},
  p11: {A:"16G", B:["ORCHID"], C:"53", tip:"地生兰用泰国颗粒兰花肥，见干见湿。"},
  p12: {A:"53", B:["WORM"], C:"42G", tip:"鹿角蕨用蚯蚓肥，稀薄少量。"},
  p13: {A:"53", B:["ECO21","SOYA","WOOD"], C:"42G", tip:"柠檬等果树用 Eco21 果肥配黄豆肥、木醋液。真实养护时 3 款需 2 星期轮流使用，次序可自行安排，不可一次使用所有肥料，避免烧根。"},
  p14: {A:"53", B:["ECO21","SOYA","WOOD"], C:"16G", tip:"青葡萄用 Eco21 果肥配黄豆肥、木醋液。2 星期交替使用，不可一次全用。"},
  p15: {A:"53", B:["ECO21","SOYA","WOOD"], C:"16G", tip:"草莓用 Eco21 果肥配黄豆肥、木醋液。2 星期交替使用。"},
  p16: {A:"53", B:["42G"], C:"ECO21", tip:"辣椒用 Ferti 42G 蔬果肥，膨果增产。"},
  p17: {A:"53", B:["42G"], C:"16G", tip:"小白菜等叶菜用 Ferti 42G 蔬果肥。"},
};

// ===== 位置（光照+通風）=====
const LOCATIONS = {
  outdoor: {name:"户外（全日照）", light:"全日照", air:"通风好"},
  balcony: {name:"阳台（半日照）", light:"半日照", air:"通风中等"},
  indoor:  {name:"室内（散射光）", light:"散射光", air:"通风差"},
};

// 每種植物適合的位置
const PLANT_LOCATION = {
  p01:"outdoor", p02:"outdoor", p03:"outdoor", p04:"indoor", p05:"indoor",
  p06:"balcony", p07:"outdoor", p08:"outdoor", p09:"balcony", p10:"indoor",
  p11:"balcony", p12:"indoor", p13:"outdoor", p14:"outdoor", p15:"balcony",
  p16:"outdoor", p17:"balcony",
};

// ===== 害蟲處理選項（依植物 + 害蟲判斷對錯）=====
// soapOK: 該植物適不適合用肥皂水
const PLANT_SOAP_OK = {
  p01:false, p02:false, p03:true, p04:true, p05:true, p06:true, p07:true,
  p08:false, p09:false, p10:false, p11:false, p12:false, p13:true,
  p14:true, p15:true, p16:true, p17:true,
};
// 每種害蟲的處理選項（正確 method 對應 PLANT_SOAP_OK）
const PEST_TREAT = {
  aphid:    {name:"蚜虫",   correct:["allinone","soap"], wrong:["water_flush","indoor"], hint:"蚜虫可用 All in One 药水，或用肥皂水喷洒（叶面光滑的植物适用）。"},
  scale:    {name:"介壳虫", correct:["allinone","wipe"], wrong:["water_flush","fertilize"], hint:"介壳虫有硬壳，要擦拭 + All in One，严重时隔离。"},
  spider:   {name:"红蜘蛛", correct:["allinone","moisture"], wrong:["dry","fertilize"], hint:"红蜘蛛喜欢干燥闷热，要提高湿度 + 清洗叶背。"},
  whitefly: {name:"粉虱",   correct:["allinone","yellowboard"], wrong:["water_flush","indoor"], hint:"粉虱可用黄板 + All in One 药水。"},
  mealybug: {name:"粉蚧",   correct:["allinone","wipe"], wrong:["fertilize","water_flush"], hint:"粉蚧像白色棉絮，要擦拭 + 隔离，别加肥。"},
  snail:    {name:"蜗牛",   correct:["snailbait","handpick"], wrong:["water","fertilize"], hint:"蜗牛用蜗牛药或手抓，别浇水（会更活跃）。"},
};
// 處理方法名稱
const TREAT_METHODS = {
  allinone:{name:"使用 All in One 药水"},
  soap:{name:"用肥皂水喷洒"},
  wipe:{name:"擦拭 + 隔离"},
  moisture:{name:"提高湿度 + 清洗叶背"},
  yellowboard:{name:"黄板 + All in One"},
  snailbait:{name:"使用蜗牛药"},
  handpick:{name:"手动抓除"},
  water_flush:{name:"大量浇水冲走"},
  indoor:{name:"移到阴暗室内"},
  dry:{name:"让环境更干燥"},
  fertilize:{name:"追加肥料"},
  water:{name:"浇更多水"},
};
