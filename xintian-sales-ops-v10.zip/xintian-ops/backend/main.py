#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""心田營運儀表板 — 後端 API"""
import os, json, sqlite3, io, csv, re
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Form, Body, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import sys as _sys, os as _os, importlib.util as _ilu
_here = _os.path.dirname(_os.path.abspath(__file__))
_spec = _ilu.spec_from_file_location("analyze", _os.path.join(_here, "analyze.py"))
analyze = _ilu.module_from_spec(_spec); _spec.loader.exec_module(analyze)

BASE = os.path.dirname(os.path.abspath(__file__))
DB   = os.path.join(BASE, "..", "data", "ops.db")
FRONT= os.path.join(BASE, "..", "frontend")

app = FastAPI(title="心田營運儀表板")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def db():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS uploads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT, period_start TEXT, period_end TEXT,
      created_at TEXT, summary TEXT, raw TEXT);
    CREATE TABLE IF NOT EXISTS orders (
      order_no TEXT, product TEXT, qty REAL,
      revenue REAL, cost REAL, profit REAL,
      date TEXT, month TEXT, status TEXT, state TEXT,
      shipping_method TEXT, shipping_fee REAL, post_url TEXT,
      first_seen TEXT, updated_at TEXT,
      PRIMARY KEY (order_no, product));
    CREATE TABLE IF NOT EXISTS ads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT, campaign TEXT, amount REAL,
      target_type TEXT,   -- product / keyword / brand
      target TEXT,        -- 商品名 / 關鍵字 / 空
      note TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS cost_map (
      product TEXT PRIMARY KEY, unit_cost REAL, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, date TEXT,
      amount REAL, note TEXT, sku TEXT, created_at TEXT);
    """)
    c.commit(); c.close()

init_db()

DEFAULT_SETTINGS = {
    "fixed_cost": "15350",
    "fixed_items": json.dumps([
        {"name":"租金","amount":2800},{"name":"Wifi","amount":300},
        {"name":"軟件","amount":500},{"name":"水電","amount":500},
        {"name":"薪資","amount":6000},{"name":"Ulive","amount":300},
        {"name":"承擔免郵運費","amount":1500},{"name":"廣告費","amount":3000},
        {"name":"包裝","amount":450},
    ], ensure_ascii=False),
}

@app.get("/api/settings")
def get_settings():
    c = db()
    out = {}
    for k, dv in DEFAULT_SETTINGS.items():
        row = c.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone()
        out[k] = row["value"] if row else dv
    c.close()
    out["fixed_items"] = json.loads(out.get("fixed_items") or "[]")
    return out

@app.post("/api/settings")
def save_settings(payload: dict = Body(...)):
    c = db()
    if "fixed_cost" in payload:
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_cost',?)", (str(payload["fixed_cost"]),))
    if "fixed_items" in payload:
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_items',?)",
                  (json.dumps(payload["fixed_items"], ensure_ascii=False),))
        total = sum(float(i.get("amount",0)) for i in payload["fixed_items"])
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_cost',?)", (str(total),))
    c.commit(); c.close()
    return {"ok": True}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    raw = (await file.read()).decode("utf-8-sig", errors="ignore")
    c = db()
    # 載入成本對照
    _rows = c.execute("SELECT product, unit_cost FROM cost_map").fetchall()
    cost_map = {r["product"]: r["unit_cost"] for r in _rows}

    # ★ 展開訂單明細 → 去重累積
    items = analyze.explode_orders(raw, cost_map)
    if not items:
        c.close()
        raise HTTPException(400, "無法解析 CSV")
    now = datetime.now().isoformat()
    before = c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    for it in items:
        c.execute("""INSERT OR REPLACE INTO orders
                     (order_no,product,qty,revenue,cost,profit,date,month,status,state,
                      shipping_method,shipping_fee,post_url,first_seen,updated_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT first_seen FROM orders WHERE order_no=? AND product=?),?),?)""",
                  (it["order_no"],it["product"],it["qty"],it["revenue"],it["cost"],it["profit"],
                   it["date"],it["month"],it["status"],it["state"],it["shipping_method"],
                   it["shipping_fee"],it["post_url"],it["order_no"],it["product"],now,now))
    c.commit()
    after = c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    added = after - before
    updated = len(items) - added

    # 記上傳記錄（不存 raw，省空間）
    dates = [it["date"] for it in items if it.get("date")]
    p_start, p_end = (min(dates) if dates else ""), (max(dates) if dates else "")
    c.execute("""INSERT INTO uploads (filename, period_start, period_end, created_at, summary, raw)
                 VALUES (?,?,?,?,?,?)""",
              (file.filename, p_start, p_end, now, "{}", ""))
    c.commit()

    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost)
    c.close()
    return {"ok": True, "summary": s, "period": [p_start, p_end],
            "added": added, "updated": updated}


def _summarize_buffer(c, fixed_cost=15350.0, month=None):
    """從 orders 表算彙總（可選月份）"""
    q = "SELECT * FROM orders"
    args = []
    if month:
        q += " WHERE month=?"; args = [month]
    rows = [dict(r) for r in c.execute(q, args).fetchall()]
    rev = sum(r["revenue"] or 0 for r in rows)
    cost = sum(r["cost"] or 0 for r in rows)
    prof = rev - cost
    rate = (prof / rev * 100) if rev else 0
    net = prof - fixed_cost
    be = (fixed_cost / (rate/100)) if rate > 0 else 0

    from collections import defaultdict
    skus = defaultdict(lambda: {"qty":0,"revenue":0.0,"cost":0.0,"profit":0.0,"name":"","promo":False,"missing_cost":False})
    states = defaultdict(lambda: {"n":0,"rev":0.0})
    posts = defaultdict(lambda: {"n":0,"rev":0.0,"profit":0.0})
    free_ship = paid_ship = 0; ship_cust = 0; extra=0
    missing = set()
    # 已填成本的商品（含 0）→ 不算漏
    cm_set = set(x["product"] for x in c.execute("SELECT product FROM cost_map").fetchall())
    for r in rows:
        k = r["product"] or "(未知)"
        sk = skus[k]; sk["qty"] += r["qty"] or 0; sk["revenue"] += r["revenue"] or 0
        sk["cost"] += r["cost"] or 0; sk["profit"] += r["profit"] or 0; sk["name"] = k
        if re.search(r"特價|特价|促销|促銷|優惠|优惠|promo|sale", k, re.I): sk["promo"]=True
        if (r["cost"] or 0) <= 0 and (r["revenue"] or 0) > 0 \
           and k not in cm_set \
           and not re.search(r"GIFT|贈品|赠品|FREE", k, re.I):
            sk["missing_cost"] = True; missing.add(k)
        st = r["state"] or "(未填)"
        states[st]["n"] += 1; states[st]["rev"] += r["revenue"] or 0
        pu = r["post_url"] or "(無)"
        posts[pu]["n"] += 1; posts[pu]["rev"] += r["revenue"] or 0; posts[pu]["profit"] += r["profit"] or 0
        sf = r["shipping_fee"] or 0
        if sf > 0: paid_ship += 1; ship_cust += sf
        elif "自取" not in (r["shipping_method"] or "") and "SELF" not in (r["shipping_method"] or "").upper():
            free_ship += 1

    top = sorted(skus.items(), key=lambda kv: kv[1]["revenue"], reverse=True)
    return {
        "orders_n": len(set(r["order_no"] for r in rows)),
        "revenue": round(rev,2), "cost": round(cost,2),
        "gross_profit": round(prof,2), "gross_rate": round(rate,2),
        "fixed_cost": round(fixed_cost,2), "net_profit": round(net,2),
        "breakeven_revenue": round(be,2), "is_profit": net >= 0,
        "ship_to_customer": round(ship_cust,2), "extra_fee": round(extra,2),
        "free_ship_n": free_ship, "paid_ship_n": paid_ship,
        "missing_cost": sorted(missing),
        "by_state": dict(states),
        "top_skus": [{"sku":k, **v} for k,v in top],
        "by_post": dict(list(posts.items())[:20]),
    }


@app.get("/api/months")
def months():
    c = db()
    rows = c.execute("SELECT DISTINCT month FROM orders WHERE month!='' ORDER BY month DESC").fetchall()
    c.close()
    return {"ok": True, "items": [r["month"] for r in rows]}


@app.get("/api/orders/summary")
def orders_summary(month: str = None):
    c = db()
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost, month)
    c.close()
    return {"ok": True, "summary": s, "month": month or "全部"}

@app.get("/api/latest")
def latest(month: str = None):
    c = db()
    cnt = c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    if not cnt:
        c.close(); return {"ok": True, "summary": None}
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost, month)
    up = c.execute("SELECT filename, created_at FROM uploads ORDER BY id DESC LIMIT 1").fetchone()
    c.close()
    return {"ok": True, "summary": s, "month": month or "全部",
            "filename": up["filename"] if up else "", "created_at": up["created_at"] if up else ""}

@app.get("/api/uploads")
def uploads_list():
    c = db()
    rows = c.execute("SELECT id,filename,period_start,period_end,created_at FROM uploads ORDER BY id DESC LIMIT 50").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}


# ── 商品成本對照（補填漏成本）──
@app.get("/api/costs")
def get_costs():
    c = db()
    rows = c.execute("SELECT product, unit_cost FROM cost_map").fetchall()
    c.close()
    return {"ok": True, "items": {r["product"]: r["unit_cost"] for r in rows}}

@app.post("/api/costs")
def save_costs(payload: dict = Body(...)):
    """payload: {"items": [{"product": "...", "unit_cost": 12.5}, ...]}"""
    c = db()
    for it in payload.get("items", []):
        prod = (it.get("product") or "").strip()
        if not prod: continue
        c.execute("""INSERT INTO cost_map (product, unit_cost, updated_at) VALUES (?,?,?)
                     ON CONFLICT(product) DO UPDATE SET unit_cost=excluded.unit_cost, updated_at=excluded.updated_at""",
                  (prod, float(it.get("unit_cost", 0)), datetime.now().isoformat()))
    c.commit()

    # ★ 用新成本重算 orders 表（把成本套到每一筆訂單）
    cm = {r["product"]: r["unit_cost"] for r in c.execute("SELECT product, unit_cost FROM cost_map").fetchall()}
    upd = 0
    for r in c.execute("SELECT order_no, product, qty, revenue FROM orders").fetchall():
        k = r["product"] or ""
        if k in cm:
            new_cost = float(cm[k]) * (r["qty"] or 0)
            new_profit = (r["revenue"] or 0) - new_cost
            c.execute("UPDATE orders SET cost=?, profit=? WHERE order_no=? AND product=?",
                      (new_cost, new_profit, r["order_no"], r["product"]))
            upd += 1
    c.commit()

    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s2 = _summarize_buffer(c, fcost)
    c.close()
    return {"ok": True, "n": len(payload.get("items", [])), "reanalyzed": True,
            "orders_updated": upd, "summary": s2}

@app.get("/api/missing-costs")
def missing_costs():
    c = db()
    if not c.execute("SELECT 1 FROM orders LIMIT 1").fetchone():
        c.close(); return {"ok": True, "items": []}
    fixed = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fcost = float(fixed["value"]) if fixed else 15350.0
    s = _summarize_buffer(c, fcost)
    c.close()
    return {"ok": True, "items": s.get("missing_cost", []),
            "skus": [{"name": t.get("name"), "sku": t.get("sku")} for t in s.get("top_skus", [])]}


# ── 廣告記錄 + ROAS ──
@app.get("/api/ads")
def list_ads():
    c = db()
    rows = c.execute("SELECT * FROM ads ORDER BY id DESC").fetchall()
    rows2 = c.execute("""SELECT product name, SUM(revenue) revenue FROM orders
                         GROUP BY product""").fetchall()
    skus = [{"name": r["name"], "revenue": r["revenue"]} for r in rows2]
    c.close()
    items = []
    for r in rows:
        d = dict(r)
        d["revenue"] = _ads_revenue(d, skus)
        d["roas"] = round(d["revenue"] / d["amount"], 2) if d["amount"] else 0
        items.append(d)
    return {"ok": True, "items": items}

def _ads_revenue(ad, skus):
    """依廣告類型算對應業績"""
    t, tg = ad.get("target_type"), (ad.get("target") or "").strip()
    if t == "brand" or not tg:
        return 0.0
    if t == "product":
        for sk in skus:
            if sk.get("name") == tg: return sk.get("revenue", 0.0)
    if t == "keyword":
        return sum(sk.get("revenue", 0.0) for sk in skus if tg.lower() in (sk.get("name") or "").lower())
    return 0.0

@app.post("/api/ads")
def add_ad(payload: dict = Body(...)):
    c = db()
    c.execute("""INSERT INTO ads (date,campaign,amount,target_type,target,note,created_at)
                 VALUES (?,?,?,?,?,?,?)""",
              (payload.get("date",""), payload.get("campaign",""),
               float(payload.get("amount",0)), payload.get("target_type",""),
               payload.get("target",""), payload.get("note",""),
               datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/ads/{aid}")
def del_ad(aid: int):
    c = db(); c.execute("DELETE FROM ads WHERE id=?", (aid,)); c.commit(); c.close()
    return {"ok": True}

@app.get("/api/ads/products")
def ads_products():
    """回傳商品清單（從 orders 表，全部）"""
    c = db()
    rows = c.execute("""SELECT product name, SUM(revenue) revenue FROM orders
                        GROUP BY product ORDER BY revenue DESC""").fetchall()
    c.close()
    return {"ok": True, "items": [{"name": r["name"], "revenue": r["revenue"]} for r in rows]}

# ── 支出（植物死亡 / 退款 / 額外採購）──
@app.get("/api/expenses")
def expenses(kind: str = None):
    c = db()
    if kind:
        rows = c.execute("SELECT * FROM expenses WHERE kind=? ORDER BY id DESC", (kind,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 200").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.post("/api/expenses")
def add_expense(payload: dict = Body(...)):
    c = db()
    c.execute("""INSERT INTO expenses (kind,date,amount,note,sku,created_at)
                 VALUES (?,?,?,?,?,?)""",
              (payload.get("kind","other"), payload.get("date",""),
               float(payload.get("amount",0)), payload.get("note",""),
               payload.get("sku",""), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/expenses/{eid}")
def del_expense(eid: int):
    c = db(); c.execute("DELETE FROM expenses WHERE id=?", (eid,)); c.commit(); c.close()
    return {"ok": True}

@app.get("/api/expenses/summary")
def expenses_summary():
    c = db()
    rows = c.execute("SELECT kind, SUM(amount) amt, COUNT(*) n FROM expenses GROUP BY kind").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.get("/health")
def health(): return {"ok": True, "service": "xintian-ops"}

# 前端靜態檔
if os.path.isdir(FRONT):
    app.mount("/", StaticFiles(directory=FRONT, html=True), name="front")
