#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
心田花友 Bot · XintianGardenBot
功能：欢迎、查积分、查回馈金、游戏入口、签到、活动上报
部署：放主機 /opt/xintian/bot/ 用 systemd 或 process 運行
"""
import os
import json
import logging
from datetime import datetime, timezone, timedelta

import httpx
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("xintian-bot")


# ===== 讀取環境設定檔 =====
def load_env_file(path):
    """從 /etc/xintian-bot.env 讀取 KEY=VALUE"""
    if not os.path.exists(path):
        return
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

load_env_file("/etc/xintian-bot.env")
load_env_file(os.path.join(os.path.dirname(__file__), ".env"))

# ===== 設定（從環境變數讀）=====
BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
BOT_KEY = os.environ.get("XINTIAN_BOT_API_KEY", "") or os.environ.get("XINTIAN_BOT_KEY", "")
API_BASE = os.environ.get("XINTIAN_API_BASE", "https://member.xintian.com.my")
GAME_URL = os.environ.get("XINTIAN_GAME_URL", "https://member.xintian.com.my/game-stage2/")
MEMBER_GROUP_ID = os.environ.get("XINTIAN_MEMBER_GROUP", "")   # 會員群 chat id
MALAYSIA_TZ = timezone(timedelta(hours=8))


def now_my():
    return datetime.now(MALAYSIA_TZ)


# ===== 系統 API =====
async def api_get(path, params=None):
    if not BOT_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(API_BASE + path, params=params,
                            headers={"X-Xintian-Bot-Key": BOT_KEY})
            return r.json() if r.status_code == 200 else None
    except Exception as e:
        log.warning("api_get %s: %s", path, e)
        return None


async def api_post(path, body):
    if not BOT_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.post(API_BASE + path, json=body,
                             headers={"X-Xintian-Bot-Key": BOT_KEY})
            return r.json() if r.status_code == 200 else None
    except Exception as e:
        log.warning("api_post %s: %s", path, e)
        return None



# ===== 遊戲 FAQ =====
GAME_FAQ = {
  "怎么玩": "🌱 心田花园怎么玩\n\n1. 点「进入心田花园」种一株植物\n2. 每天回来照顾它（浇水/施肥/除虫/检查）\n3. 植物会慢慢长大，完成后解锁更多品种\n4. 照顾和答题都能拿积分，积分可兑换礼物 🌸\n\n有不懂的随时问我～",
  "怎么种": "🌱 点「进入心田花园」→ 选一株植物 → 就种下了。\n新手可以先种：石莲花、小白菜、薰衣草，都比较简单 🌿",
  "怎么积分": "⭐ 积分怎么拿\n\n• 每天签到 +5\n• 群互动 +2\n• 答对植物问答 +5\n• 游戏里照顾植物 +1\n• 分享植物照片 +10\n• 推荐新花友 +20\n\n每天上限 25 分，积分永久累积不归零 🌸",
  "怎么兑换": "🎁 积分满 300 就能兑换：\n随机小植物盲盒 400 / RM10 voucher 500 /\n香草多肉 600 / 自制肥料 700 /\n植物数字学解读 900 / 高值植物 2000\n\n在花园里点「兑换」提交申请，我们会审核 🌿",
  "怎么浇水": "💧 浇水看植物需不需要：\n水分低于 80% 才能浇，一天一次。\n多肉不用天天浇，叶菜要常保湿哦 🌿",
  "怎么施肥": "🌾 施肥要选对肥料！\n每种植物需要的肥料不同，\n进入花园点「施肥」→ 选正确的肥料组合 🌸\n（真实养护时肥料要 2 星期轮流使用）",
  "生病": "🐛 植物生病了？\n先点「检查」看状态报告，\n如果是因为位置不对（光照/通风），用「移位」调整。\n有害虫就点「除虫」，选正确的处理方式 🌿",
  "枯萎": "🥀 植物打蔫了？\n通常是缺水或缺养分，先点「检查」看看。\n放心，游戏里的植物不会死，只会打蔫，照顾回来就好 🌸",
}

def match_faq(text):
    for k, v in GAME_FAQ.items():
        if k in text:
            return v
    return None

# ===== /start 歡迎 =====
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    name = update.effective_user.first_name or "花友"
    text = (
        f"🌱 *心田花友俱乐部*\n"
        f"每天都有人陪你一起养植物 ♡\n\n"
        f"你好，{name}！我是心田精灵管家 🌿\n\n"
        f"你可以：\n"
        f"• 点下方按钮 *进入心田花园* 种植物\n"
        f"• 输入 *积分* 查看你的积分\n"
        f"• 在群里发早安/打卡，就算签到 🌿\n"
        f"• 输入 *绑定* 绑定你的会员（电话）\n\n"
        f"有任何植物问题，随时问我 🌸"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🌱 进入心田花园（种植物 / 赚积分）", web_app=WebAppInfo(url=GAME_URL))],
        [InlineKeyboardButton("⭐ 查看我的积分", callback_data="check_points")],
        [InlineKeyboardButton("🔗 绑定会员", callback_data="bind")],
    ])
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


# ===== 查积分 =====
async def cmd_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid = str(update.effective_user.id)
    data = await api_get("/api/bot/member", {"tg_user_id": tid})
    if not data or not data.get("member"):
        await update.message.reply_text(
            "我还不知道你是谁呢～\n先输入 *绑定*，或用你的会员电话绑定一下 🌿",
            parse_mode="Markdown")
        return
    m = data["member"]
    text = (
        f"🌿 *{m.get('name','花友')}* 的账户\n"
        f"─────────────\n"
        f"⭐ 总积分：{m.get('points_total',0)}\n"
        f"🔒 待审核：{m.get('points_pending',0)}\n"
        f"✅ 可用积分：{m.get('points_available',0)}\n"
        f"💰 回馈金：RM{float(m.get('rebate_available',0)):.2f}\n"
        f"─────────────\n"
        f"想兑换礼物？进入花园看看吧 🌸"
    )
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("🌱 进入心田花园", web_app=WebAppInfo(url=GAME_URL))
    ]])
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


# ===== 签到 =====
async def do_checkin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid = str(update.effective_user.id)
    today = now_my().strftime("%Y-%m-%d")
    body = {
        "event_id": f"bot-checkin-{tid}-{today.replace('-','')}",
        "tg_user_id": tid,
        "task_key": "checkin",
        "proof_id": f"checkin:{tid}:{today}",
        "occurred_at": now_my().isoformat(),
        "verified": True,
        "verification_ref": f"telegram:{update.effective_message.message_id}",
        "progress": {}
    }
    res = await api_post("/api/bot/activities", body)
    if res and res.get("ok"):
        pts = res.get("points", 0)
        total = res.get("points_total", "")
        rep = "（今天已签到）" if res.get("repeated") else ""
        msg = f"✅ 签到成功 +{pts} 分 {rep}"
        if total != "":
            msg += f"\n目前共 {total} 分 🌿"
    else:
        msg = "签到需要先绑定会员哦～\n请用 *绑定* 完成绑定 🌿"
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(msg, parse_mode="Markdown")
    else:
        await update.message.reply_text(msg, parse_mode="Markdown")


# ===== 訊息處理 =====
async def on_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    # 只處理私聊（群訊息交給 on_group_message）
    if update.effective_chat and update.effective_chat.type != "private":
        return
    text = (update.message.text or "").strip()
    if any(k in text for k in ["积分", "積分", "points"]):
        await cmd_points(update, ctx)
    elif any(k in text for k in ["签到", "簽到", "打卡", "checkin"]):
        await update.message.reply_text(
            "✅ 签到是在 *会员群* 里进行的哦～\n\n"
            "每天早上我会在群里提醒，\n"
            "你在群里发「早安」「打卡」或「签到」就完成签到了 🌿",
            parse_mode="Markdown")
    elif any(k in text for k in ["绑定", "綁定", "bind"]):
        await update.message.reply_text(
            "请发送你的会员电话（例如 0122542466），我帮你绑定 🌿")
    elif any(k in text for k in ["游戏", "遊戲", "花园", "花園", "game"]):
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🌱 进入心田花园", web_app=WebAppInfo(url=GAME_URL))
        ]])
        await update.message.reply_text("点下方按钮进入你的花园 🌸", reply_markup=kb)
    elif text.lower() in ["hi", "hello", "你好", "早安", "嗨"]:
        await cmd_start(update, ctx)
    else:
        # 遊戲 FAQ
        faqans = match_faq(text)
        if faqans:
            await update.message.reply_text(faqans, parse_mode="Markdown")
            return
        # 植物問題 → 先回覆引導（AI 回答待接）
        await update.message.reply_text(
            "🌿 收到你的问题！\n如果我能答会直接告诉你；\n"
            "太复杂的话，我会转给心田老师回你 🌸")



# ===== 群訊息處理（簽到 + 互動）=====
async def on_group_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.text:
        return
    text = msg.text.strip()
    uid = str(msg.from_user.id)
    name = msg.from_user.first_name or "花友"
    today = now_my().strftime("%Y-%m-%d")

    # 簽到：早安 / 打卡 / 签到
    if any(k in text for k in ["早安", "打卡", "签到", "簽到", "good morning", "morning"]):
        body = {
            "event_id": f"group-checkin-{uid}-{today.replace('-','')}",
            "tg_user_id": uid,
            "task_key": "checkin",
            "proof_id": f"checkin:{uid}:{today}",
            "occurred_at": now_my().isoformat(),
            "verified": True,
            "verification_ref": f"telegram:{msg.message_id}",
            "progress": {}
        }
        res = await api_post("/api/bot/activities", body)
        if res and res.get("ok") and not res.get("repeated"):
            pts = res.get("points", 0)
            try:
                await msg.reply_text(f"✅ {name} 早安打卡成功 +{pts} 分 🌿")
            except Exception:
                pass
    elif len(text) >= 4:
        # 群互動 +2（不回應，只記錄）
        body = {
            "event_id": f"group-interact-{uid}-{msg.message_id}",
            "tg_user_id": uid,
            "task_key": "interaction",
            "proof_id": f"interaction:{uid}:{msg.message_id}",
            "occurred_at": now_my().isoformat(),
            "verified": True,
            "verification_ref": f"telegram:{msg.message_id}",
            "progress": {}
        }
        await api_post("/api/bot/activities", body)


# ===== 每日早安（定時 08:30 馬來西亞時間）=====
GROUP_CHAT_ID = os.environ.get("XINTIAN_GROUP_ID", "")

async def daily_morning(context: ContextTypes.DEFAULT_TYPE):
    """每天早上群發早安 + 提醒簽到"""
    if not GROUP_CHAT_ID:
        return
    try:
        await context.bot.send_message(
            chat_id=GROUP_CHAT_ID,
            text="🌱 早安，花友们！\n\n新的一天，你的植物也在等你 🌿\n\n"
                 "记得在群里发「早安」或「打卡」签到，+5 积分哦～\n"
                 "今天也一起把绿意带回家 🌸")
    except Exception as e:
        log.warning("morning post failed: %s", e)

# ===== callback =====
async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if q.data == "check_points":
        await q.answer()
        await cmd_points(update, ctx)
    elif q.data == "checkin":
        await do_checkin(update, ctx)
    elif q.data == "bind":
        await q.answer()
        await q.edit_message_text("请发送你的会员电话（例如 0122542466），我帮你绑定 🌿")


# ===== 新成員歡迎 =====
async def on_new_member(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    for m in update.message.new_chat_members:
        if m.is_bot:
            continue
        name = m.first_name or "花友"
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🌱 进入心田花园", web_app=WebAppInfo(url=GAME_URL))
        ]])
        await update.message.reply_text(
            f"🎉 欢迎 {name} 加入心田大家庭！\n\n"
            f"请点下方按钮进入花园，完成注册后就能开始种植物、赚积分 🌿\n\n"
            f"有任何植物问题都可以随时找我 🌸",
            reply_markup=kb)


def main():
    if not BOT_TOKEN:
        print("缺少 TG_BOT_TOKEN"); return
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("points", cmd_points))
    app.add_handler(CommandHandler("checkin", do_checkin))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, on_new_member))
    app.add_handler(MessageHandler(filters.ChatType.GROUPS & filters.TEXT & ~filters.COMMAND, on_group_message))
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND, on_message))
    app.add_handler(CommandHandler("help", cmd_start))
    from telegram.ext import CallbackQueryHandler
    app.add_handler(CallbackQueryHandler(on_callback))
    # 每日早安（08:30 馬來西亞 = 00:30 UTC）
    if GROUP_CHAT_ID and app.job_queue:
        import datetime as _dt
        app.job_queue.run_daily(daily_morning, time=_dt.time(hour=0, minute=30))
        log.info("每日早安已排程 08:30 (MYT)，群: %s", GROUP_CHAT_ID)
    log.info("心田 Bot 啟動中… @XintianGardenBot")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
