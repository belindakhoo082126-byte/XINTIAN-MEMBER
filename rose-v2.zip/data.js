/**
 * 心田月季目錄 — 資料檔
 * 新增品種：在對應分類的 varieties 陣列裡加一筆。
 * 新增分類：複製一個 category 物件，改 id / label / en / desc。
 *
 * 欄位：
 *   name  英文品種名（必填）
 *   zh    中文名（可空字串）
 *   color 花色描述（必填）
 *   hex   花色色碼（必填，例 #E88498）
 *   form  花型與大小
 *   notes 香氣、抗病、特性
 *   flag  特殊提醒（例：名稱待核對）
 */

window.XINTIAN_ROSES = {
  updated: "2026-11-04",
  categories: [
    {
      id: "climbing",
      label: "藤本月季",
      en: "Climbing Roses",
      desc: "枝條長、可牵引上架，適合拱門、圍籬與牆面。",
      varieties: [
        { name: "James Galway", zh: "詹姆斯·高威", color: "淺粉，中心深粉", hex: "#F2BCCB", form: "重瓣蓮座 · 中花", notes: "藤本 · 幾乎無刺 · 香味濃" },
        { name: "Jerry Jenning", zh: "（疑為 James Galway）", color: "淺粉，中心深粉", hex: "#F2BCCB", form: "重瓣蓮座 · 中花", notes: "名稱待核對", flag: "待核對" },
        { name: "Sally Holmes", zh: "莎莉·霍姆斯", color: "白，花蕊金黃", hex: "#FCFAF3", form: "單瓣 · 大花", notes: "成串開 · 非常強健 · 幾乎不生病" },
        { name: "Kew Gardens", img: "images/kew-gardens.jpg", zh: "邱園", color: "純白，花蕊黃", hex: "#FBF8F0", form: "單瓣 · 小中花", notes: "花量極多 · 抗病強" },
        { name: "Evelyn", zh: "伊芙琳", color: "杏桃／蜜桃橙", hex: "#F0A87E", form: "重瓣杯型 · 大花", notes: "果香濃郁" },
        { name: "Charles Darwin", zh: "查理斯·達爾文", color: "蜜黃轉奶油黃", hex: "#EFD48A", form: "重瓣 · 大花", notes: "濃香 · 巨型花" },
        { name: "Abraham Darby", zh: "亞伯拉罕·達比", color: "杏桃粉漸層", hex: "#E89A7C", form: "重瓣杯型 · 大花", notes: "濃果香 · 經典品種" },
        { name: "Constance", zh: "康斯坦絲", color: "粉紅，內瓣較深", hex: "#E88AA0", form: "重瓣球型 · 中花", notes: "濃香 · 英系" },
        { name: "Soeur Emmanuelle", zh: "艾曼紐修女", color: "粉紅，瓣背偏白", hex: "#F0A6B6", form: "重瓣 · 中花", notes: "強香 · 德系" },
        { name: "Marie Antoinette", zh: "瑪麗·安東妮", color: "粉白，外瓣淡綠白", hex: "#F6E3DE", form: "重瓣杯型 · 大花", notes: "法系 · 香氣濃" },
        { name: "Moulin de la Galette", zh: "煎餅磨坊", color: "粉橙／珊瑚橙", hex: "#EE9C77", form: "重瓣 · 中花", notes: "香氣濃 · 法系" },
        { name: "Heaven on Earth", zh: "天堂", color: "淺杏／奶油白", hex: "#F4E2C8", form: "重瓣 · 中花", notes: "香氣淡雅" },
        { name: "Kordes Jubilee", zh: "科德斯禧年", color: "杏黃／橙黃", hex: "#EFA95E", form: "重瓣 · 大花", notes: "德系 · 強香" },
        { name: "Augusta Louise", zh: "奧古斯塔·路易絲", color: "杏色轉奶油", hex: "#F2C08A", form: "重瓣 · 大花", notes: "強香 · 德系" },
        { name: "Romantic Tutu", zh: "浪漫芭蕾舞裙", color: "淺粉，邊緣偏白", hex: "#F5C6D2", form: "重瓣球狀 · 中等", notes: "強香 · 瓣數多" },
        { name: "Charles de Nervaux", img: "images/charles-de-nervaux.jpg", zh: "查爾斯·德·內爾沃", color: "乳白帶檸檬白", hex: "#F3EDD6", form: "半重瓣波浪瓣 · 中花", notes: "強香 · 耐熱 · 可當小藤本" }
      ]
    },
    {
      id: "shrub",
      label: "灌木月季",
      en: "Shrub & English Roses",
      desc: "株型飽滿，適合花圃中央與盆栽，多數香味濃郁。",
      varieties: [
        { name: "Kate", img: "images/kate.jpg", zh: "凱特", color: "深粉紅，外瓣較淺", hex: "#D96B86", form: "重瓣杯型 · 大花", notes: "濃香 · 切花表現極佳" },
        { name: "Othello", zh: "奧賽羅", color: "深紅轉紫紅", hex: "#8E2C46", form: "重瓣深杯 · 大花", notes: "強香 · 古典品種" },
        { name: "The Poet's Wife", zh: "詩人之妻", color: "蜜黃／奶油黃", hex: "#F2D07E", form: "重瓣 · 中花", notes: "強香 · 英系" },
        { name: "Amandine Chanel", zh: "阿曼丁·香奈兒", color: "深紅天鵝絨", hex: "#8C1F2E", form: "重瓣 · 大花", notes: "濃香 · 法系" },
        { name: "Parfum de Paris", zh: "巴黎香水", color: "紫粉／洋紅粉", hex: "#C06080", form: "重瓣 · 中花", notes: "強香 · 法系" },
        { name: "Henri Delbard", zh: "亨利·德爾巴", color: "粉紅帶條紋色暈", hex: "#E88CA4", form: "重瓣 · 大花", notes: "濃香 · 法系" },
        { name: "Julie Andrieu", zh: "茱莉·安德里厄", color: "粉紅，中心偏杏", hex: "#F0A9B8", form: "重瓣 · 中等", notes: "成簇開" }
      ]
    },
    {
      id: "floribunda",
      label: "豐花月季",
      en: "Floribunda & Polyantha",
      desc: "一株多花、花量驚人，適合初學者與大面積種植。",
      varieties: [
        { name: "Pink Drift", img: "images/pink-drift.jpg", zh: "粉紅漂流", color: "珊瑚粉，中心較深", hex: "#E88498", form: "半重瓣 · 小花", notes: "矮叢噴泉型 · 四季開花 · 抗病", flag: "非藤本" },
        { name: "Red Drift", img: "images/red-drift.jpg", zh: "深紅漂流", color: "深紅偏朱", hex: "#C1272D", form: "半重瓣 · 小花", notes: "矮叢噴泉型 · 四季開花 · 抗病", flag: "非藤本" },
        { name: "Out of Rosenheim", zh: "羅森海姆", color: "深紅偏緋", hex: "#B32B3A", form: "半重瓣～重瓣 · 中等", notes: "耐熱 · 花量多 · 抗病" },
        { name: "Sweet Pretty", zh: "甜蜜美人", color: "粉紅，瓣背偏淺", hex: "#F2AEC0", form: "半重瓣 · 小中花", notes: "成簇開 · 庭院表現好" },
        { name: "Cepheus", zh: "仙王座", color: "橙紅／朱紅", hex: "#E0553A", form: "半重瓣 · 中花", notes: "成簇開" },
        { name: "Plume White", zh: "白羽", color: "純白／乳白", hex: "#FAF7EE", form: "重瓣 · 中花", notes: "法系 · 花型柔和" },
        { name: "Plume Pink", zh: "粉羽", color: "淺粉／玫瑰粉", hex: "#F3B8C6", form: "重瓣 · 中花", notes: "法系 · 花型柔和" },
        { name: "Peachy Bonbons", zh: "蜜桃糖果", color: "蜜桃橙／杏橘", hex: "#F4A97B", form: "重瓣 · 中花", notes: "甜香 · 成簇開" },
        { name: "Petty Kiss", zh: "（疑為 Pretty Kiss）", color: "粉紅，瓣背偏白", hex: "#F0A8BC", form: "半重瓣 · 中花", notes: "名稱待核對", flag: "待核對" }
      ]
    },
    {
      id: "hybrid",
      label: "雜交茶香月季",
      en: "Hybrid Tea & Others",
      desc: "大花、單枝單朵，切花首選。",
      varieties: [
        { name: "Monalisa", zh: "蒙娜麗莎", color: "深紅天鵝絨", hex: "#9B1B2A", form: "重瓣 · 大花", notes: "切花 · 花型端正耐插" },
        { name: "Capri", zh: "卡布里", color: "深黃，瓣邊偏淺", hex: "#F0C233", form: "重瓣 · 中花", notes: "成簇開 · 荷系" },
        { name: "Eisvogel", zh: "翠鳥", color: "深紅偏藍紅", hex: "#A82735", form: "半重瓣 · 中花", notes: "德系 · 耐寒" },
        { name: "Cartonnage", img: "images/cartonnage.jpg", zh: "卡特納日", color: "淺粉帶杏黃暈", hex: "#F2C6B4", form: "半重瓣 · 中等", notes: "成簇開 · 法系", flag: "名稱待核對" },
        { name: "Bishop", zh: "主教", color: "深粉紅", hex: "#D9708C", form: "重瓣 · 中花", notes: "可能是 Bishop's Lodge", flag: "名稱待核對" },
        { name: "Le Temps des Cerises", zh: "櫻桃時光", color: "洋紅／櫻桃紅", hex: "#C0392B", form: "重瓣 · 中花", notes: "名稱待核對", flag: "名稱待核對" },
        { name: "Masora", zh: "雅（待確認）", color: "查無可靠資料", hex: "#CCCCCC", form: "—", notes: "需確認品種名", flag: "名稱待核對" }
      ]
    }
  ]
};
