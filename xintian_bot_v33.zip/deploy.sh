#!/bin/bash
# 心田 Bot 部署腳本（在主機執行）
set -e
DEST=/opt/xintian/bot
mkdir -p $DEST
echo "1. 目錄: $DEST"
cd $DEST
echo "2. 建立 venv..."
python3 -m venv venv 2>/dev/null || true
./venv/bin/pip install -q -r requirements.txt
echo "3. 套件安裝完成"
echo "4. 請確認 /etc/xintian-bot.env 有 XINTIAN_BOT_API_KEY"
echo "5. 啟動 Bot（見 systemd 服務）"
