/* 心田花園 · API 對接層
 * 有 API 環境 → 呼叫真系統；沒有 → 用本機模擬
 */
const API = {
  base: "",            // 同網域（遊戲部署在系統主機）
  token: null,
  useReal: false,      // 是否使用真實 API

  async login(code){
    // 開發用 dev-login（上線改用 Telegram initData）
    try{
      const r = await fetch(this.base + "/api/member/auth/dev-login", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({member_code: code}), signal: AbortSignal.timeout(3000)
      });
      if(!r.ok) throw new Error("login failed");
      const d = await r.json();
      this.token = d.access_token;
      this.useReal = true;
      return {ok:true};
    }catch(e){
      this.useReal = false;   // 退回模擬模式
      return {ok:false, fallback:true};
    }
  },

  headers(){
    return {"Authorization":"Bearer "+this.token, "Content-Type":"application/json"};
  },

  async me(){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/api/member/me",{headers:this.headers()});
      if(!r.ok) return null;
      return await r.json();
    }catch(e){ return null; }
  },

  async points(page=1, kind="all"){
    if(!this.useReal) return null;
    try{
      const r = await fetch(`${this.base}/api/member/points?page=${page}&kind=${kind}`,{headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async rebateBatches(page=1){
    if(!this.useReal) return null;
    try{
      const r = await fetch(`${this.base}/api/member/rebate-batches?page=${page}`,{headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async rewards(){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/api/member/rewards",{headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async gameState(){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/api/member/game",{headers:this.headers()});
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async startPlant(key, reqId){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/api/member/game/start",{
        method:"POST", headers:this.headers(),
        body: JSON.stringify({plant_key:key, request_id:reqId})
      });
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async observe(plantId, checkType){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/api/member/game/observe",{
        method:"POST", headers:this.headers(),
        body: JSON.stringify({plant_id:plantId, check_type:checkType})
      });
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  },

  async redeem(rewardId, reqId, note){
    if(!this.useReal) return null;
    try{
      const r = await fetch(this.base+"/api/member/reward-requests",{
        method:"POST", headers:this.headers(),
        body: JSON.stringify({reward_id:rewardId, quantity:1, note:note||"", request_id:reqId})
      });
      return r.ok ? await r.json() : null;
    }catch(e){ return null; }
  }
};

function uuid(){ return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,c=>{const r=Math.random()*16|0;return (c==="x"?r:(r&0x3|0x8)).toString(16);}); }
