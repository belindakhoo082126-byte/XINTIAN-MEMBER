/* 心田花園 · 遊戲核心 v1
 * 17 種植物 / 照顧 / 觀察 / 積分 / 兌換 / 花友中心
 * 目前用本機模擬；接系統時改 API 層即可
 */

// ============ 17 種植物配置（對齊系統契約）============
const PLANTS = [
  {key:"p01", emoji:"🪴", name:"石莲花",   cat:"多肉",   star:1, stages:["幼苗","新叶","莲座"],                water:3, fert:30, light:"充足日照", tip:"介质全干才浇，勿按固定天数"},
  {key:"p02", emoji:"🌺", name:"沙漠玫瑰", cat:"块根",   star:2, stages:["幼苗","茎基膨大","分枝","开花"],      water:4, fert:30, light:"充足日照", tip:"茎基软≠缺水，可能是积水"},
  {key:"p03", emoji:"💜", name:"薰衣草",   cat:"香草",   star:2, stages:["幼苗","枝叶茂密","抽穗","开花"],      water:1, fert:14, light:"充足日照+通风", tip:"高温高湿难养，通风最重要"},
  {key:"p04", emoji:"🍃", name:"红财神",   cat:"观叶",   star:2, stages:["幼苗","新叶1","新叶2","新叶3"],      water:2, fert:30, light:"明亮散射光", tip:"红叶≠要强晒，会灼伤"},
  {key:"p05", emoji:"🌸", name:"大岩桐",   cat:"草本花卉",star:3,stages:["幼苗","新叶","花苞","开花"],         water:1, fert:14, light:"明亮散射光", tip:"浇水避开叶心，否则冠腐"},
  {key:"p06", emoji:"🌼", name:"百万小铃", cat:"半木质花卉",star:3,stages:["幼苗","分枝","开花","修剪","复花"],  water:1, fert:14, light:"充足光照",   tip:"过湿叶黄≠缺肥，先查根"},
  {key:"p07", emoji:"🌹", name:"英式月季", cat:"木本花卉",star:4,stages:["幼苗","分枝","花苞","开花","修剪"],    water:2, fert:14, light:"充足日照+通风", tip:"控水≠断水；疏叶≠剃光"},
  {key:"p08", emoji:"🪷", name:"睡莲",     cat:"水生",   star:3, stages:["种藕","浮叶","立叶","开花"],          water:0, fert:21, light:"全日照",     tip:"保持水位，养鱼不可用一般荷花肥"},
  {key:"p09", emoji:"🌾", name:"万代兰",   cat:"裸根兰花",star:4,stages:["苗","新根","新叶","花梗","开花"],      water:0, fert:10, light:"明亮散射光", tip:"裸根≠不用浇水，需每日喷雾"},
  {key:"p10", emoji:"🦋", name:"蝴蝶兰",   cat:"介质兰花",star:4,stages:["苗","新根","新叶","花梗","开花"],      water:3, fert:14, light:"明亮散射光", tip:"水苔内部干才浇，别只看表面"},
  {key:"p11", emoji:"🌷", name:"地生兰",   cat:"土壤兰花",star:3,stages:["幼苗","丛生","花梗","开花"],           water:2, fert:30, light:"半日照",     tip:"地生兰与附生兰照顾不同"},
  {key:"p12", emoji:"🌿", name:"鹿角蕨",   cat:"附生蕨", star:4, stages:["苗","盾叶","孢子叶"],                  water:1, fert:21, light:"明亮散射光", tip:"盾叶变褐可能自然老化，别乱剪"},
  {key:"p13", emoji:"🍋", name:"柠檬",     cat:"果树",   star:4, stages:["幼苗","分枝","开花","结果","成熟"],    water:2, fert:14, light:"全日照",     tip:"结果期别急施氮肥"},
  {key:"p14", emoji:"🍇", name:"青葡萄",   cat:"藤本果", star:4, stages:["藤苗","长藤","开花","结果","成熟"],    water:2, fert:14, light:"全日照",     tip:"长藤≠会结果，注意光照与氮肥"},
  {key:"p15", emoji:"🍓", name:"草莓",     cat:"草本果", star:3, stages:["幼苗","开花","结果","转红"],           water:1, fert:14, light:"充足光照",   tip:"怕冠部积水，浇水避开花心"},
  {key:"p16", emoji:"🌶️", name:"辣椒",     cat:"果菜",   star:2, stages:["幼苗","分枝","开花","结果","转色"],    water:2, fert:14, light:"全日照",     tip:"开花后落花要找原因，不是猛施肥"},
  {key:"p17", emoji:"🥬", name:"小白菜",   cat:"叶菜",   star:1, stages:["播种","发芽","幼苗","长叶","可采收"],  water:1, fert:14, light:"半日照至全日照", tip:"叶菜周期短，勤观察"},
];

// 解鎖規則
const UNLOCK = [
  {need:0, plants:["p01","p17","p03"]},
  {need:1, plants:["p04","p16","p15","p02"]},
  {need:2, plants:["p05","p06","p08"]},
  {need:3, plants:["p10","p11","p12"]},
  {need:4, species:3, plants:["p07","p09","p13","p14"]},
];

// 每日任務上限
const DAILY_LIMIT = 25;
const TASK_LIMIT = {game_login:1, plant_care:3, game_quiz:3, plant_photo:1};


// ============ 蟲害資料 ============
const PESTS = [
  {id:"aphid", name:"蚜虫", icon:"🐛", desc:"绿色小虫聚集在嫩芽上", cure:"肥皂水喷洒", hint:"嫩芽上有密集绿色小虫"},
  {id:"scale", name:"介壳虫", icon:"🦠", desc:"白色硬壳粘在枝干", cure:"擦拭 + 除虫药", hint:"枝干上有白色硬壳小点"},
  {id:"spider", name:"红蜘蛛", icon:"🕷️", desc:"叶背有细网、红色小点", cure:"提高湿度 + 清洗叶背", hint:"叶背有细丝网"},
  {id:"whitefly", name:"粉虱", icon:"🦟", desc:"白色小飞虫飞起", cure:"黄板 + 除虫药", hint:"碰叶子会飞起白色小虫"},
  {id:"mealybug", name:"粉蚧", icon:"🪱", desc:"白色棉絮状", cure:"擦拭 + 隔离", hint:"叶腋有白色棉絮"},
];

// ============ 知識卡（部分，正式版接 100 條）============
const KNOWLEDGE_CARDS = [
  {t:"多肉叶子变红的原因", c:"日照充足 + 日夜温差大时，植物会产生花青素，叶片就会慢慢转红。变红是健康表现。"},
  {t:"浇水不是越多越好", c:"先摸土，干了才浇。多数植物烂根都是浇太多造成的。多肉 7-10 天浇一次就够。"},
  {t:"蛋壳不要直接放盆里", c:"未腐熟的蛋壳会招小黑飞和蚂蚁，建议堆肥腐熟后再用。"},
  {t:"兰花不一定要种在土里", c:"许多热带兰喜欢树皮、木炭、椰壳块这类透气介质，根需要空气。"},
  {t:"辣椒开花后落花怎么办", c:"先看是否热害、水分不稳或养分不足，别急着猛施肥。"},
  {t:"螞蟻出現代表什麼", c:"蚂蚁本身不伤植物，但大量出现常代表环境潮湿、土里有有机质，或伴随蚜虫、介壳虫。"},
  {t:"施肥要交替使用", c:"花肥和虫沙肥/黄豆肥建议 2 星期交替，不要一次重肥猛催，以免烧根。"},
  {t:"蝴蝶兰的水苔陷阱", c:"水苔常常表面干了、里面还湿。要摸内部湿度再浇，不然容易烂根。"},
  {t:"鹿角蕨盾叶变褐", c:"盾叶自然老化变褐是正常的，不要乱剪健康的功能结构。"},
  {t:"睡莲怎么养", c:"需要全日照、保持水位。花期用荷花肥(9-23-20)，养鱼的缸不适用一般荷花肥。"},
];

// ============ 每日小測題（部分）============
const QUIZ = [
  {q:"多肉叶尖变红，最可能的原因是？", o:["浇水太多","日照充足+温差大","生病了","缺肥"], a:1, ex:"日照充足 + 日夜温差大会产生花青素，叶片变红是健康表现。"},
  {q:"叶菜（小白菜）浇水原则？", o:["等土全干才浇","常保湿润","一周一次","只喷叶面"], a:1, ex:"叶菜需水多，保持土壤湿润，但不能积水。"},
  {q:"蝴蝶兰用水苔种植，什么时候浇水？", o:["表面干就浇","水苔内部干才浇","每天浇","不浇水"], a:1, ex:"水苔常表干内湿，要摸内部湿度。"},
  {q:"辣椒开花后落花，第一步应该？", o:["猛施肥","找原因（热害/水分/养分）","剪掉所有花","换盆"], a:1, ex:"落花要先诊断原因，不是马上施肥。"},
  {q:"蚂蚁大量出现在盆栽，通常代表？", o:["植物健康","环境潮湿或有伴生害虫","要开花","缺光"], a:1, ex:"蚂蚁常伴蚜虫、介壳虫，也可能是环境太湿。"},
];


// ============ 知識卡（依植物 + 通用，約 100 條）============
const KNOWLEDGE_BY_PLANT = {
p01:["多肉叶子变红是健康表现，代表日照充足、温差大。","多肉宁少浇勿多浇，介质全干再浇。","多肉怕闷湿，通风比浇水更重要。","多肉用颗粒土，排水是关键。","多肉可叶插繁殖，摘下叶片晾干再放土上。"],
p02:["沙漠玫瑰茎基软不一定是缺水，可能是积水。","沙漠玫瑰膨大茎基会储水，宁干勿湿。","沙漠玫瑰用 Ferti 16G 促开花。","沙漠玫瑰要充足日照，幼株需循序适应。","沙漠玫瑰修剪后切口要晾干再接触土壤。"],
p03:["薰衣草怕闷湿，马来西亚低地要特别通风。","薰衣草萎蔫可能不是缺水，是热湿伤根。","薰衣草用 Ferti 53 配黄豆肥。","薰衣草喜欢凉爽干燥，避免午后暴雨。","薰衣草开花后可修剪，促进侧芽。"],
p04:["红财神红叶不需要强晒，强晒会灼伤。","观叶植物用明亮散射光最好。","红财神用 FE17 绿又亮叶色更艳。","观叶植物避免长期泡水，会烂根。"],
p05:["大岩桐浇水要避开叶心和冠部。","大岩桐有块茎，怕积水烂根。","大岩桐会有休眠期，别以为死了。","大岩桐用 Ferti 53 配虫沙肥。","大岩桐叶子有绒毛，不要喷水在叶面。"],
p06:["百万小铃过湿叶黄，要先查根不是加肥。","百万小铃要适度修剪才会复花。","百万小铃用 Ferti 53 配虫沙肥。","百万小铃喜欢充足光照，炎热时注意水分。"],
p07:["月季控水≠断水，缺水也会萎蔫落花。","月季疏叶≠剃光，健康叶要保留。","月季用 Ferti 23 玫瑰肥配木醋液。","月季要通风好，减少黑斑病。","月季花后修剪可促进下次开花。"],
p08:["睡莲需要全日照才会开花。","睡莲用 FE170 荷花肥，养鱼也可用。","睡莲要定期补充水位。","睡莲每 2 星期施肥一次。","睡莲叶片有缺口是正常的，不要剪。"],
p09:["万代兰是裸根兰，靠气根吸空气水分。","万代兰需要每天喷雾保持湿度。","万代兰用泰国水状兰花肥稀薄喷施。","万代兰喜欢明亮散射光与良好通风。"],
p10:["蝴蝶兰水苔常表干内湿，别只看表面。","蝴蝶兰用泰国颗粒兰花肥薄肥勤施。","蝴蝶兰花谢后从花梗剪，可能再开花。","蝴蝶兰怕积水，根要透气。"],
p11:["地生兰与附生兰照顾方式不同。","地生兰用土壤栽培，见干见湿。","地生兰喜欢半日照。","地生兰用泰国颗粒兰花肥。"],
p12:["鹿角蕨盾叶变褐可能是自然老化。","鹿角蕨需要高湿度但介质要透气。","鹿角蕨用蚯蚓肥，稀薄少量。","鹿角蕨可以上板或上树，附生栽培。"],
p13:["柠檬结果期别急施氮肥。","柠檬用 Eco21 果肥配黄豆肥、木醋液。","果树肥料要 2 星期轮流使用，避免烧根。","柠檬需要全日照才会结果。","柠檬开花后要减少浇水波动，防落果。"],
p14:["葡萄长藤不结果，通常是光照不足或氮肥过多。","青葡萄用 Eco21 果肥配黄豆肥、木醋液。","葡萄要搭架，让藤蔓攀爬。","葡萄结果期需要稳定水分。"],
p15:["草莓怕冠部积水，浇水避开花心。","草莓用 Eco21 果肥，2 星期交替。","草莓可用走茎繁殖新株。","草莓结果期要注意防鸟。"],
p16:["辣椒开花后落花要找原因，不是猛施肥。","辣椒用 Ferti 42G 蔬果肥。","辣椒需要全日照。","辣椒结果期要稳定供水，忽干忽湿易落果。"],
p17:["小白菜生长周期短，要勤观察。","叶菜用 Ferti 42G 蔬果肥。","小白菜要常保湿润，但不能积水。","小白菜可以播种繁殖，约一个月可采收。","叶菜要防虫，可用防虫网。"],
};
const KNOWLEDGE_GENERAL = [
"浇水前先摸土，干了才浇。","多数植物烂根都是浇太多造成的。","蛋壳要腐熟再用，不然会招虫。",
"蚂蚁大量出现常代表有蚜虫或介壳虫。","施肥要交替使用，不要一次重肥猛催。","兰花不一定种在土里，很多喜欢透气介质。",
"叶黄不一定是缺肥，要先查根和排水。","连续下雨不要继续浇水，要检查排水。","植物打蔫不一定是缺水，也可能是烂根。",
"通风是预防病虫害的关键。","有虫害可用 All in One，蜗牛要用蜗牛药。","自制的草本肥料要充分腐熟。",
"夏天正午不要浇水，容易伤根。","换盆后要缓苗几天再施肥。","修剪要剪枯枝病枝，保留健康叶。",
"多肉用颗粒土，排水最重要。","香草喜欢凉爽干燥和通风。","水生植物保持水位很重要。",
"果树要全面养分，才会开花结果。","叶子有白斑可能是日照不足。","叶尖焦枯可能是施肥过量。",
"叶片下垂可能是缺水。","介壳虫是白色硬壳，要擦拭。","红蜘蛛在叶背，喜欢干燥闷热。",
"粉虱碰叶子会飞起。","粉蚧像白色棉絮。","蜗牛多在雨后出现。",
"盆栽垫高可改善排水。","浇水浇透比天天浇一点好。","观察植物比照表操课重要。",
];

// ============ 蟲害邏輯 ============
function maybePest(){
  // 照顧不好（水太多/健康低）或隨機 → 生蟲
  if(!S.plant || S.plant.pest) return;
  const badCare = S.plant.water>90;
  const rnd = Math.random();
  if(badCare && rnd<0.3 || rnd<0.05){
    const pest = PESTS[Math.floor(Math.random()*PESTS.length)];
    S.plant.pest = pest;
    setTimeout(()=>toast("⚠️ 你的植物好像有虫了，检查一下吧！"),800);
  }
}

// ============ 狀態 ============
// 施肥選項 / 位置 / 肥料資料 見 fert_data.js

let S = {
  code:"XT-0001",
  name:"enabelle khoo",
  tier:"VIP",
  points_total:745,
  points_pending:0,
  plant:null,           // 目前種植
  completed:0,          // 完成株數
  species:[],           // 完成過的種類
  observed_today:false,
  watered_today:false,
  consecutive:5,
  today_points:9,       // 今日已得
  task_done:{game_login:0, plant_care:2, game_quiz:1, plant_photo:0},
  points_history:[
    {date:"10/12", reason:"答对问答", change:10},
    {date:"10/11", reason:"照顾植物", change:3},
    {date:"10/11", reason:"每日登入", change:2},
  ],
  rebate_total:15.50,
  rebate_batches:[
    {date:"10/01", reason:"消费回馈", amount:10, exp:"11/30", status:"available"},
    {date:"10/08", reason:"折抵肥料", amount:-5, exp:null, status:"used"},
  ],
  reward_requests:[],
  admin:false,          // 管理者模式
};

// 禮物（正式版讀系統 /api/member/rewards）
const REWARDS = [
  {id:1, name:"随机小植物盲盒", points:400},
  {id:2, name:"RM10 voucher",  points:500},
  {id:3, name:"随机香草/多肉",  points:600},
  {id:4, name:"心田自制肥料",   points:700},
  {id:5, name:"植物数字学解读", points:900},
  {id:6, name:"随机高值植物",   points:2000},
];

// 知識庫（正式版讀 100 條 tips）
const TIPS = [
  {t:"为什么多肉的叶子会变红？", c:"日照充足 + 日夜温差大时，植物会产生花青素，叶片就会慢慢转红，看起来更漂亮。"},
  {t:"浇水不是越多越好", c:"先摸土，干了才浇。多数植物烂根都是浇太多造成的。"},
  {t:"蛋壳不要直接放盆里", c:"未腐熟的蛋壳会招虫，建议堆肥腐熟后再用。"},
  {t:"兰花不一定要种在土里", c:"许多热带兰喜欢树皮、木炭、椰壳块这类透气介质，根需要空气。"},
  {t:"辣椒开花后落花怎么办？", c:"先看是否热害、水分不稳或养分不足，别急着猛施肥。"},
];

// ============ 工具 ============
function toast(msg){
  const t=document.getElementById("toast");
  t.textContent=msg; t.classList.add("show");
  clearTimeout(t._tm); t._tm=setTimeout(()=>t.classList.remove("show"),1800);
}
function getPlant(key){ return PLANTS.find(p=>p.key===key); }
function unlockedKeys(){
  const keys=["p01","p17","p03"];
  UNLOCK.forEach(u=>{
    if(S.completed>=u.need){
      if(u.species && new Set(S.species).size < u.species) return;
      u.plants.forEach(k=>{ if(!keys.includes(k)) keys.push(k); });
    }
  });
  return keys;
}
function availablePoints(){ return S.points_total - S.points_pending; }

// ============ 渲染：頁面骨架 ============
function renderApp(){
  document.getElementById("app").innerHTML = `
  <!-- 登入 -->
  <div class="page active" id="page-login">
    <div class="logo-big">🌱</div>
    <h1>心田花园</h1>
    <p class="sub">一边种 · 一边学 · 一边拿</p>
    <div class="login-box">
      <input id="member-code" placeholder="输入会员编号" value="XT-0001">
      <button class="btn-main" onclick="doLogin(false)">花友进入</button>
      <a class="link-admin" onclick="doLogin(true)">管理者进入</a>
    </div>
  </div>

  <!-- 花園 -->
  <div class="page" id="page-garden">
    <div class="topbar">
      <div class="t">心田花园</div>
      <div class="score" id="garden-score">0 分</div>
    </div>
    <div class="scene" id="scene">
      <img class="bg-img" src="bg.jpg" onerror="this.style.display='none'">
      <div class="plant-area" id="plant-area"></div>
    </div>
    <div id="garden-info"></div>
    <div class="actions">
      <button class="action" onclick="doCare('water')" style="${S.plant&&S.plant.water<70?'':'opacity:.4'}"><span class="ic">水</span><span class="lb">浇水${S.plant&&S.plant.water<70?' ⚠️':''}</span></button>
      <button class="action" id="btn-fert" onclick="${S.plant&&S.plant.food<50?'doCare(\'fert\')':'toast(\'养分充足，暂时不用施肥 🌾\')'}" style="${S.plant&&S.plant.food<50?'':'opacity:.4'}"><span class="ic">肥</span><span class="lb">施肥${S.plant&&S.plant.food<50?' ⚠️':''}</span></button>
      <button class="action" onclick="doPest()" style="${S.plant&&S.plant.pest?'':'opacity:.4'}"><span class="ic">虫</span><span class="lb">除虫${S.plant&&S.plant.pest?' ⚠️':''}</span></button>
      <button class="action" onclick="doObserve('moisture')"><span class="ic">查</span><span class="lb">检查</span></button>
    </div>
    <div class="nav">
      <button class="nav-item active" onclick="go('garden')"><span class="ni">园</span><span class="nl">花园</span></button>
      <button class="nav-item" onclick="go('choose')"><span class="ni">种</span><span class="nl">种植</span></button>
      <button class="nav-item" onclick="go('reward')"><span class="ni">礼</span><span class="nl">兑换</span></button>
      <button class="nav-item" onclick="go('member')"><span class="ni">我</span><span class="nl">花友中心</span></button>
    </div>
  </div>

  <!-- 選擇種植 -->
  <div class="page" id="page-choose">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>选择要种的植物</h2></div>
    <div class="scroll" id="choose-content"></div>
  </div>

  <!-- 學習 -->
  <div class="page" id="page-learn">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>植物知识</h2></div>
    <div class="scroll" id="learn-content"></div>
  </div>

  <!-- 兌換 -->
  <div class="page" id="page-reward">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>兑换礼物</h2></div>
    <div class="scroll" id="reward-content"></div>
  </div>

  <!-- 花友中心 -->
  <div class="page" id="page-member">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>花友中心</h2></div>
    <div class="scroll" id="member-content"></div>
  </div>

  <!-- 任務 -->
  <div class="page" id="page-task">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>今日任务</h2></div>
    <div class="scroll" id="task-content"></div>
  </div>

  <!-- 管理者 -->
  <div class="page" id="page-admin">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>管理者 · 花园管理</h2></div>
    <div class="scroll" id="admin-content"></div>
  </div>

  <!-- Modal -->
  <div class="modal-bg" id="modal-detail" onclick="if(event.target===this)this.classList.remove('show')">
    <div class="modal wide" style="background:#fff;border-radius:16px;padding:24px;max-width:400px;margin:auto;position:relative;max-height:85vh;overflow-y:auto">
      <button onclick="document.getElementById('modal-detail').classList.remove('show')" style="position:absolute;top:12px;right:12px;border:none;background:#F0F2EE;width:32px;height:32px;border-radius:50%;font-size:15px;cursor:pointer">✕</button>
      <div id="detail-content"></div>
    </div>
  </div>`;
}

// ============ 登入 ============
async function doLogin(isAdmin){
  const code=document.getElementById("member-code").value.trim();
  if(!code){ toast("请输入会员编号"); return; }
  S.code=code;
  S.admin=isAdmin;
  // 嘗試呼叫系統 API
  const r = await API.login(code);
  if(r.ok){
    await loadFromAPI();
    toast("已连接系统");
  } else {
    toast("离线模式（"+code+"）");
  }
  if(isAdmin){ go("admin"); toast("管理者模式"); }
  else { go("garden"); }
  addPoints(2,"每日登入");
}

// 從系統載入真實資料
async function loadFromAPI(){
  const me = await API.me();
  if(me){
    S.name = me.member.name;
    S.tier = me.member.tier;
    S.points_total = me.points_total;
    S.points_pending = me.points_pending_redemption;
    S.rebate_total = me.rebate_available;
  }
  const gs = await API.gameState();
  if(gs){
    S.completed = gs.completed_count || 0;
    S.species = gs.completed_species || [];
    if(gs.current_plant){
      S.plant = {
        key: gs.current_plant.plant_key,
        plantId: gs.current_plant.id,
        stageIdx: 0,
        stageName: gs.current_plant.status || "幼苗",
        day: 1, water:50, food:50, health:100
      };
    }
  }
  const rw = await API.rewards();
  if(rw && rw.rewards){
    REWARDS.length = 0;
    rw.rewards.forEach(x=>REWARDS.push({id:x.id, name:x.name, points:x.points}));
  }
}

// ============ 頁面切換 ============
function go(p){
  document.querySelectorAll(".page").forEach(e=>e.classList.remove("active"));
  const el=document.getElementById("page-"+p);
  if(el) el.classList.add("active");
  if(p==="garden") renderGarden();
  if(p==="choose") renderChoose();
  if(p==="learn") renderLearn();
  if(p==="reward") renderReward();
  if(p==="member") renderMember();
  if(p==="task") renderTask();
  if(p==="admin") renderAdmin();
}

// ============ 花園 ============
function renderGarden(){
  document.getElementById("garden-score").textContent=availablePoints()+" 分";
  const area=document.getElementById("plant-area");
  const info=document.getElementById("garden-info");
  if(!S.plant){
    area.innerHTML=`<div style="text-align:center"><div style="font-size:70px">🌱</div>
      <div style="font-size:15px;font-weight:700;color:#2E5D2A;margin-top:8px">你还没有种植物</div>
      <button class="btn-main" style="margin-top:14px;width:auto;padding:12px 28px" onclick="go('choose')">去种植</button></div>`;
    info.innerHTML=`<div class="info-card"><div style="text-align:center;font-size:13px;color:#889">完成株数：${S.completed} · 连续观察：${S.consecutive} 天</div></div>`;
    return;
  }
  const p=getPlant(S.plant.key);
  // 依狀態決定植物外觀
  let cls = "plant-img";
  let imgSrc = `plants/${p.key}.png`;
  if(S.plant.wilting){
    imgSrc = `plants_wilt/${p.key}.png`;   // 換成缺水版
    cls += " wilt";
  } else if(S.plant.stageIdx===0) cls += " small";
  else if(S.plant.stageIdx < p.stages.length-1) cls += " grow";
  else cls += " bloom";
  // 開花 overlay（到最後階段才顯示）
  let bloom = "";
  if(S.plant.stageIdx >= p.stages.length-1 && !S.plant.wilting){
    bloom = `<div class="bloom-overlay" style="top:30px;right:60px">🌸</div><div class="bloom-overlay" style="top:70px;left:55px;animation-delay:1s">🌸</div>`;
  }
  area.innerHTML=`<div style="position:relative">${bloom}
    <img class="${cls}" src="${imgSrc}" onerror="this.src='plants/${p.key}.png'">
    </div>
    <div class="plant-stage">${p.name} · ${S.plant.stageName} · 第 ${S.plant.day} 天</div>`;
  const wiltBanner = S.plant.wilting ? `<div style="background:#FFF8E1;color:#8D6E00;padding:8px 14px;border-radius:12px;font-size:12.5px;font-weight:600;margin-bottom:8px;text-align:center">🥀 植物有点打蔫了，检查一下水分和养分吧</div>` : "";
  const pestBanner = S.plant.pest ? `<div style="background:#FFEBEE;color:#C62828;padding:8px 14px;border-radius:12px;font-size:12.5px;font-weight:600;margin-bottom:8px;text-align:center">⚠️ 发现虫害！点击「除虫」处理</div>` : "";
  info.innerHTML=`<div class="info-card">
    ${wiltBanner}
    ${pestBanner}
    <div class="pname">${p.name}</div>
    <div class="bar-row"><span class="lb">水</span><div class="bar"><div class="bar-fill w" style="width:${S.plant.water}%"></div></div></div>
    <div class="bar-row"><span class="lb">肥</span><div class="bar"><div class="bar-fill f" style="width:${S.plant.food}%"></div></div></div>
    <div class="bar-row"><span class="lb">健</span><div class="bar"><div class="bar-fill h" style="width:${S.plant.health}%"></div></div></div>
    <div style="font-size:11px;color:#889;text-align:center;margin-top:6px">位置：${LOCATIONS[S.plant.location||"outdoor"].name}</div>
  </div>`;
}


// ============ 每日推進（養分下降、打蔫）============
const PLANT_DECAY = {
  p01:10, p02:10, p03:20, p04:12, p05:20, p06:20, p07:18, p08:12,
  p09:10, p10:10, p11:12, p12:10, p13:15, p14:15, p15:18, p16:18, p17:20
};
function dailyTick(){
  if(!S.plant) return;
  const p = S.plant;
  const decay = PLANT_DECAY[p.key] || 15;
  p.food = Math.max(0, p.food - decay);
  p.water = Math.max(0, p.water - (p.key==="p01"||p.key==="p02" ? 15 : 25));
  // 打蔫判斷（不死亡）
  if(p.water < 30 || p.food < 30){
    p.health = Math.max(20, p.health - 10);
    p.wilting = true;
  } else {
    p.health = Math.min(100, p.health + 3);
    if(p.health > 60) p.wilting = false;
  }
  p.day++;
  S.watered_today = false;   // 新的一天可再澆
  maybePest();
  // 成長
  maybeGrow();
}

// ============ 照顧 ============

// ============ 施肥（選肥料）============
function openFertPanel(){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  if(S.plant.food >= 50){ toast("养分充足（"+Math.round(S.plant.food)+"/100），暂时不用施肥 🌾"); return; }
  const key = S.plant.key;
  const fq = FERT_QUIZ[key];
  if(!fq){ toast("此植物暂无需施肥"); return; }
  // 選項：A(錯1) / B(正確,組合) / C(錯2)
  const comboName = fq.B.map(k=>FERTILIZERS[k].name).join(" + ");
  const opts = [
    {name:FERTILIZERS[fq.A].name, ok:false},
    {name:comboName, ok:true},
    {name:FERTILIZERS[fq.C].name, ok:false},
  ];
  opts.sort(()=>Math.random()-0.5);
  S._fertOpts = opts;
  let h = `<div style="font-size:13px;color:#889;margin-bottom:12px">${getPlant(key).name} 需要施肥了（养分 ${Math.round(S.plant.food)}/100）<br>请选择正确的肥料：</div>`;
  opts.forEach((o,i)=>{
    h += `<button class="btn-redeem" style="width:100%;margin-bottom:9px;background:#F0F7EC;color:#3A4A36;text-align:left;padding:13px 15px;font-size:13px;line-height:1.5" onclick="doFert(${i})">${o.name}</button>`;
  });
  document.getElementById("detail-content").innerHTML = h;
  document.getElementById("modal-detail").classList.add("show");
}

function doFert(i){
  const o = S._fertOpts[i];
  const fq = FERT_QUIZ[S.plant.key];
  const pname = getPlant(S.plant.key).name;
  let title, body, pts;
  if(o.ok){
    S.plant.food = Math.min(100, S.plant.food + 40);
    pts = 0;
    if(S.task_done.plant_care < TASK_LIMIT.plant_care){
      addPoints(1,"照顾植物"); S.task_done.plant_care++; pts = 1;
    }
    title = "✅ 施肥正确" + (pts ? " +1 分" : "（今日照顾已达上限）");
    body = fq.tip;
  } else {
    S.plant.food = Math.min(100, S.plant.food + 10);
    title = "❌ 这个肥料不适合 " + pname + "（未加分）";
    body = "正确做法：" + fq.tip;
  }
  showResult(title, body);
  renderGarden();
}

// 顯示結果（手動關閉，不自動消失）
function showResult(title, body){
  const isOk = title.indexOf("✅") === 0;
  const h = `
    <div style="text-align:center">
      <div style="font-size:17px;font-weight:700;color:${isOk?'#2E7D32':'#C62828'};margin-bottom:14px">${title}</div>
      <div style="background:${isOk?'#EAF3E4':'#FFF8E1'};border-radius:12px;padding:16px;font-size:13px;line-height:1.8;color:#3A4A36;text-align:left;margin-bottom:18px">💡 ${body}</div>
      <button class="btn-main" onclick="document.getElementById('modal-detail').classList.remove('show')" style="width:100%">我读完了</button>
    </div>`;
  document.getElementById("detail-content").innerHTML = h;
  document.getElementById("modal-detail").classList.add("show");
}

// ============ 移位（選位置）============
function openLocPanel(){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  const cur = S.plant.location || "outdoor";
  const good = PLANT_LOCATION[S.plant.key];
  let h = `<div style="font-size:13px;color:#889;margin-bottom:10px">选择养护位置（光照 + 通风）</div>`;
  Object.keys(LOCATIONS).forEach(k=>{
    const L = LOCATIONS[k];
    h += `<button class="btn-redeem" style="width:100%;margin-bottom:8px;background:#F0F7EC;color:#3A4A36;text-align:left;padding:12px 14px" onclick="doMove('${k}')">${L.name} · ${L.light} · ${L.air}</button>`;
  });
  document.getElementById("detail-content").innerHTML = h;
  document.getElementById("modal-detail").classList.add("show");
}

function doMove(k){
  S.plant.location = k;
  const good = PLANT_LOCATION[S.plant.key];
  if(k === good){
    S.plant.health = Math.min(100, S.plant.health + 15);
    showResult("✅ 位置合适！", LOCATIONS[k].name + "：光照 " + LOCATIONS[k].light + "、通风 " + LOCATIONS[k].air + "，很适合它。");
  } else {
    showResult("⚠️ 位置不太适合", "这个位置（" + LOCATIONS[k].name + "）" + LOCATIONS[k].air + "，对 " + getPlant(S.plant.key).name + " 不太理想。建议再想想它喜欢什么环境。");
  }
  renderGarden();
}

function doCare(type){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  const p=getPlant(S.plant.key);
  if(type==="water"){
    if(S.watered_today){ toast("今天已经浇过水了，不用天天浇哦 💧"); return; }
    if(S.plant.water>85){ toast("植物现在不需要浇水哦 💧"); return; }
    S.plant.water=Math.min(100,S.plant.water+35);
    S.watered_today=true;
    if(S.task_done.plant_care < TASK_LIMIT.plant_care){
      addPoints(1,"照顾植物"); S.task_done.plant_care++;
      toast("浇水完成 +1 分");
    } else { toast("浇水完成（今日照顾已达上限）"); }
    splashWater();
  } else if(type==="fert"){
    openFertPanel();
    return;
  }
  if(type==="water"){ }
  maybeGrow();
  maybePest();
  renderGarden();
}
function splashWater(){
  const area=document.getElementById("plant-area");
  for(let i=0;i<3;i++){
    const d=document.createElement("div");
    d.className="drop"; d.style.left=(35+i*12)+"%";
    d.style.animationDelay=(i*0.15)+"s";
    area.appendChild(d);
    setTimeout(()=>d.remove(),1800);
  }
}
function maybeGrow(){
  const p=getPlant(S.plant.key);
  // 簡單：水肥都 >70 且天數到，就進階
  const needDay=(S.plant.stageIdx+1)*2;
  if(S.plant.water>70 && S.plant.food>70 && S.plant.day>=needDay){
    if(S.plant.stageIdx < p.stages.length-1){
      S.plant.stageIdx++;
      S.plant.stageName=p.stages[S.plant.stageIdx];
      addPoints(5,"植物成长");
      toast("🌱 植物长大了："+S.plant.stageName);
      // 完成判斷
      if(S.plant.stageIdx===p.stages.length-1 && S.plant.day>=p.stages.length*2){
        completePlant();
      }
    }
  }
}
function completePlant(){
  const p=getPlant(S.plant.key);
  toast("🎉 完成一株 "+p.name+"！");
  S.completed++;
  if(!S.species.includes(p.key)) S.species.push(p.key);
  S.plant=null;
  setTimeout(()=>go("choose"),1200);
}

// ============ 觀察 ============

function doPest(){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  if(!S.plant.pest){ toast("检查过了，目前没有虫害 🐛"); return; }
  const pest = S.plant.pest;
  // 顯示蟲害資訊（玩家辨識）
  const ok = confirm("发现【"+pest.name+"】\n"+pest.desc+"\n\n正确处理方式："+pest.cure+"\n\n要处理吗？");
  if(ok){
    S.plant.pest = null;
    addPoints(1,"照顾植物");
    toast("✅ 已处理 "+pest.name+"，+1 分");
    // 答對知識 → 學到
    S.learned = S.learned || [];
    if(!S.learned.includes(pest.id)) S.learned.push(pest.id);
  }
  renderGarden();
}

async function doObserve(type){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  if(S.observed_today){ toast("今天已经检查过了，明天再来 🌿"); return; }
  // 呼叫系統 API
  const res = await API.observe(S.plant.plantId, type);
  S.observed_today=true;
  if(res && res.consecutive_days) S.consecutive = res.consecutive_days;
  else S.consecutive++;
  toast("今日检查完成（连续 "+S.consecutive+" 天）");
  if(res && res.streak_reward){ addPoints(20,"连续观察"); toast("🎉 连续7天观察 +20 分！"); }
  else if(!res && S.consecutive%7===0){ addPoints(20,"连续观察"); toast("🎉 连续7天观察 +20 分！"); }
  maybePest();
  renderGarden();
}

// ============ 選擇種植 ============
function renderChoose(){
  const un=unlockedKeys();
  let h=`<div class="card"><div class="lbl">已完成 ${S.completed} 株 · 已解锁 ${un.length} / 17 种</div>
    <div style="font-size:12px;color:#889;line-height:1.6">完成 1 株解锁 4 种，完成 2 株再解锁 3 种，完成 3 株再解锁 3 种，完成 4 株（≥3 种不同）解锁全部。</div></div>
    <div class="plant-grid">`;
  PLANTS.forEach(p=>{
    const ok=un.includes(p.key);
    const lock=(S.plant&&S.plant.key===p.key)?"✅":"";
    h+=`<div class="plant-cell ${ok?'':'locked'}" onclick="${ok?`startPlant('${p.key}')`:`toast('未解锁')`}">
      <div class="pi"><img src="plants/${p.key}.png" style="width:44px;height:44px;object-fit:contain" onerror="this.outerHTML='<div style=font-size:30px>${p.emoji}</div>'"></div>
      <div class="pn">${p.name}</div>
      <div class="ps">${"★".repeat(p.star)}</div>
      ${ok?'':`<div class="lock">🔒</div>`}
    </div>`;
  });
  h+=`</div>`;
  document.getElementById("choose-content").innerHTML=h;
}
async function startPlant(key){
  if(S.plant){ toast("一次只能种一株，先完成现在的植物"); return; }
  const p=getPlant(key);
  // 呼叫系統 API
  const res = await API.startPlant(key, uuid());
  S.plant={key:key, plantId:(res&&res.plant_id)||null, stageIdx:0, stageName:p.stages[0], day:1, water:60, food:55, health:100, location:(PLANT_LOCATION[key]||'outdoor'), wilting:false};
  toast("种下了 "+p.name+" 🌱");
  go("garden");
}

// ============ 學習 ============
function renderLearn(){
  let h = `<div class="card" style="background:#EAF3E4"><div class="lbl">📚 知识卡（阅读 +2 分，每日 1 次）</div>
    <div style="font-size:11.5px;color:#5B6B57">每天学一点，把绿意带回家</div></div>`;
  // 當前植物的知識
  if(S.plant && KNOWLEDGE_BY_PLANT[S.plant.key]){
    const pn = getPlant(S.plant.key).name;
    h += `<div class="section-title">🌿 你正在种：${pn}</div>`;
    KNOWLEDGE_BY_PLANT[S.plant.key].forEach(c=>{
      h += `<div class="card" style="padding:13px 16px"><div style="font-size:12.5px;color:#3A4A36;line-height:1.7">• ${c}</div></div>`;
    });
  } else {
    h += `<div class="card" style="background:#FFF8E1;padding:13px 16px"><div style="font-size:12.5px;color:#8D6E00">🌱 种下一株植物后，这里会出现它的专属养护知识。</div></div>`;
  }
  // 全部植物知识（可展开）
  h += `<div class="section-title">🌿 各植物养护知识（点击展开）</div>`;
  Object.keys(KNOWLEDGE_BY_PLANT).forEach(k=>{
    const pn = getPlant(k).name;
    h += `<div class="card" style="padding:0;overflow:hidden"><div onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='block'?'none':'block'" style="padding:13px 16px;cursor:pointer;display:flex;justify-content:space-between"><span style="font-size:13px;font-weight:600;color:#2E5D2A">🌿 ${pn}</span><span style="color:#7BA05B">▾</span></div>
      <div style="display:none;padding:0 16px 13px">`;
    KNOWLEDGE_BY_PLANT[k].forEach(c=>{
      h += `<div style="font-size:12px;color:#3A4A36;line-height:1.6;margin-bottom:6px">• ${c}</div>`;
    });
    h += `</div></div>`;
  });
  h += `<div class="section-title">📖 通用植物知识</div>`;
  KNOWLEDGE_GENERAL.forEach(c=>{
    h += `<div class="card" style="padding:12px 16px"><div style="font-size:12.5px;color:#3A4A36;line-height:1.7">• ${c}</div></div>`;
  });
  h += `<div style="text-align:center;margin:16px 0"><button class="btn-main" onclick="readKnowledge()" style="width:auto;padding:12px 28px">读完今日知识 +2 分</button></div>`;
  h += `<div class="section-title">📝 每日小测（答对 +5 分，每日 3 次）</div>`;
  S.quizIdx = S.quizIdx || 0;
  const q = QUIZ[S.quizIdx % QUIZ.length];
  h += `<div class="card"><div style="font-size:13.5px;font-weight:700;color:#2E5D2A;margin-bottom:10px">${q.q}</div>`;
  q.o.forEach((opt,i)=>{
    h += `<button class="btn-redeem" style="width:100%;margin-bottom:7px;background:#F0F7EC;color:#3A4A36;text-align:left;padding:11px 14px" onclick="answerQuiz(${i})">${String.fromCharCode(65+i)}. ${opt}</button>`;
  });
  h += `</div>`;
  if(S.plant){
    const p=getPlant(S.plant.key);
    h+=`<div class="card" style="background:#EAF3E4"><div style="font-size:13px;font-weight:700;color:#2E5D2A">🌿 ${p.name} 养护重点</div>
      <div style="font-size:12px;color:#3A4A36;line-height:1.7;margin-top:6px">${p.tip}</div></div>`;
  }
  document.getElementById("learn-content").innerHTML=h;
}

function readKnowledge(){
  if(S.read_today){ toast("今天已经读过了，明天再来 📚"); return; }
  S.read_today = true;
  addPoints(2, "阅读知识");
  toast("📚 阅读完成 +2 分");
}

function answerQuiz(i){
  const q = QUIZ[S.quizIdx % QUIZ.length];
  if(i === q.a){
    if(S.task_done.game_quiz < TASK_LIMIT.game_quiz){
      addPoints(5, "答对问答");
      S.task_done.game_quiz++;
      toast("✅ 答对了！+5 分\n" + q.ex);
    } else { toast("答对了！但今日答题已达上限"); }
    S.quizIdx++;
  } else {
    toast("❌ 答错了，再想想～");
  }
  renderLearn();
}

// ============ 兌換 ============
function renderReward(){
  let h=`<div class="card"><div class="lbl">可用积分</div>
    <div style="font-size:25px;font-weight:700;color:#5E8A45">${availablePoints()}</div>
    <div style="font-size:11.5px;color:#889;margin-top:4px">总积分 ${S.points_total} · 待审核 ${S.points_pending} · 每人每月限换 1 件</div></div>`;
  REWARDS.forEach(r=>{
    const can=availablePoints()>=r.points;
    h+=`<div class="reward-item"><div><div class="rn">${r.name}</div><div class="rp">${r.points} 分</div></div>
      <button class="btn-redeem" ${can?"":"disabled"} onclick="doRedeem(${r.id})">申请</button></div>`;
  });
  if(S.reward_requests.length){
    h+=`<div class="section-title">我的申请</div>`;
    S.reward_requests.forEach(rq=>{
      h+=`<div class="card" style="padding:12px 15px"><div class="list-item" style="border:none;padding:0">
        <span>${rq.name} · ${rq.points} 分</span><span class="tag-avail">待审核</span></div></div>`;
    });
  }
  document.getElementById("reward-content").innerHTML=h;
}
async function doRedeem(id){
  const r=REWARDS.find(x=>x.id===id);
  if(availablePoints()<r.points){ toast("积分不足"); return; }
  if(S.reward_requests.length>=1){ toast("每人每月限换 1 件"); return; }
  const res = await API.redeem(id, uuid());
  S.points_pending+=r.points;
  S.reward_requests.push({id:id,name:r.name,points:r.points,status:"pending"});
  toast("已提交申请："+r.name);
  renderReward();
}

// ============ 花友中心 ============
function renderMember(){
  let h=`<div class="card"><div class="lbl">${S.code} · ${S.name} · ${S.tier}</div>
    <div class="stat-nums">
      <div><div class="n">${S.points_total}</div><div class="s">总积分</div></div>
      <div><div class="n">${S.points_pending}</div><div class="s">待审核</div></div>
      <div><div class="n">${availablePoints()}</div><div class="s">可用积分</div></div>
    </div></div>
    <div class="section-title">积分记录</div><div class="card">`;
  S.points_history.slice(0,8).forEach(p=>{
    h+=`<div class="list-item"><span>${p.reason} <span style="color:#AAB;font-size:10.5px">${p.date}</span></span>
      <span class="${p.change>=0?'pos':'neg'}">${p.change>=0?'+':''}${p.change}</span></div>`;
  });
  h+=`</div><div class="section-title">回馈金 <span class="pos">RM${S.rebate_total.toFixed(2)}</span></div><div class="card">`;
  S.rebate_batches.forEach(b=>{
    h+=`<div class="list-item"><span>${b.reason} <span style="color:#AAB;font-size:10.5px">${b.date}${b.exp?' · 至 '+b.exp:''}</span></span>
      <span class="${b.amount>=0?'pos':'neg'}">${b.amount>=0?'+':''}RM${Math.abs(b.amount).toFixed(2)}
      ${b.status==='available'?'<span class="tag-avail">可用</span>':'<span class="tag-exp">已用</span>'}</span></div>`;
  });
  h+=`</div>
    <div class="card" style="text-align:center">
      <button class="btn-main" onclick="go('task')">查看今日任务</button>
    </div>`;
  document.getElementById("member-content").innerHTML=h;
}

// ============ 任務 ============
function renderTask(){
  const done=S.task_done;
  let h=`<div class="card"><div class="lbl">今日已得</div>
    <div style="font-size:25px;font-weight:700;color:#5E8A45">${S.today_points} / ${DAILY_LIMIT} 分</div></div>
    <div class="card">`;
  const rows=[
    ["game_login","每日登入",2,done.game_login,TASK_LIMIT.game_login],
    ["plant_care","照顾植物",1,done.plant_care,TASK_LIMIT.plant_care],
    ["game_quiz","答对问答",5,done.game_quiz,TASK_LIMIT.game_quiz],
    ["plant_photo","分享植物",10,done.plant_photo,TASK_LIMIT.plant_photo],
  ];
  rows.forEach(([k,n,pt,d,l])=>{
    const full=d>=l;
    h+=`<div class="task-item"><span class="${full?'task-done':'task-todo'}">${full?'✓':'○'} ${n}</span>
      <span class="${full?'task-done':'task-todo'}">${d}/${l} · +${pt}</span></div>`;
  });
  h+=`</div><div class="card"><div class="lbl">连续观察</div>
    <div style="font-size:20px;font-weight:700;color:#5E8A45">${S.consecutive} 天</div>
    <div style="font-size:11.5px;color:#889;margin-top:4px">每连续 7 天 +20 分（不重叠周期）</div></div>`;
  document.getElementById("task-content").innerHTML=h;
}

// ============ 管理者 ============
function renderAdmin(){
  let h=`<div class="card"><div class="lbl">管理者模式</div>
    <div style="font-size:12.5px;color:#5B6B57;line-height:1.7">可查看任何会员的花园（只读诊断），或建立独立测试花园（不影响真实会员数据）。</div></div>
    <div class="section-title">会员花园（只读）</div>
    <div class="card"><div class="list-item"><span>XT-0001 enabelle</span><button class="btn-sm" onclick="toast('只读查看')">查看</button></div>
      <div class="list-item"><span>XT-0025 Kitty yws</span><button class="btn-sm" onclick="toast('只读查看')">查看</button></div>
      <div class="list-item"><span>XT-0017 Phyllis Tan</span><button class="btn-sm" onclick="toast('只读查看')">查看</button></div></div>
    <div class="section-title">测试花园</div>
    <div class="card"><div class="list-item"><span>我的测试花园</span><button class="btn-sm" onclick="toast('已进入测试花园（模拟，不扣真实积分）')">进入</button></div>
      <div class="list-item"><span>孩子的花园</span><button class="btn-sm" onclick="toast('已进入（模拟）')">进入</button></div></div>
    <div class="card" style="text-align:center"><button class="btn-main" onclick="go('garden')">回到我的花园</button></div>`;
  document.getElementById("admin-content").innerHTML=h;
}

// ============ 積分 ============
function addPoints(n,reason){
  if(S.today_points >= DAILY_LIMIT){ toast("今日积分已达上限（25 分）"); return; }
  const real = Math.min(n, DAILY_LIMIT - S.today_points);
  S.points_total += real;
  S.today_points += real;
  S.points_history.unshift({date:"今天",reason:reason,change:real});
}
// ============ 啟動 ============
renderApp();
