#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""心田營運儀表板 — 後端 API"""
import os, json, sqlite3, io, csv
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Form, Body, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import sys as _sys, os as _os, importlib.util as _ilu
_here = _os.path.dirname(_os.path.abspath(__file__))
_spec = _ilu.spec_from_file_location("analyze", _os.path.join(_here, "analyze.py"))
analyze = _ilu.module_from_spec(_spec); _spec.loader.exec_module(analyze)

BASE = os.path.dirname(os.path.abspath(__file__))
DB   = os.path.join(BASE, "..", "data", "ops.db")
FRONT= os.path.join(BASE, "..", "frontend")

app = FastAPI(title="心田營運儀表板")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS uploads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT, period_start TEXT, period_end TEXT,
      created_at TEXT, summary TEXT, raw TEXT);
    CREATE TABLE IF NOT EXISTS cost_map (
      product TEXT PRIMARY KEY, unit_cost REAL, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, date TEXT,
      amount REAL, note TEXT, sku TEXT, created_at TEXT);
    """)
    c.commit(); c.close()

init_db()

DEFAULT_SETTINGS = {
    "fixed_cost": "15350",
    "fixed_items": json.dumps([
        {"name":"租金","amount":2800},{"name":"Wifi","amount":300},
        {"name":"軟件","amount":500},{"name":"水電","amount":500},
        {"name":"薪資","amount":6000},{"name":"Ulive","amount":300},
        {"name":"承擔免郵運費","amount":1500},{"name":"廣告費","amount":3000},
        {"name":"包裝","amount":450},
    ], ensure_ascii=False),
}

@app.get("/api/settings")
def get_settings():
    c = db()
    out = {}
    for k, dv in DEFAULT_SETTINGS.items():
        row = c.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone()
        out[k] = row["value"] if row else dv
    c.close()
    out["fixed_items"] = json.loads(out.get("fixed_items") or "[]")
    return out

@app.post("/api/settings")
def save_settings(payload: dict = Body(...)):
    c = db()
    if "fixed_cost" in payload:
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_cost',?)", (str(payload["fixed_cost"]),))
    if "fixed_items" in payload:
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_items',?)",
                  (json.dumps(payload["fixed_items"], ensure_ascii=False),))
        total = sum(float(i.get("amount",0)) for i in payload["fixed_items"])
        c.execute("INSERT OR REPLACE INTO settings VALUES('fixed_cost',?)", (str(total),))
    c.commit(); c.close()
    return {"ok": True}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    raw = (await file.read()).decode("utf-8-sig", errors="ignore")
    # 載入成本對照
    _c = db()
    _rows = _c.execute("SELECT product, unit_cost FROM cost_map").fetchall()
    _c.close()
    cost_map = {r["product"]: r["unit_cost"] for r in _rows}
    parsed = analyze.parse_csv(raw, cost_map)
    if not parsed:
        raise HTTPException(400, "無法解析 CSV")
    c = db()
    row = c.execute("SELECT value FROM settings WHERE key='fixed_cost'").fetchone()
    fixed = float(row["value"]) if row else 15350.0
    s = analyze.summarize(parsed, fixed)

    dates = [o["date"] for o in parsed["orders"] if o.get("date")]
    p_start, p_end = (min(dates) if dates else ""), (max(dates) if dates else "")
    c.execute("""INSERT INTO uploads (filename, period_start, period_end, created_at, summary, raw)
                 VALUES (?,?,?,?,?,?)""",
              (file.filename, p_start, p_end, datetime.now().isoformat(),
               json.dumps(s, ensure_ascii=False), raw[:200000]))
    c.commit(); c.close()
    return {"ok": True, "summary": s, "period": [p_start, p_end]}

@app.get("/api/latest")
def latest():
    c = db()
    row = c.execute("SELECT * FROM uploads ORDER BY id DESC LIMIT 1").fetchone()
    c.close()
    if not row: return {"ok": True, "summary": None}
    return {"ok": True, "summary": json.loads(row["summary"]),
            "filename": row["filename"], "created_at": row["created_at"]}

@app.get("/api/uploads")
def uploads_list():
    c = db()
    rows = c.execute("SELECT id,filename,period_start,period_end,created_at FROM uploads ORDER BY id DESC LIMIT 50").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}


# ── 商品成本對照（補填漏成本）──
@app.get("/api/costs")
def get_costs():
    c = db()
    rows = c.execute("SELECT product, unit_cost FROM cost_map").fetchall()
    c.close()
    return {"ok": True, "items": {r["product"]: r["unit_cost"] for r in rows}}

@app.post("/api/costs")
def save_costs(payload: dict = Body(...)):
    """payload: {"items": [{"product": "...", "unit_cost": 12.5}, ...]}"""
    c = db()
    for it in payload.get("items", []):
        prod = (it.get("product") or "").strip()
        if not prod: continue
        c.execute("""INSERT INTO cost_map (product, unit_cost, updated_at) VALUES (?,?,?)
                     ON CONFLICT(product) DO UPDATE SET unit_cost=excluded.unit_cost, updated_at=excluded.updated_at""",
                  (prod, float(it.get("unit_cost", 0)), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True, "n": len(payload.get("items", []))}

@app.get("/api/missing-costs")
def missing_costs():
    """從最新上傳中，找出漏成本的商品"""
    c = db()
    row = c.execute("SELECT summary FROM uploads ORDER BY id DESC LIMIT 1").fetchone()
    c.close()
    if not row: return {"ok": True, "items": []}
    s = json.loads(row["summary"])
    return {"ok": True, "items": s.get("missing_cost", []),
            "skus": [{"name": t.get("name"), "sku": t.get("sku")} for t in s.get("top_skus", [])]}

# ── 支出（植物死亡 / 退款 / 額外採購）──
@app.get("/api/expenses")
def expenses(kind: str = None):
    c = db()
    if kind:
        rows = c.execute("SELECT * FROM expenses WHERE kind=? ORDER BY id DESC", (kind,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 200").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.post("/api/expenses")
def add_expense(payload: dict = Body(...)):
    c = db()
    c.execute("""INSERT INTO expenses (kind,date,amount,note,sku,created_at)
                 VALUES (?,?,?,?,?,?)""",
              (payload.get("kind","other"), payload.get("date",""),
               float(payload.get("amount",0)), payload.get("note",""),
               payload.get("sku",""), datetime.now().isoformat()))
    c.commit(); c.close()
    return {"ok": True}

@app.delete("/api/expenses/{eid}")
def del_expense(eid: int):
    c = db(); c.execute("DELETE FROM expenses WHERE id=?", (eid,)); c.commit(); c.close()
    return {"ok": True}

@app.get("/api/expenses/summary")
def expenses_summary():
    c = db()
    rows = c.execute("SELECT kind, SUM(amount) amt, COUNT(*) n FROM expenses GROUP BY kind").fetchall()
    c.close()
    return {"ok": True, "items": [dict(r) for r in rows]}

@app.get("/health")
def health(): return {"ok": True, "service": "xintian-ops"}

# 前端靜態檔
if os.path.isdir(FRONT):
    app.mount("/", StaticFiles(directory=FRONT, html=True), name="front")
