/**
 * 心田月季目錄 — 資料檔
 * 新增品種：在對應分類的 varieties 陣列裡加一筆。
 * 新增分類：複製一個 category 物件，改 id / label / en / desc。
 *
 * 欄位：
 *   name  英文品種名（必填）
 *   zh    中文名（可空字串）
 *   color 花色描述（必填）
 *   hex   花色色碼（必填，例 #E88498）
 *   form  花型與大小
 *   notes 香氣、抗病、特性
 *   flag  特殊提醒（例：名稱待核對）
 */

window.XINTIAN_ROSES = {
  updated: "2026-11-04",
  categories: [
    {
      id: "climbing",
      label: "藤本月季",
      en: "Climbing Roses",
      desc: "枝條長、可牵引上架，適合拱門、圍籬與牆面。",
      varieties: [
        { name: "James Galway", img: "images/james-galway.jpg", zh: "詹姆斯·高威", color: "淺粉，中心深粉", hex: "#F2BCCB", form: "重瓣蓮座型 · 中花", notes: "David Austin 藤本 · 幾乎無刺 · 香味濃" },
        { name: "Jerry Jenning", img: "images/jerry-jenning.jpg", zh: "傑里·詹寧斯（Jerry Jennings）", color: "金黃／橙黃，後轉淺黃奶油", hex: "#EFA83C", form: "重瓣古典杯型 · 中小花（約5cm）· 成簇爆花", notes: "極強麝香蜂蜜香 · 勤花 · 抗病 · 耐雨 · 易打理" },
        { name: "Sally Holmes", img: "images/sally-holmes.jpg", zh: "莎莉·霍姆斯", color: "白，花蕊金黃", hex: "#FCFAF3", form: "單瓣 · 大花", notes: "成串開 · 非常強健 · 幾乎不生病 · 可作藤本" },
        { name: "Kew Gardens", img: "images/kew-gardens.jpg", zh: "邱園", color: "純白，花蕊黃", hex: "#FBF8F0", form: "單瓣 · 中花", notes: "David Austin · 花量極多 · 幾乎不生病 · 可作小藤本" },
        { name: "Evelyn", img: "images/evelyn.jpg", zh: "伊芙琳", color: "杏桃／蜜桃橙", hex: "#F0A87E", form: "重瓣杯型 · 大花", notes: "David Austin · 濃郁果香 · 花型工整" },
        { name: "Charles Darwin", img: "images/charles-darwin.jpg", zh: "查理斯·達爾文", color: "蜜黃轉奶油黃", hex: "#EFD48A", form: "重瓣 · 大花", notes: "David Austin · 濃香 · 花朵巨大" },
        { name: "Abraham Darby", img: "images/abraham-darby.jpg", zh: "亞伯拉罕·達比", color: "杏桃粉漸層", hex: "#E89A7C", form: "重瓣杯型 · 大花", notes: "David Austin · 濃果香 · 杏桃粉漸層" },
        { name: "Constance", img: "images/constance.jpg", zh: "康斯坦絲", color: "粉紅，內瓣較深", hex: "#E88AA0", form: "重瓣球型 · 中花", notes: "David Austin · 濃香 · 粉色漸層" },
        { name: "Soeur Emmanuelle", img: "images/soeur-emmanuelle.jpg", zh: "艾曼紐修女", color: "粉紅，瓣背偏白", hex: "#F0A6B6", form: "重瓣 · 中花", notes: "德系 · 強香 · 粉紅瓣背白" },
        { name: "Marie Antoinette", img: "images/marie-antoinette.jpg", zh: "瑪麗·安東妮", color: "粉白，外瓣淡綠白", hex: "#F6E3DE", form: "重瓣杯型 · 大花", notes: "Delbard 法系 · 香濃 · 粉白外瓣淡綠" },
        { name: "Moulin de la Galette", img: "images/moulin-de-la-galette.jpg", zh: "煎餅磨坊", color: "粉橙／珊瑚橙", hex: "#EE9C77", form: "重瓣 · 中花", notes: "Delbard 法系 · 香氣濃 · 粉橙珊瑚色" },
        { name: "Heaven on Earth", img: "images/heaven-on-earth.jpg", zh: "天堂", color: "淺杏／奶油白", hex: "#F4E2C8", form: "重瓣 · 中花", notes: "淡雅香氣 · 杏白漸層 · 花期長" },
        { name: "Kordes Jubilee", img: "images/kordes-jubilee.jpg", zh: "科德斯禧年", color: "杏黃／橙黃", hex: "#EFA95E", form: "重瓣杯型 · 大花", notes: "Kordes 德系 · 強香 · 百瓣以上" },
        { name: "Augusta Louise", img: "images/augusta-luise.jpg", zh: "奧古斯塔·路易絲", color: "杏色轉奶油", hex: "#F2C08A", form: "重瓣 · 大花", notes: "Tantau 德系 · 強香 · 杏色轉奶油" },
        { name: "Romantic Tutu", img: "images/romantic-tutu.jpg", zh: "浪漫芭蕾舞裙", color: "淺粉，邊緣偏白", hex: "#F5C6D2", form: "重瓣球狀 · 中花", notes: "瓣數多 · 強香 · 花型圓潤" },
        { name: "Charles de Nervaux", img: "images/charles-de-nervaux.jpg", zh: "查爾斯·德·內爾沃", color: "乳白帶檸檬白", hex: "#F3EDD6", form: "半重瓣波浪瓣 · 中花", notes: "Guillot 法系 · 淡香至中香 · 耐熱耐雨" }
      ]
    },
    {
      id: "shrub",
      label: "灌木月季",
      en: "Shrub & English Roses",
      desc: "株型飽滿，適合花圃中央與盆栽，多數香味濃郁。",
      varieties: [
        { name: "Kate", img: "images/kate.jpg", zh: "凱特", color: "深粉紅，外瓣較淺", hex: "#D96B86", form: "重瓣深杯型 · 大花", notes: "David Austin 切花系 · 濃香 · 插瓶持久" },
        { name: "Othello", img: "images/othello.jpg", zh: "奧賽羅", color: "深紅轉紫紅", hex: "#8E2C46", form: "重瓣深杯型 · 大花", notes: "古典英系 · 強香 · 深紅轉紫紅" },
        { name: "The Poet's Wife", img: "images/the-poets-wife.jpg", zh: "詩人之妻", color: "蜜黃／奶油黃", hex: "#F2D07E", form: "重瓣 · 中花", notes: "David Austin · 強香 · 蜜黃奶油黃" },
        { name: "Amandine Chanel", img: "images/amandine-chanel.jpg", zh: "阿曼丁·香奈兒", color: "深紅天鵝絨", hex: "#8C1F2E", form: "重瓣 · 大花", notes: "Delbard 法系 · 濃香 · 深紅天鵝絨" },
        { name: "Parfum de Paris", img: "images/parfum-de-paris.jpg", zh: "巴黎香水", color: "紫粉／洋紅粉", hex: "#C06080", form: "重瓣 · 中花", notes: "Delbard 法系 · 強香 · 紫粉洋紅" },
        { name: "Henri Delbard", img: "images/henri-delbard.jpg", zh: "亨利·德爾巴", color: "粉紅帶條紋色暈", hex: "#E88CA4", form: "重瓣 · 大花", notes: "Delbard 法系 · 濃香 · 粉紅帶條紋色暈" },
        { name: "Julie Andrieu", img: "images/julie-andrieu.jpg", zh: "茱莉·安德里厄", color: "粉紅，中心偏杏", hex: "#F0A9B8", form: "重瓣 · 中花", notes: "Delbard 法系 · 成簇開 · 香氣溫和" }
      ]
    },
    {
      id: "floribunda",
      label: "豐花月季",
      en: "Floribunda & Polyantha",
      desc: "一株多花、花量驚人，適合初學者與大面積種植。",
      varieties: [
        { name: "Pink Drift", img: "images/pink-drift.jpg", zh: "粉紅漂流", color: "珊瑚粉，中心較深", hex: "#E88498", form: "半重瓣至重瓣 · 小花", notes: "矮叢噴泉型 · 四季開花 · 抗病力強 · 非藤本", flag: "非藤本" },
        { name: "Red Drift", img: "images/red-drift.jpg", zh: "深紅漂流", color: "深紅偏朱", hex: "#C1272D", form: "半重瓣 · 小花", notes: "矮叢噴泉型 · 四季開花 · 抗病力強 · 非藤本", flag: "非藤本" },
        { name: "Out of Rosenheim", img: "images/out-of-rosenheim.jpg", zh: "羅森海姆", color: "深紅偏緋", hex: "#B32B3A", form: "半重瓣至重瓣 · 中花", notes: "Kordes 德系 · 耐熱 · 花量多 · 抗病" },
        { name: "Sweet Pretty", img: "images/sweet-pretty.jpg", zh: "甜蜜美人", color: "粉紅，瓣背偏淺", hex: "#F2AEC0", form: "半重瓣 · 中花", notes: "Meilland 法系 · 淡粉 · 抗病佳" },
        { name: "Cepheus", img: "images/cepheus.jpg", zh: "仙王座", color: "橙紅／朱紅", hex: "#E0553A", form: "半重瓣 · 中花", notes: "橙紅朱紅 · 成簇開 · 花量多" },
        { name: "Plume White", img: "images/plume.jpg", zh: "白羽", color: "純白／乳白", hex: "#FAF7EE", form: "重瓣 · 中花", notes: "日系庭園月季 · 純白乳白 · 花型柔和" },
        { name: "Plume Pink", img: "images/plume-pink.jpg", zh: "粉羽", color: "淺粉／玫瑰粉", hex: "#F3B8C6", form: "重瓣 · 中花", notes: "日系庭園月季 · 淺粉玫瑰粉 · 花型柔和" },
        { name: "Peachy Bonbons", img: "images/peachy-bonbons.jpg", zh: "蜜桃糖果", color: "蜜桃橙／杏橘", hex: "#F4A97B", form: "重瓣 · 中花", notes: "甜香 · 蜜桃橙杏橘 · 成簇開" },
        { name: "Petty Kiss", img: "images/petty-kiss.jpg", zh: "美麗的吻（Pretty Kiss）", color: "雪白瓣、邊緣暈染深粉至胭脂紅（雙色）", hex: "#F6D7E0", form: "單瓣（4–8瓣）· 大花 7–10cm · 一莖多花", notes: "橙黃雄蕊外露 · 淡清香 · 勤花耐雨 · 抗病耐寒" }
      ]
    },
    {
      id: "hybrid",
      label: "雜交茶香月季",
      en: "Hybrid Tea & Others",
      desc: "大花、單枝單朵，切花首選。",
      varieties: [
        { name: "Monalisa", img: "images/monalisa.jpg", zh: "蒙娜麗莎", color: "深紅天鵝絨", hex: "#9B1B2A", form: "重瓣 · 大花", notes: "切花品種 · 花型端正 · 插瓶持久" },
        { name: "Capri", img: "images/capri.jpg", zh: "卡布里", color: "深黃，瓣邊偏淺", hex: "#F0C233", form: "重瓣 · 中花", notes: "荷系 · 深黃 · 成簇開" },
        { name: "Eisvogel", img: "images/eisvogel.jpg", zh: "翠鳥", color: "深紅偏藍紅", hex: "#A82735", form: "半重瓣 · 中花", notes: "德系老品種 · 耐寒 · 深紅偏藍紅" },
        { name: "Cartonnage", img: "images/cartonnage.jpg", zh: "卡特納日", color: "淺粉帶杏黃暈", hex: "#F2C6B4", form: "半重瓣 · 中花", notes: "Guillot 法系 · 成簇開 · 溫和果香", flag: "名稱待核對" },
        { name: "Bishop", img: "images/bishop.jpg", zh: "主教城堡（Bishop's Castle）", color: "覆盆子粉紅（深而純）", hex: "#C9557A", form: "重瓣老月季杯型 · 中花 7–10cm · 約80瓣 · 紐扣眼中心", notes: "濃郁古典老月季強香 · 抗病佳 · 耐熱" },
        { name: "Le Temps des Cerises", img: "images/le-temps-des-cerises.jpg", zh: "櫻桃時光", color: "洋紅／櫻桃紅", hex: "#C0392B", form: "重瓣 · 中花", notes: "洋紅櫻桃紅 · 成簇開 · 花量多", flag: "名稱待核對" },
        { name: "Masora", img: "images/masora.jpg", zh: "真宙（Masora）", color: "杏粉（春）／檸檬粉（夏），中心較深", hex: "#F0B8B0", form: "重瓣杯狀古典型 · 中至大花（8–10cm）", notes: "日系灌木 · 100–150瓣 · 柑橘熱帶果香 · 極耐熱 · 抗病強 · 可灌木可藤本" }
      ]
    },
    {
      id: "purple",
      label: "紫色系列",
      en: "Purple Collection",
      desc: "紫、藍紫、梅子紫系月季。色澤隨溫度與花期變化，越冷越紫。",
      varieties: [
        { name: "Minerva", img: "images/minerva.jpg", zh: "米涅瓦", color: "紫紅／洋紅，瓣背銀紫", hex: "#8E4B7A", form: "重瓣 · 中花 · 成簇開", notes: "Delbard 法系 · 濃香 · 花量多 · 抗病佳" },
        { name: "Midnight Blue", img: "images/midnight-blue.jpg", zh: "午夜深藍", color: "深紫／紫絨，中心帶藍調", hex: "#4A2E5C", form: "半重瓣至重瓣 · 中花", notes: "濃郁香料香 · 灌木 · 耐熱 · 花朵較小但成簇" },
        { name: "Twilight Zone", img: "images/twilight-zone.jpg", zh: "暮光之城", color: "深紫天鵝絨，近乎紫黑", hex: "#3D2447", form: "重瓣 · 中至大花", notes: "極濃香（香料＋丁香）· Grandiflora · 植株強健" },
        { name: "Le Temps des Cerises", img: "images/le-temps-des-cerises.jpg", zh: "櫻桃時光", color: "洋紅／櫻桃紅", hex: "#C0392B", form: "重瓣 · 中花", notes: "成簇開 · 花量多 · 亦屬藤本系列" },
        { name: "Sweet Chariot", img: "images/sweet-chariot.jpg", zh: "甜蜜戰車", color: "紫／薰衣草紫，瓣背偏白", hex: "#9B7BB0", form: "重瓣 · 小花（迷你型）", notes: "Ralph Moore · 濃香 · 適合盆栽與小空間" },
        { name: "Ebb Tide", img: "images/ebb-tide.jpg", zh: "退潮", color: "深紫／梅子紫，帶煙燻調", hex: "#4B2C4F", form: "重瓣 · 中花", notes: "極濃香（丁香＋香料）· 豐花 · 花期長" },
        { name: "Vineyard Song", img: "images/vineyard-song.jpg", zh: "葡萄園之歌", color: "紫紅／紫玫瑰，瓣背偏銀", hex: "#A85C86", form: "重瓣 · 中花 · 成簇開", notes: "Ralph Moore · 香味獨特（果香帶酒香）· 抗病" },
        { name: "Blue for You", img: "images/blue-for-you.jpg", zh: "為你而藍", color: "藍紫／灰藍，中心偏紫", hex: "#7A82B8", form: "半重瓣 · 中花 · 花量極多", notes: "David Austin 豐花 · 香味淡雅 · 幾乎不生病" },
        { name: "Rinaldo", img: "images/rinaldo.jpg", zh: "聖十字軍（Rinaldo）", color: "深紫，初開偏粉紅後轉深紫灰紫", hex: "#6B3A63", form: "重瓣古典杯型至平盤 · 中小花 6–8cm · 成簇開", notes: "瓣背銀白形成雙面感 · 中等錦緞茶香 · 多頭勤花" }
      ]
    },
    {
      id: "babylon",
      label: "巴比倫系列",
      en: "Babylon Collection",
      desc: "Rosa persica 血統的「眼」系列 —— 花瓣中央有明顯深色眼斑，單瓣至半重瓣，耐熱抗病。",
      varieties: [
        { name: "Eridu Babylon", img: "images/eridu-babylon.jpg", zh: "埃里都巴比倫", color: "粉白，中心深紅眼", hex: "#F0C4CE", form: "單瓣至半重瓣 · 中花 · 花瓣波浪", notes: "Rosa persica 血統 · 眼斑明顯 · 耐熱 · 抗病強" },
        { name: "Sunset Babylon", img: "images/sunset-babylon.jpg", zh: "日落巴比倫", color: "橙黃至杏橘，中心深紅眼", hex: "#F2A05E", form: "單瓣至半重瓣 · 中花", notes: "眼系列 · 花色隨溫度變化 · 花量多 · 耐熱" },
        { name: "Eye Tiger", img: "images/eye-tiger.jpg", zh: "虎眼", color: "金黃，中心深紅眼斑", hex: "#EFB93E", form: "單瓣 · 中花", notes: "Harkness · Rosa persica 血統 · 香氣濃 · 花型特別" },
        { name: "Eyes for You", img: "images/eyes-for-you.jpg", zh: "眼中只有你", color: "粉紫，中心深紫眼", hex: "#C88FC0", form: "半重瓣 · 中花 · 成簇開", notes: "Harkness 2008 · 香氣濃 · 眼系列代表作 · 抗病佳" },
        { name: "Amethyst Babylon", img: "images/amethyst-babylon.jpg", zh: "紫晶巴比倫", color: "紫／淡紫，中心深紫眼", hex: "#A98BC0", form: "單瓣至半重瓣 · 中花", notes: "眼系列 · 紫色系 · 耐熱抗病 · 小花成簇" }
      ]
    },
    {
      id: "single",
      label: "單瓣系列",
      en: "Single Petal Roses",
      desc: "單瓣或半重瓣，花瓣少、花蕊外露，花量通常極大，給人清爽自然感。",
      varieties: [
        { name: "Jantharika", img: "images/jantharika.jpg", zh: "詹塔莉卡（Chantrika）", color: "粉白相間，粉瓣白邊漸層", hex: "#F2CBD8", form: "單瓣至半重瓣 · 中花 · 成簇爆花", notes: "微型／半藤本 · 花量極大 · 耐熱耐曬 · 幾近無刺 · 淡香" },
        { name: "The Flowering Spirit of Yamabuki", img: "images/yamabuki-spirit.jpg", zh: "棣棠之靈（山吹）", color: "明黃／鮮明亮黃", hex: "#F2C51E", form: "單瓣 · 中花 · 成簇群開", notes: "柔和微香（帶雪碧與蜂蜜氣息）· 四季開花 · 強健抗病" },
        { name: "Lotus Star", img: "images/lotus-star.jpg", zh: "天荷繁星", color: "淡粉至深粉", hex: "#F2B6C6", form: "半重瓣 · 花瓣微尖 · 成簇開", notes: "株高 30–50cm · 微開似荷花、全開如繁星 · 淡雅清香" },
        { name: "Starry Sky", img: "images/starry-sky.jpg", zh: "星空", color: "淡粉腮紅，花蕊金黃", hex: "#F5D5DC", form: "單瓣 · 中小花 · 花量極多", notes: "Kordes（Korhubkah）· 矮叢 · 抗病力強" },
        { name: "Popcorn", img: "images/popcorn.jpg", zh: "爆米花", color: "純白，中心黃蕊", hex: "#FBF9F2", form: "半重瓣 · 迷你小花 · 成簇開", notes: "Popcorn Drift 系列 · 矮叢 · 四季開花 · 抗病" },
        { name: "Yametsuhime", img: "images/yametsuhime.jpg", zh: "八女津姫", color: "深粉至紫粉", hex: "#D96A93", form: "半重瓣 · 中花 · 成簇開", notes: "日本育種 · 花形工整 · 四季開花" },
        { name: "Azumino", img: "images/azumino.jpg", zh: "安曇野", color: "淺粉至白色", hex: "#F5DCE2", form: "單瓣 · 中花", notes: "日本長野育種 · 清雅柔和 · 抗病" },
        { name: "Wedding Day", img: "images/wedding-day.jpg", zh: "婚禮日", color: "純白，花蕊金黃", hex: "#FCFBF6", form: "單瓣 · 中花 · 成串開", notes: "Kordes 1950 藤本 · 花量驚人 · 香味濃 · 強健" },
        { name: "Rose Baby Love", img: "images/baby-love.jpg", zh: "寶貝之愛", color: "明黃，中心深黃", hex: "#F5C93A", form: "單瓣 · 小花 · 花量極多", notes: "Scrivens 1992 · 抗病極強 · 適合盆栽與小空間" },
        { name: "Otto Linne", img: "images/otto-linne.jpg", zh: "奧托·林內", color: "珊瑚粉至淺粉，中心偏白", hex: "#F0A9B4", form: "單瓣至半重瓣 · 小花 · 成簇開", notes: "Kordes 1939 矮叢多花 · 花量爆發 · 耐病" },
        { name: "Gloire du Midi", img: "images/gloire-du-midi.jpg", zh: "午後榮耀", color: "明亮橙紅至橙色（Orange-scarlet），中心金黃蕊", hex: "#E8622C", form: "半重瓣至重瓣球狀 · 小花 3–5cm · 大簇群開", notes: "紅與橙自然融合 · 淡溫和微香 · 後期光照下略褪色 · 矮叢多花" },
        { name: "Green Ice", img: "images/green-ice.jpg", zh: "綠冰", color: "白帶淡粉，後轉淡綠白", hex: "#E8F0E2", form: "重瓣 · 迷你小花", notes: "Ralph Moore · 花色會「變綠」· 耐熱抗病" },
        { name: "Hohoemi", img: "images/hohoemi.jpg", zh: "微笑（ほほえみ）", color: "粉紅至深粉，中心偏白", hex: "#EE9BB2", form: "半重瓣 · 迷你小花", notes: "日本迷你品種 · 耐熱 · 花量多 · 適合盆栽" }
      ]
    }
  ]
};
