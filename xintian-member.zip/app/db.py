# -*- coding: utf-8 -*-
"""心田花友俱樂部 — 資料庫層"""
import sqlite3, os, re
from datetime import datetime, date, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "xintian.db")

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_conn(); c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS members (
        member_id INTEGER PRIMARY KEY AUTOINCREMENT, member_code TEXT UNIQUE,
        name TEXT NOT NULL, phone TEXT, fb_name TEXT, tg_id TEXT, email TEXT,
        birthday TEXT, tier TEXT NOT NULL DEFAULT 'friend', status TEXT NOT NULL DEFAULT 'active',
        join_date TEXT NOT NULL, expiry_date TEXT, is_free_trial INTEGER NOT NULL DEFAULT 0,
        referrer_code TEXT, total_spend REAL NOT NULL DEFAULT 0, points INTEGER NOT NULL DEFAULT 0,
        rebate REAL NOT NULL DEFAULT 0, note TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS points_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL,
        change INTEGER NOT NULL, reason TEXT NOT NULL, ref TEXT, created_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS rebate_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL,
        change REAL NOT NULL, reason TEXT NOT NULL, ref TEXT, expires_at TEXT, created_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS orders (
        order_no TEXT PRIMARY KEY, purchase_date TEXT, status TEXT, buyer_name TEXT,
        buyer_fb_name TEXT, buyer_contact TEXT, recipient TEXT, ship_method TEXT, source TEXT,
        total_amount REAL NOT NULL DEFAULT 0, member_id INTEGER, match_type TEXT,
        is_pending INTEGER NOT NULL DEFAULT 0, points_given INTEGER NOT NULL DEFAULT 0,
        rebate_given REAL NOT NULL DEFAULT 0, imported_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS aliases (
        id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL,
        alias TEXT NOT NULL, alias_norm TEXT NOT NULL, source TEXT, created_at TEXT NOT NULL)""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_alias_norm ON aliases(alias_norm)")
    c.execute("""CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL,
        amount REAL NOT NULL, months INTEGER NOT NULL DEFAULT 1, pay_date TEXT NOT NULL,
        method TEXT, kind TEXT, note TEXT, created_at TEXT NOT NULL)""")
    c.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    for k, v in {"monthly_fee":"20","free_trial_threshold":"50","rebate_rate":"0.15",
                 "rebate_min_order":"30","rebate_max_ratio":"0.5","rebate_expire_days":"60"}.items():
        c.execute("INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)", (k, v))
    conn.commit(); conn.close()

def normalize_phone(p):
    if not p: return None
    p = re.sub(r"[\s\-\(\)]", "", str(p))
    if p in ("-","","+"): return None
    if p.startswith("+"): return p
    if p.startswith("60"): return "+" + p
    if p.startswith("0"): return "+6" + p
    if p.isdigit():
        if len(p) in (9,10): return "+60" + p
        if len(p) == 11: return "+6" + p
    return "+60" + p

def norm_name(s):
    if not s: return ""
    s = str(s).lower().strip()
    s = re.sub(r"[\(（].*?[\)）]", "", s)
    return re.sub(r"[^\w\u4e00-\u9fff]", "", s)

def name_tokens(s):
    if not s: return set()
    s = str(s).lower()
    s = re.sub(r"[\(（].*?[\)）]", "", s)
    s = re.sub(r"[^\w\u4e00-\u9fff]", " ", s)
    return {x for x in s.split() if len(x) >= 2}

def next_member_code():
    conn = get_conn()
    n = conn.execute("SELECT COUNT(*) n FROM members").fetchone()["n"]
    conn.close()
    return f"XT-{(n+1):04d}"

def create_member(name, phone=None, fb_name=None, tg_id=None, tier="friend", months=1,
                  birthday=None, email=None, note=None, expiry_override=None, status="active",
                  join_date=None):
    conn = get_conn()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    today = date.today()
    code = next_member_code()
    expiry = expiry_override
    if expiry is None and tier not in ("vip","elder"):
        expiry = (today + timedelta(days=30*months)).strftime("%Y-%m-%d")
    try:
        cur = conn.execute("""INSERT INTO members
            (member_code,name,phone,fb_name,tg_id,email,birthday,tier,status,join_date,
             expiry_date,is_free_trial,note,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (code,name,phone,fb_name,tg_id,email,birthday,tier,status,
             join_date or today.strftime("%Y-%m-%d"), expiry,
             1 if tier=="friend" else 0, note, now, now))
        conn.commit()
        return {"ok": True, "member_id": cur.lastrowid, "member_code": code}
    except sqlite3.IntegrityError as e:
        return {"ok": False, "error": str(e)}
    finally:
        conn.close()

def find_member_by_identity(phone=None, fb_name=None, tg_id=None):
    conn = get_conn(); m = None
    if tg_id:
        m = conn.execute("SELECT * FROM members WHERE tg_id=?", (tg_id,)).fetchone()
    if not m and phone:
        m = conn.execute("SELECT * FROM members WHERE phone=?", (normalize_phone(phone),)).fetchone()
    if not m and fb_name:
        an = norm_name(fb_name)
        m = conn.execute("""SELECT m.* FROM aliases a JOIN members m ON a.member_id=m.member_id
            WHERE a.alias_norm=? LIMIT 1""", (an,)).fetchone()
    conn.close()
    return dict(m) if m else None

def get_member(mid):
    conn = get_conn()
    m = conn.execute("SELECT * FROM members WHERE member_id=?", (mid,)).fetchone()
    conn.close()
    return dict(m) if m else None

def list_members(tier=None, status=None):
    conn = get_conn()
    sql = "SELECT * FROM members WHERE 1=1"; args = []
    if tier: sql += " AND tier=?"; args.append(tier)
    if status: sql += " AND status=?"; args.append(status)
    sql += " ORDER BY member_id"
    rows = conn.execute(sql, args).fetchall(); conn.close()
    return [dict(r) for r in rows]

def add_points(mid, change, reason, ref=None):
    conn = get_conn(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("INSERT INTO points_log (member_id,change,reason,ref,created_at) VALUES (?,?,?,?,?)",
                 (mid,change,reason,ref,now))
    conn.execute("UPDATE members SET points=points+?, updated_at=? WHERE member_id=?", (change,now,mid))
    conn.commit(); conn.close()

def get_points_history(mid, limit=50):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM points_log WHERE member_id=? ORDER BY id DESC LIMIT ?", (mid,limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_setting(k, d=None):
    conn = get_conn()
    r = conn.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone()
    conn.close()
    return r["value"] if r else d

def calc_rebate(amount):
    return round(amount * float(get_setting("rebate_rate","0.15")), 2)

def add_rebate(mid, change, reason, ref=None, expire_days=None):
    conn = get_conn(); now = datetime.now()
    now_s = now.strftime("%Y-%m-%d %H:%M:%S"); exp = None
    if change > 0:
        exp = (now + timedelta(days=expire_days or int(get_setting("rebate_expire_days","60")))).strftime("%Y-%m-%d")
    conn.execute("INSERT INTO rebate_log (member_id,change,reason,ref,expires_at,created_at) VALUES (?,?,?,?,?,?)",
                 (mid,change,reason,ref,exp,now_s))
    conn.execute("UPDATE members SET rebate=rebate+?, updated_at=? WHERE member_id=?", (change,now_s,mid))
    conn.commit(); conn.close()

def get_rebate_history(mid, limit=50):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM rebate_log WHERE member_id=? ORDER BY id DESC LIMIT ?", (mid,limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_alias(mid, alias, source="manual"):
    conn = get_conn(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    an = norm_name(alias)
    if an:
        ex = conn.execute("SELECT id FROM aliases WHERE member_id=? AND alias_norm=?", (mid,an)).fetchone()
        if not ex:
            conn.execute("INSERT INTO aliases (member_id,alias,alias_norm,source,created_at) VALUES (?,?,?,?,?)",
                         (mid,alias,an,source,now))
            conn.commit()
    conn.close(); return True

def list_aliases(mid):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM aliases WHERE member_id=? ORDER BY id", (mid,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def suggest_member_matches(name, threshold=0.6, limit=5):
    if not name: return []
    target = name_tokens(name); tgt = norm_name(name)
    conn = get_conn()
    members = conn.execute("SELECT member_id,member_code,name,phone,fb_name FROM members").fetchall()
    aliases = conn.execute("SELECT member_id,alias FROM aliases").fetchall()
    conn.close()
    amap = {}
    for a in aliases: amap.setdefault(a["member_id"], []).append(a["alias"])
    out = []
    for m in members:
        mname = m["name"] or ""; mtok = name_tokens(mname); score = 0.0
        if tgt and tgt == norm_name(mname): score = 1.0
        elif target and mtok:
            inter = target & mtok
            if inter:
                score = len(inter)/max(len(target),len(mtok))
                if target.issubset(mtok) or mtok.issubset(target): score = max(score,0.85)
        for al in amap.get(m["member_id"], []):
            atok = name_tokens(al)
            if tgt and tgt == norm_name(al): score = max(score,1.0)
            elif target and atok:
                inter = target & atok
                if inter:
                    s2 = len(inter)/max(len(target),len(atok))
                    if target.issubset(atok) or atok.issubset(target): s2 = max(s2,0.85)
                    score = max(score,s2)
        if score >= threshold:
            out.append({"member_id":m["member_id"],"member_code":m["member_code"],"name":mname,
                        "phone":m["phone"],"fb_name":m["fb_name"],"score":round(score,3)})
    out.sort(key=lambda x:-x["score"])
    return out[:limit]

def mark_renewed(mid, months=1):
    conn = get_conn(); m = get_member(mid)
    if not m: conn.close(); return {"ok":False}
    base = date.today()
    if m["expiry_date"]:
        try:
            e = datetime.strptime(m["expiry_date"],"%Y-%m-%d").date()
            if e > base: base = e
        except ValueError: pass
    new_exp = (base + timedelta(days=30*months)).strftime("%Y-%m-%d")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("""UPDATE members SET expiry_date=?, status='active',
        tier=CASE WHEN tier='friend' THEN 'paid' ELSE tier END, is_free_trial=0, updated_at=?
        WHERE member_id=?""", (new_exp,now,mid))
    conn.commit(); conn.close()
    return {"ok":True,"expiry_date":new_exp}

def expiring_members(days_ahead=7):
    conn = get_conn(); today = date.today()
    target = (today+timedelta(days=days_ahead)).strftime("%Y-%m-%d")
    rows = conn.execute("""SELECT * FROM members WHERE expiry_date IS NOT NULL
        AND expiry_date>=? AND expiry_date<=? AND status='active' ORDER BY expiry_date""",
        (today.strftime("%Y-%m-%d"), target)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def record_payment(mid, amount, months=1, pay_date=None, method=None, kind="renew", note=None, extend=True):
    conn = get_conn(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pd = pay_date or date.today().strftime("%Y-%m-%d")
    conn.execute("""INSERT INTO payments (member_id,amount,months,pay_date,method,kind,note,created_at)
        VALUES (?,?,?,?,?,?,?,?)""", (mid,amount,months,pd,method,kind,note,now))
    conn.commit(); conn.close()
    if extend and months > 0: return mark_renewed(mid, months)
    return {"ok":True}

def get_payments(mid=None, month=None):
    conn = get_conn()
    if mid:
        rows = conn.execute("SELECT * FROM payments WHERE member_id=? ORDER BY pay_date DESC", (mid,)).fetchall()
    elif month:
        rows = conn.execute("""SELECT p.*,m.name,m.member_code FROM payments p
            JOIN members m ON p.member_id=m.member_id WHERE p.pay_date LIKE ? ORDER BY p.pay_date DESC""",
            (month+"%",)).fetchall()
    else:
        rows = conn.execute("""SELECT p.*,m.name,m.member_code FROM payments p
            JOIN members m ON p.member_id=m.member_id ORDER BY p.pay_date DESC LIMIT 200""").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def monthly_revenue(month=None):
    if not month: month = date.today().strftime("%Y-%m")
    conn = get_conn()
    row = conn.execute("""SELECT COUNT(*) n, COALESCE(SUM(amount),0) total, COALESCE(SUM(months),0) months
        FROM payments WHERE pay_date LIKE ?""", (month+"%",)).fetchone()
    nm = conn.execute("SELECT COUNT(*) n FROM members WHERE join_date LIKE ?", (month+"%",)).fetchone()["n"]
    rn = conn.execute("""SELECT COUNT(DISTINCT member_id) n FROM payments
        WHERE pay_date LIKE ? AND kind='renew'""", (month+"%",)).fetchone()["n"]
    conn.close()
    return {"month":month,"payment_count":row["n"],"revenue":round(row["total"],2),
            "months":row["months"],"new_members":nm,"renewals":rn}

def revenue_by_month(limit=12):
    conn = get_conn()
    rows = conn.execute("""SELECT substr(pay_date,1,7) month, COUNT(*) n, COALESCE(SUM(amount),0) total
        FROM payments GROUP BY month ORDER BY month DESC LIMIT ?""", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def upgrade_elders():
    conn = get_conn()
    cutoff = (date.today()-timedelta(days=365)).strftime("%Y-%m-%d")
    rows = conn.execute("""SELECT member_id,member_code,name,join_date FROM members
        WHERE tier='paid' AND join_date IS NOT NULL AND join_date<=?""", (cutoff,)).fetchall()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S"); up = []
    for r in rows:
        conn.execute("UPDATE members SET tier='elder', updated_at=? WHERE member_id=?", (now,r["member_id"]))
        up.append({"member_code":r["member_code"],"name":r["name"],"join_date":r["join_date"]})
    conn.commit(); conn.close()
    return up

def conversion_analysis(min_amount=0):
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(total_amount),0) s FROM orders").fetchone()
    mem = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(total_amount),0) s FROM orders WHERE member_id IS NOT NULL").fetchone()
    non = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(total_amount),0) s FROM orders WHERE member_id IS NULL").fetchone()
    wm = ""; args = []
    if min_amount and min_amount > 0: wm = " AND total_amount>=?"; args.append(min_amount)
    rows = conn.execute("""SELECT order_no,buyer_name,buyer_fb_name,buyer_contact,total_amount,purchase_date
        FROM orders WHERE member_id IS NULL
        AND (buyer_fb_name IS NOT NULL OR (buyer_contact IS NOT NULL AND buyer_contact!=''))"""
        + wm + " ORDER BY total_amount DESC", args).fetchall()
    buyers = []
    for r in rows:
        g = suggest_member_matches(r["buyer_fb_name"],0.6) if r["buyer_fb_name"] else []
        buyers.append({"order_no":r["order_no"],"name":r["buyer_name"],"fb":r["buyer_fb_name"],
                       "phone":r["buyer_contact"],"amount":r["total_amount"],"date":r["purchase_date"],
                       "suggestions":g})
    conn.close()
    conv = round(mem["n"]/total["n"]*100,1) if total["n"] else 0
    return {"total":{"count":total["n"],"amount":round(total["s"],2)},
            "member":{"count":mem["n"],"amount":round(mem["s"],2)},
            "non_member":{"count":non["n"],"amount":round(non["s"],2)},
            "conversion_rate":conv,"non_member_buyers":buyers}

def assign_order_to_member(order_no, mid, add_alias_name=None):
    conn = get_conn()
    row = conn.execute("SELECT * FROM orders WHERE order_no=?", (order_no,)).fetchone()
    if not row: conn.close(); return {"ok":False,"error":"order not found"}
    amt = row["total_amount"]; pts = int(amt) + (50 if amt>=150 else 0); reb = calc_rebate(amt)
    now_s = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if row["member_id"] != mid:
        conn.execute("INSERT INTO points_log (member_id,change,reason,ref,created_at) VALUES (?,?,?,?,?)",
                     (mid,pts,"消費回饋",order_no,now_s))
        conn.execute("UPDATE members SET points=points+? WHERE member_id=?", (pts,mid))
        if reb > 0:
            exp = (datetime.now()+timedelta(days=int(get_setting("rebate_expire_days","60")))).strftime("%Y-%m-%d")
            conn.execute("""INSERT INTO rebate_log (member_id,change,reason,ref,expires_at,created_at)
                VALUES (?,?,?,?,?,?)""", (mid,reb,"消費回饋金",order_no,exp,now_s))
            conn.execute("UPDATE members SET rebate=rebate+? WHERE member_id=?", (reb,mid))
        conn.execute("UPDATE members SET total_spend=total_spend+? WHERE member_id=?", (amt,mid))
    conn.execute("""UPDATE orders SET member_id=?, match_type='manual', is_pending=0, points_given=?, rebate_given=?
        WHERE order_no=?""", (mid,pts,reb,order_no))
    conn.commit(); conn.close()
    if add_alias_name: add_alias(mid, add_alias_name, "manual")
    return {"ok":True,"points_given":pts,"rebate_given":reb}

if __name__ == "__main__":
    init_db(); print("DB initialized:", DB_PATH)
