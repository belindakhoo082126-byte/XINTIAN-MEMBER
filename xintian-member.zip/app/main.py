# -*- coding: utf-8 -*-
"""心田花友俱樂部 — 後端 API"""
import os
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

from app import db
from app.importer import parse_ulive_csv, import_orders

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "app", "static")

app = FastAPI(title="心田花友俱樂部 API")
db.init_db()

class MemberIn(BaseModel):
    name: str; phone: Optional[str]=None; fb_name: Optional[str]=None; tg_id: Optional[str]=None
    tier: str="friend"; months: int=1; birthday: Optional[str]=None; email: Optional[str]=None
    note: Optional[str]=None
class PointsIn(BaseModel):
    member_id: int; change: int; reason: str="手動調整"
class RebateIn(BaseModel):
    member_id: int; change: float; reason: str="手動調整"
class AliasIn(BaseModel):
    member_id: int; alias: str; order_no: Optional[str]=None
class AssignIn(BaseModel):
    order_no: str; member_id: Optional[int]=None; phone: Optional[str]=None
    name: Optional[str]=None; create_if_missing: Optional[bool]=False
class PaymentIn(BaseModel):
    member_id: int; amount: float; months: int=1; pay_date: Optional[str]=None
    method: Optional[str]=None; kind: str="renew"; note: Optional[str]=None; extend: bool=True

@app.get("/api/members")
def api_members(tier: Optional[str]=None, status: Optional[str]=None):
    return {"members": db.list_members(tier, status)}

@app.post("/api/members")
def api_create_member(m: MemberIn):
    phone = db.normalize_phone(m.phone) if m.phone else None
    res = db.create_member(m.name, phone=phone, fb_name=m.fb_name, tg_id=m.tg_id, tier=m.tier,
                           months=m.months, birthday=m.birthday, email=m.email, note=m.note)
    if not res["ok"]: raise HTTPException(400, res["error"])
    if m.fb_name: db.add_alias(res["member_id"], m.fb_name, "manual")
    return res

@app.get("/api/members/{mid}")
def api_member(mid: int):
    m = db.get_member(mid)
    if not m: raise HTTPException(404, "not found")
    return {"member": m, "points_history": db.get_points_history(mid),
            "rebate_history": db.get_rebate_history(mid), "aliases": db.list_aliases(mid),
            "payments": db.get_payments(mid)}

@app.post("/api/members/{mid}/renew")
def api_renew(mid: int, months: int=1):
    return db.mark_renewed(mid, months)

@app.post("/api/points")
def api_points(p: PointsIn):
    db.add_points(p.member_id, p.change, p.reason)
    return {"ok": True, "points": db.get_member(p.member_id)["points"]}

@app.post("/api/rebate")
def api_rebate(r: RebateIn):
    db.add_rebate(r.member_id, r.change, r.reason)
    return {"ok": True, "rebate": db.get_member(r.member_id)["rebate"]}

@app.get("/api/match")
def api_match(name: str, threshold: float=0.6):
    return {"name": name, "suggestions": db.suggest_member_matches(name, threshold)}

@app.post("/api/alias")
def api_alias(a: AliasIn):
    db.add_alias(a.member_id, a.alias, "manual")
    res = {"ok": True}
    if a.order_no: res.update(db.assign_order_to_member(a.order_no, a.member_id))
    return res

@app.get("/api/aliases/{mid}")
def api_aliases(mid: int):
    return {"aliases": db.list_aliases(mid)}

@app.post("/api/order/assign")
def api_assign(a: AssignIn):
    mid = a.member_id
    if not mid and a.phone:
        m = db.find_member_by_identity(phone=a.phone)
        if m: mid = m["member_id"]
        elif a.create_if_missing:
            r = db.create_member(a.name or "(未命名)", phone=db.normalize_phone(a.phone), tier="friend")
            if r["ok"]: mid = r["member_id"]
    if not mid: return {"ok": False, "error": "找不到會員"}
    conn = db.get_conn()
    row = conn.execute("SELECT buyer_fb_name FROM orders WHERE order_no=?", (a.order_no,)).fetchone()
    conn.close()
    return db.assign_order_to_member(a.order_no, mid, row["buyer_fb_name"] if row else None)

@app.get("/api/pending")
def api_pending(min_amount: float=50):
    conn = db.get_conn()
    if min_amount > 0:
        rows = conn.execute("""SELECT * FROM orders WHERE is_pending=1 AND member_id IS NULL
            AND total_amount>=? ORDER BY purchase_date DESC LIMIT 200""", (min_amount,)).fetchall()
    else:
        rows = conn.execute("""SELECT * FROM orders WHERE is_pending=1 AND member_id IS NULL
            ORDER BY purchase_date DESC LIMIT 200""").fetchall()
    conn.close()
    return {"orders": [dict(r) for r in rows], "min_amount": min_amount}

@app.post("/api/import/preview")
async def api_preview(file: UploadFile = File(...)):
    orders = parse_ulive_csv(await file.read())
    return {"order_count": len(orders), "total_amount": round(sum(o["total_amount"] for o in orders.values()), 2)}

@app.post("/api/import")
async def api_import(file: UploadFile = File(...)):
    return import_orders(parse_ulive_csv(await file.read()))

@app.get("/api/stats")
def api_stats():
    conn = db.get_conn()
    total = conn.execute("SELECT COUNT(*) n FROM members").fetchone()["n"]
    paid = conn.execute("SELECT COUNT(*) n FROM members WHERE tier='paid'").fetchone()["n"]
    vip = conn.execute("SELECT COUNT(*) n FROM members WHERE tier IN ('vip','elder')").fetchone()["n"]
    trial = conn.execute("SELECT COUNT(*) n FROM members WHERE tier='friend'").fetchone()["n"]
    expired = conn.execute("SELECT COUNT(*) n FROM members WHERE status='expired'").fetchone()["n"]
    pending = conn.execute("SELECT COUNT(*) n FROM orders WHERE is_pending=1 AND member_id IS NULL").fetchone()["n"]
    pts = conn.execute("SELECT COALESCE(SUM(points),0) s FROM members").fetchone()["s"]
    reb = conn.execute("SELECT COALESCE(SUM(rebate),0) s FROM members").fetchone()["s"]
    rev = db.monthly_revenue()
    conn.close()
    return {"members":{"total":total,"paid":paid,"vip":vip,"trial":trial,"expired":expired},
            "pending_orders":pending,"points_outstanding":pts,"rebate_outstanding":round(reb,2),
            "revenue":rev}

@app.get("/api/analysis/conversion")
def api_conversion(min_amount: float=0):
    return db.conversion_analysis(min_amount)

@app.post("/api/upgrade-elders")
def api_elders():
    up = db.upgrade_elders()
    return {"ok": True, "upgraded": up, "count": len(up)}

@app.get("/api/expiring")
def api_expiring(days: int=7):
    return {"members": db.expiring_members(days)}

@app.post("/api/payment")
def api_payment(p: PaymentIn):
    res = db.record_payment(p.member_id, p.amount, p.months, p.pay_date, p.method, p.kind, p.note, p.extend)
    return {"ok": True, **(res or {})}

@app.get("/api/payments")
def api_payments(member_id: Optional[int]=None, month: Optional[str]=None):
    return {"payments": db.get_payments(member_id, month)}

@app.get("/api/revenue")
def api_revenue(month: Optional[str]=None):
    return {"current": db.monthly_revenue(month), "history": db.revenue_by_month()}

@app.get("/api/export/members.csv")
def api_export():
    import csv as _csv, io as _io
    members = db.list_members()
    out = _io.StringIO()
    if members:
        w = _csv.DictWriter(out, fieldnames=list(members[0].keys()))
        w.writeheader()
        for m in members: w.writerow(m)
    return Response(out.getvalue(), media_type="text/csv",
        headers={"Content-Disposition":"attachment; filename=xintian_members.csv"})

@app.get("/api/health")
def api_health():
    return {"ok": True, "time": datetime.now().isoformat()}

app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
