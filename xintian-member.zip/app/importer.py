# -*- coding: utf-8 -*-
"""Ulive 訂單 CSV 匯入模組"""
import csv, io
from datetime import datetime, timedelta
from app import db

def parse_amount(v):
    if v is None: return 0.0
    v = str(v).strip().replace(",", "")
    if v in ("","-"): return 0.0
    try: return float(v)
    except ValueError: return 0.0

def _clean(v):
    if v is None: return None
    v = str(v).strip()
    return None if v in ("","-") else v

def parse_ulive_csv(src):
    if isinstance(src,(bytes,bytearray)):
        fh = io.StringIO(src.decode("utf-8-sig"))
    elif isinstance(src,str) and ("\n" in src or "," in src):
        fh = io.StringIO(src)
    else:
        fh = open(src, encoding="utf-8-sig")
    orders = {}
    try:
        for row in csv.DictReader(fh):
            ono = (row.get("Order Number") or "").strip()
            if not ono or not ono.startswith("ECO-OR"): continue
            if ono not in orders:
                orders[ono] = {"order_no":ono,
                    "purchase_date":(row.get("Purchase Date") or "").strip(),
                    "status":(row.get("Status") or "").strip(),
                    "buyer_name":(row.get("Buyer Name") or "").strip(),
                    "buyer_fb_name":_clean(row.get("Buyer FB Name")),
                    "buyer_contact":_clean(row.get("Buyer Contact")),
                    "recipient":_clean(row.get("Recipient Name")),
                    "ship_method":_clean(row.get("Shipping Method")),
                    "source":_clean(row.get("Product Purchase Source")),
                    "total_amount":0.0, "items":[]}
            amt = parse_amount(row.get("Total Amount"))
            if amt > orders[ono]["total_amount"]: orders[ono]["total_amount"] = amt
            pn = (row.get("Product Name") or "").strip()
            if pn: orders[ono]["items"].append({"name":pn,"qty":parse_amount(row.get("Product Qty"))})
        return orders
    finally:
        fh.close()

def import_orders(orders, give_points=True, give_rebate=True):
    conn = db.get_conn(); now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    stats = {"total":len(orders),"matched":0,"candidates":[],"pending":[],"skipped":0,
             "points_total":0,"rebate_total":0.0}
    for ono, o in orders.items():
        if conn.execute("SELECT order_no FROM orders WHERE order_no=?", (ono,)).fetchone():
            stats["skipped"] += 1; continue
        member = db.find_member_by_identity(phone=o["buyer_contact"], fb_name=o["buyer_fb_name"])
        mid, mt, pend = None, None, 0
        if member:
            mid = member["member_id"]
            np = db.normalize_phone(o["buyer_contact"])
            mt = "phone" if (np and member.get("phone") and np == member["phone"]) else "fb_name"
            stats["matched"] += 1
        else:
            pend = 1
            if o["buyer_contact"] or o["buyer_fb_name"]:
                g = db.suggest_member_matches(o["buyer_fb_name"],0.6) if o["buyer_fb_name"] else []
                stats["candidates"].append({"order_no":ono,"name":o["buyer_name"],"phone":o["buyer_contact"],
                                            "fb":o["buyer_fb_name"],"amount":o["total_amount"],"suggestions":g})
            else:
                stats["pending"].append({"order_no":ono,"name":o["buyer_name"],"amount":o["total_amount"]})
        pts, reb = 0, 0.0
        if member and give_points:
            pts = int(o["total_amount"]) + (50 if o["total_amount"]>=150 else 0)
            conn.execute("INSERT INTO points_log (member_id,change,reason,ref,created_at) VALUES (?,?,?,?,?)",
                         (mid,pts,"消費回饋",ono,now))
            conn.execute("UPDATE members SET points=points+? WHERE member_id=?", (pts,mid))
            stats["points_total"] += pts
        if member and give_rebate:
            reb = db.calc_rebate(o["total_amount"])
            if reb > 0:
                exp = (datetime.now()+timedelta(days=int(db.get_setting("rebate_expire_days","60")))).strftime("%Y-%m-%d")
                conn.execute("""INSERT INTO rebate_log (member_id,change,reason,ref,expires_at,created_at)
                    VALUES (?,?,?,?,?,?)""", (mid,reb,"消費回饋金",ono,exp,now))
                conn.execute("UPDATE members SET rebate=rebate+? WHERE member_id=?", (reb,mid))
                stats["rebate_total"] += reb
        conn.execute("""INSERT INTO orders (order_no,purchase_date,status,buyer_name,buyer_fb_name,
            buyer_contact,recipient,ship_method,source,total_amount,member_id,match_type,is_pending,
            points_given,rebate_given,imported_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (ono,o["purchase_date"],o["status"],o["buyer_name"],o["buyer_fb_name"],o["buyer_contact"],
             o["recipient"],o["ship_method"],o["source"],o["total_amount"],mid,mt,pend,pts,reb,now))
        if mid:
            conn.execute("UPDATE members SET total_spend=total_spend+? WHERE member_id=?", (o["total_amount"],mid))
    conn.commit(); conn.close()
    return stats
