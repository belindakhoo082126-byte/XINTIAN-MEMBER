const I18N={zh:{
app_title:"心田花友俱樂部",app_sub:"Xin Tian Flower Friends Club · 營運後台",refresh:"重新整理",
tab_dashboard:"總覽",tab_members:"會員",tab_revenue:"會費收入",tab_import:"匯入訂單",tab_conversion:"轉換分析",tab_pending:"待認領",tab_expiring:"到期提醒",
sys_info:"系統說明",member_list:"會員列表",add_member:"新增會員",export_csv:"匯出 Excel",
all_tiers:"全部等級",all_status:"全部狀態",tier_friend:"體驗花友",tier_paid:"付費花友",tier_vip:"VIP 老客戶",tier_elder:"元老花友",
tier_friend_full:"體驗花友（首月免費）",tier_paid_full:"付費花友（RM20/月）",tier_vip_full:"VIP 老客戶（永久）",tier_elder_full:"元老花友（永久）",
status_active:"有效",status_expired:"已過期",
th_code:"編號",th_name:"姓名",th_phone:"電話",th_fb:"FB 名稱",th_tg:"TG ID",th_tier:"等級",th_points:"積分",th_rebate:"回饋金",th_spend:"累計消費",th_expiry:"到期日",th_action:"操作",
btn_detail:"詳情",import_title:"匯入 Ulive 訂單",import_hint:"從 Ulive 匯出訂單 CSV，上傳後系統會自動合併同一訂單、用電話/FB 名稱認人、計算消費積分與回饋金。",import_drop:"點擊選擇檔案，或拖放 CSV 到這裡",
pending_title:"待認領訂單",pending_hint:"只顯示單筆滿 RM50 的訂單。可以直接填電話建檔認領。",only_over_50:"只顯示 ≥ RM50（推薦）",show_all:"顯示全部",
expiring_title:"即將到期會員",days3:"未來 3 天",days7:"未來 7 天",days14:"未來 14 天",days30:"未來 30 天",
f_name:"姓名 *",f_phone:"電話",f_fb:"FB 名稱",f_tier:"等級",f_months:"會籍月數",f_birthday:"生日",f_note:"備註",
cancel:"取消",save:"儲存",close:"關閉",
st_total:"總會員",st_paid:"付費花友",st_vip:"VIP 老客戶",st_trial:"體驗花友",st_expired:"已過期",st_pending:"待認領",st_points:"流通積分",st_rebate:"回饋金負債",st_revenue:"本月會費",
rev_what:"這一頁是做什麼的？",rev_desc1:"這裡專門記錄會費收入（RM20/月）。",rev_step1:"新會員加入 → 去「會員」分頁 → 「+ 新增會員」",rev_step2:"他匯了 RM20 → 在下面選他、填金額 → 自動延長會籍",rev_note:"（會費一律在這裡記錄，不需要在 Ulive 開單。）",
rev_this_month:"本月",rev_pay_count:"本月付款筆數",rev_new_members:"本月新會員",rev_renewals:"本月續費人數",
rev_record:"記錄一筆付款",rev_member:"會員",rev_amount:"金額 RM",rev_months:"月數",rev_date:"付款日",rev_method:"方式",rev_kind:"類型",rev_renew:"續費",rev_new:"新加入",
rev_save:"儲存並延長會籍",rev_history:"歷月收入",rev_recent:"最近付款紀錄",
cv_total:"總消費訂單",cv_member:"會員消費",cv_non:"非會員消費",cv_rate:"會員轉換率",cv_targets:"非會員買家清單（招募目標）",
cv_hint:"這些人已經在消費，但還沒加入花友會。點「一鍵邀請」可生成邀請訊息（含 TG 連結）。",cv_invite:"一鍵邀請",
renew_btn:"標記已續費（+1月）",adjust_points:"調整積分",adjust_rebate:"調整回饋金",points_history:"積分紀錄",rebate_history:"回饋金紀錄",payment_history:"付款紀錄",
no_record:"尚無紀錄",current_points:"目前積分",rebate_label:"回饋金",total_spend:"累計消費",
invite_title:"📩 邀請訊息（點下方按鈕複製）",copy_msg:"複製訊息",copied:"已複製！",build_claim:"建檔並認領",fill_phone:"填電話 例 0122542466",name_ph:"姓名",
perm:"永久"},
en:{
app_title:"Xin Tian Flower Friends Club",app_sub:"Operations Dashboard",refresh:"Refresh",
tab_dashboard:"Overview",tab_members:"Members",tab_revenue:"Fees",tab_import:"Import",tab_conversion:"Conversion",tab_pending:"Unclaimed",tab_expiring:"Expiring",
sys_info:"How this system works",member_list:"Member List",add_member:"Add Member",export_csv:"Export Excel",
all_tiers:"All Tiers",all_status:"All Status",tier_friend:"Trial",tier_paid:"Paid",tier_vip:"VIP",tier_elder:"Elder",
tier_friend_full:"Trial (1st month free)",tier_paid_full:"Paid (RM20/month)",tier_vip_full:"VIP (Lifetime)",tier_elder_full:"Elder (Lifetime)",
status_active:"Active",status_expired:"Expired",
th_code:"Code",th_name:"Name",th_phone:"Phone",th_fb:"FB Name",th_tg:"TG ID",th_tier:"Tier",th_points:"Points",th_rebate:"Rebate",th_spend:"Total Spend",th_expiry:"Expiry",th_action:"Action",
btn_detail:"Detail",import_title:"Import Ulive Orders",import_hint:"Export orders from Ulive as CSV, then upload. The system auto-merges same orders, identifies members by phone/FB name, and calculates points & rebates.",import_drop:"Click to choose a file, or drag a CSV here",
pending_title:"Unclaimed Orders",pending_hint:"Only orders ≥ RM50 are shown. Fill in a phone to create the member.",only_over_50:"Only ≥ RM50 (recommended)",show_all:"Show all",
expiring_title:"Expiring Members",days3:"Next 3 days",days7:"Next 7 days",days14:"Next 14 days",days30:"Next 30 days",
f_name:"Name *",f_phone:"Phone",f_fb:"FB Name",f_tier:"Tier",f_months:"Months",f_birthday:"Birthday",f_note:"Note",
cancel:"Cancel",save:"Save",close:"Close",
st_total:"Total Members",st_paid:"Paid Members",st_vip:"VIP Members",st_trial:"Trial Members",st_expired:"Expired",st_pending:"Unclaimed Orders",st_points:"Points Issued",st_rebate:"Rebate Balance",st_revenue:"Fees This Month",
rev_what:"What is this page for?",rev_desc1:"This page records membership fees (RM20/month).",rev_step1:"New member joins → go to 'Members' tab → '+ Add Member'",rev_step2:"Paid RM20 → select member below, enter amount → membership auto-extended",rev_note:"(Record all fees here. No need to create an order in Ulive.)",
rev_this_month:"This Month",rev_pay_count:"Payments",rev_new_members:"New Members",rev_renewals:"Renewals",
rev_record:"Record a Payment",rev_member:"Member",rev_amount:"Amount RM",rev_months:"Months",rev_date:"Pay Date",rev_method:"Method",rev_kind:"Type",rev_renew:"Renewal",rev_new:"New",
rev_save:"Save & Extend Membership",rev_history:"Monthly Revenue",rev_recent:"Recent Payments",
cv_total:"Total Orders",cv_member:"Member Orders",cv_non:"Non-member Orders",cv_rate:"Conversion Rate",cv_targets:"Non-member Buyers (Recruitment Targets)",
cv_hint:"These people are already buying, but not yet members. Click 'Invite' to generate a message (with TG link).",cv_invite:"Invite",
renew_btn:"Mark Renewed (+1 month)",adjust_points:"Adjust Points",adjust_rebate:"Adjust Rebate",points_history:"Points History",rebate_history:"Rebate History",payment_history:"Payments",
no_record:"No records",current_points:"Points",rebate_label:"Rebate",total_spend:"Total Spend",
invite_title:"📩 Invitation Message (click to copy)",copy_msg:"Copy Message",copied:"Copied!",build_claim:"Create & Claim",fill_phone:"Phone e.g. 0122542466",name_ph:"Name",
perm:"Lifetime"}
};
let LANG=localStorage.getItem("xt_lang")||"zh";
function t(k){return (I18N[LANG]&&I18N[LANG][k])||I18N.zh[k]||k}
function applyLang(){
  document.documentElement.lang=LANG==="zh"?"zh-Hant":"en";
  document.querySelectorAll("[data-i18n]").forEach(el=>{const v=t(el.getAttribute("data-i18n"));if(v)el.textContent=v});
  const lb=document.getElementById("lang-label"); if(lb) lb.textContent=LANG==="zh"?"EN":"中文";
  if(typeof onLangChange==="function")onLangChange();
}
document.addEventListener("DOMContentLoaded",()=>{
  applyLang();
  const b=document.getElementById("btn-lang");
  if(b)b.addEventListener("click",()=>{LANG=LANG==="zh"?"en":"zh";localStorage.setItem("xt_lang",LANG);applyLang()});
});
