/* 心田花友俱樂部 — 前端邏輯 */
function tierLabel(tier){return t({friend:"tier_friend",paid:"tier_paid",vip:"tier_vip",elder:"tier_elder"}[tier]||tier)}
function closeModal(id){document.getElementById(id).classList.remove("show")}
document.querySelectorAll(".modal-bg").forEach(bg=>{bg.addEventListener("click",e=>{if(e.target===bg)bg.classList.remove("show")})});

document.querySelectorAll(".tab").forEach(tab=>{tab.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
  document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));
  tab.classList.add("active");
  document.getElementById("tab-"+tab.dataset.tab).classList.add("active");
  const tb=tab.dataset.tab;
  if(tb==="dashboard")loadStats();
  if(tb==="members")loadMembers();
  if(tb==="revenue")loadRevenue();
  if(tb==="conversion")loadConversion();
  if(tb==="pending")loadPending();
  if(tb==="expiring")loadExpiring();
})});

/* 總覽（不含訂單數量/總額，依 enabelle 要求） */
async function loadStats(){
  const s=await (await fetch("/api/stats")).json();
  document.getElementById("stat-grid").innerHTML=`
    <div class="stat"><div class="label"><i class="ph ph-users"></i> ${t("st_total")}</div><div class="value">${s.members.total}</div></div>
    <div class="stat info"><div class="label"><i class="ph ph-crown"></i> ${t("st_paid")}</div><div class="value">${s.members.paid}</div></div>
    <div class="stat"><div class="label"><i class="ph ph-star"></i> ${t("st_vip")}</div><div class="value">${s.members.vip}</div></div>
    <div class="stat"><div class="label"><i class="ph ph-seedling"></i> ${t("st_trial")}</div><div class="value">${s.members.trial}</div></div>
    <div class="stat warn"><div class="label"><i class="ph ph-clock"></i> ${t("st_expired")}</div><div class="value">${s.members.expired}</div></div>
    <div class="stat warn"><div class="label"><i class="ph ph-warning-circle"></i> ${t("st_pending")}</div><div class="value">${s.pending_orders}</div></div>
    <div class="stat"><div class="label"><i class="ph ph-coins"></i> ${t("st_points")}</div><div class="value">${s.points_outstanding.toLocaleString()}</div></div>
    <div class="stat info"><div class="label"><i class="ph ph-money"></i> ${t("st_revenue")}</div><div class="value">RM ${s.revenue.revenue.toFixed(2)}</div></div>`;
  buildSystemInfo();
}

const SYS_INFO={zh:[
"本系統為心田自有，資料保存在你自己的伺服器，不依賴第三方。",
"<strong>認人規則：</strong>電話優先 → FB 名稱備用 → 兩者皆無列為「待認領」。",
"<strong>匯入規則：</strong>同一訂單（Order Number）自動合併，只計算一次。",
"<strong>消費積分：</strong>每 RM1 = 1 分，單筆滿 RM150 額外 +50 分。",
"<strong>回饋金：</strong>消費金額 ×15%，下次消費可折抵最高 50%（滿 RM30 可用）。",
"<strong>會費：</strong>一律在「會費收入」頁記錄，不需在 Ulive 開單。"],
en:[
"This is Xin Tian's own system. Data is stored on your own server.",
"<strong>Matching:</strong> Phone first → FB name as fallback → if neither, marked 'Unclaimed'.",
"<strong>Import:</strong> Same order (Order Number) is auto-merged and counted once.",
"<strong>Points:</strong> RM1 = 1 point; orders ≥ RM150 get an extra +50 points.",
"<strong>Rebate:</strong> 15% of spend; can offset up to 50% of next order (min order RM30).",
"<strong>Fees:</strong> Always recorded on the 'Fees' page — no need to create an order in Ulive."]};
function buildSystemInfo(){const el=document.getElementById("sys-info-list");if(el)el.innerHTML=(SYS_INFO[LANG]||SYS_INFO.zh).map(x=>`<li>${x}</li>`).join("")}

/* 會員 */
let curTier="",curStatus="";
function buildMemberThead(){
  const th=["th_code","th_name","th_phone","th_fb","th_tg","th_tier","th_points","th_rebate","th_spend","th_expiry","th_action"];
  document.getElementById("member-thead").innerHTML=th.map(k=>`<th>${t(k)}</th>`).join("");
}
async function loadMembers(){
  const p=new URLSearchParams();
  if(curTier)p.set("tier",curTier);
  if(curStatus)p.set("status",curStatus);
  const data=await (await fetch("/api/members?"+p.toString())).json();
  const tb=document.querySelector("#member-table tbody");
  buildMemberThead();
  if(!data.members.length){tb.innerHTML=`<tr><td colspan="11"><div class="empty"><i class="ph ph-users"></i>${t("no_record")}</div></td></tr>`;return}
  tb.innerHTML=data.members.map(m=>`<tr>
    <td>${m.member_code||"-"}</td>
    <td><strong>${m.name}</strong>${m.status==="expired"?` <span class="pill expired">${t("status_expired")}</span>`:""}</td>
    <td>${m.phone||"-"}</td><td>${m.fb_name||"-"}</td><td>${m.tg_id||"-"}</td>
    <td><span class="pill ${m.tier}">${tierLabel(m.tier)}</span></td>
    <td>${m.points}</td><td>RM ${Number(m.rebate).toFixed(2)}</td><td>RM ${Number(m.total_spend).toFixed(0)}</td>
    <td>${m.expiry_date||t("perm")}</td>
    <td><button class="btn-ghost btn-sm" onclick="showDetail(${m.member_id})"><i class="ph ph-eye"></i> ${t("btn_detail")}</button></td>
  </tr>`).join("");
}
document.getElementById("filter-tier").addEventListener("change",e=>{curTier=e.target.value;loadMembers()});
document.getElementById("filter-status").addEventListener("change",e=>{curStatus=e.target.value;loadMembers()});

document.getElementById("btn-add-member").onclick=()=>document.getElementById("modal-member").classList.add("show");
document.getElementById("modal-save").onclick=async()=>{
  const body={name:document.getElementById("m-name").value.trim(),
    phone:document.getElementById("m-phone").value.trim()||null,
    fb_name:document.getElementById("m-fb").value.trim()||null,
    tg_id:document.getElementById("m-tg").value.trim()||null,
    tier:document.getElementById("m-tier").value,
    months:parseInt(document.getElementById("m-months").value)||1,
    birthday:document.getElementById("m-birthday").value||null,
    note:document.getElementById("m-note").value.trim()||null};
  if(!body.name){alert(LANG==="zh"?"請填寫姓名":"Please enter a name");return}
  const r=await fetch("/api/members",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const res=await r.json();
  if(!r.ok){alert((LANG==="zh"?"新增失敗：":"Failed: ")+(res.detail||""));return}
  alert((LANG==="zh"?"已新增會員 ":"Member added ")+res.member_code);
  closeModal("modal-member");
  ["m-name","m-phone","m-fb","m-tg","m-birthday","m-note"].forEach(id=>document.getElementById(id).value="");
  loadMembers();
};

async function showDetail(id){
  const d=await (await fetch("/api/members/"+id)).json();
  const m=d.member;
  const ph=d.points_history.map(p=>`<div class="log-row"><span>${p.reason} <small style="color:#889">${(p.created_at||"").slice(0,10)}</small></span><span class="${p.change>=0?"pos":"neg"}">${p.change>=0?"+":""}${p.change}</span></div>`).join("")||`<div class="log-row"><span>${t("no_record")}</span></div>`;
  const rh=d.rebate_history.map(x=>`<div class="log-row"><span>${x.reason} <small style="color:#889">${(x.created_at||"").slice(0,10)}${x.expires_at?" · "+x.expires_at:""}</small></span><span class="${x.change>=0?"pos":"neg"}">${x.change>=0?"+":"-"}RM${Math.abs(Number(x.change)).toFixed(2)}</span></div>`).join("")||`<div class="log-row"><span>${t("no_record")}</span></div>`;
  const pm=d.payments.map(x=>`<div class="log-row"><span>${x.pay_date} · ${x.kind==="new"?t("rev_new"):t("rev_renew")} · ${x.months}${LANG==="zh"?"個月":"mo"}</span><span class="pos">RM${Number(x.amount).toFixed(2)}</span></div>`).join("")||`<div class="log-row"><span>${t("no_record")}</span></div>`;
  document.getElementById("detail-content").innerHTML=`
    <div class="detail-head"><div class="avatar">${m.name.charAt(0)}</div>
      <div><h3>${m.name} <span class="pill ${m.tier}">${tierLabel(m.tier)}</span></h3>
      <div class="sub">${m.member_code} · ${m.phone||m.fb_name||m.tg_id||"-"} · ${m.expiry_date||t("perm")}</div></div></div>
    <div class="detail-stats">
      <div class="box"><strong>${m.points}</strong><span>${t("current_points")}</span></div>
      <div class="box"><strong>RM ${Number(m.rebate).toFixed(2)}</strong><span>${t("rebate_label")}</span></div>
      <div class="box"><strong>RM ${Number(m.total_spend).toFixed(0)}</strong><span>${t("total_spend")}</span></div></div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
      <button class="btn-primary btn-sm" onclick="renewMember(${m.member_id})"><i class="ph ph-check-circle"></i> ${t("renew_btn")}</button>
      <button class="btn-ghost btn-sm" onclick="adjustPoints(${m.member_id})"><i class="ph ph-plus-minus"></i> ${t("adjust_points")}</button>
      <button class="btn-ghost btn-sm" onclick="adjustRebate(${m.member_id})"><i class="ph ph-plus-minus"></i> ${t("adjust_rebate")}</button></div>
    <div class="detail-section"><h4>${t("points_history")}</h4>${ph}</div>
    <div class="detail-section"><h4>${t("rebate_history")}</h4>${rh}</div>
    <div class="detail-section"><h4>${t("payment_history")}</h4>${pm}</div>`;
  document.getElementById("modal-detail").classList.add("show");
}
async function renewMember(id){
  const msg=LANG==="zh"?"確認標記已續費並延長一個月？":"Mark as renewed and extend 1 month?";
  if(!confirm(msg))return;
  const res=await (await fetch(`/api/members/${id}/renew?months=1`,{method:"POST"})).json();
  alert((LANG==="zh"?"已續費，新到期日：":"Renewed. New expiry: ")+res.expiry_date);
  closeModal("modal-detail");loadMembers();
}
async function adjustPoints(id){
  const v=prompt(LANG==="zh"?"輸入積分調整值（可負數）：":"Point adjustment (+/-):");
  if(!v)return;const n=parseInt(v);if(isNaN(n))return;
  await fetch("/api/points",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({member_id:id,change:n,reason:"手動調整"})});
  showDetail(id);
}
async function adjustRebate(id){
  const v=prompt(LANG==="zh"?"輸入回饋金調整 RM（可負數）：":"Rebate adjustment RM (+/-):");
  if(!v)return;const n=parseFloat(v);if(isNaN(n))return;
  await fetch("/api/rebate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({member_id:id,change:n,reason:"手動調整"})});
  showDetail(id);
}

/* 匯入 */
const dz=document.getElementById("dropzone"),fi=document.getElementById("file-input");
dz.onclick=()=>fi.click();
dz.ondragover=e=>{e.preventDefault();dz.classList.add("drag")};
dz.ondragleave=()=>dz.classList.remove("drag");
dz.ondrop=e=>{e.preventDefault();dz.classList.remove("drag");if(e.dataTransfer.files.length)doImport(e.dataTransfer.files[0])};
fi.onchange=()=>{if(fi.files.length)doImport(fi.files[0])};
async function doImport(file){
  const fd=new FormData();fd.append("file",file);
  const box=document.getElementById("import-result");
  box.innerHTML=`<div class="result-box">${LANG==="zh"?"處理中…":"Processing…"}</div>`;
  const s=await (await fetch("/api/import",{method:"POST",body:fd})).json();
  box.innerHTML=`<div class="result-box"><h4><i class="ph ph-check-circle"></i> ${LANG==="zh"?"匯入完成":"Import complete"}</h4>
    <div class="result-grid">
      <div><span>${LANG==="zh"?"讀取訂單":"Orders"}</span><strong>${s.total}</strong></div>
      <div><span>${LANG==="zh"?"認到會員":"Matched"}</span><strong>${s.matched}</strong></div>
      <div><span>${LANG==="zh"?"候選新會員":"Candidates"}</span><strong>${s.candidates.length}</strong></div>
      <div><span>${LANG==="zh"?"待認領":"Pending"}</span><strong>${s.pending.length}</strong></div>
      <div><span>${LANG==="zh"?"重複跳過":"Skipped"}</span><strong>${s.skipped}</strong></div>
      <div><span>${LANG==="zh"?"發出積分":"Points"}</span><strong>${s.points_total}</strong></div>
      <div><span>${LANG==="zh"?"發出回饋金":"Rebate"}</span><strong>RM ${s.rebate_total.toFixed(2)}</strong></div>
    </div></div>`;
  loadStats();
}

/* 轉換分析 */
async function loadConversion(){
  const min=(document.getElementById("conv-filter")||{}).value||"0";
  const d=await (await fetch("/api/analysis/conversion?min_amount="+min)).json();
  const buyers=d.non_member_buyers.map(b=>{
    const sugg=(b.suggestions&&b.suggestions.length)?b.suggestions.map(s=>`<button class="suggest-btn" onclick="quickAssign('${b.order_no}',${s.member_id})">${s.name} <small>${Math.round(s.score*100)}%</small></button>`).join(""):`<span class="suggest-none">${LANG==="zh"?"非會員":"Non-member"}</span>`;
    return `<div class="row-item" style="flex-direction:column;align-items:stretch">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><div class="who">${b.name||"-"}</div><div class="meta">${b.fb?"FB: "+b.fb:""} ${b.phone?"· "+b.phone:""} · ${b.order_no}</div></div>
        <div class="amt">RM ${Number(b.amount).toFixed(0)}</div></div>
      <div class="suggest-box"><span class="suggest-label">💡</span>${sugg}
        <button class="btn-primary btn-sm" onclick="inviteBuyer('${(b.name||"").replace(/'/g,"")}','${(b.fb||"").replace(/'/g,"")}')"><i class="ph ph-paper-plane-tilt"></i> ${t("cv_invite")}</button></div></div>`;
  }).join("")||`<div class="empty"><i class="ph ph-check-circle"></i>${t("no_record")}</div>`;
  document.getElementById("conversion-content").innerHTML=`
    <div class="stat-grid">
      <div class="stat info"><div class="label"><i class="ph ph-receipt"></i> ${t("cv_total")}</div><div class="value">${d.total.count}</div><div style="font-size:13px;color:#5B6B57">RM ${d.total.amount.toLocaleString()}</div></div>
      <div class="stat"><div class="label"><i class="ph ph-user-check"></i> ${t("cv_member")}</div><div class="value">${d.member.count}</div><div style="font-size:13px;color:#5B6B57">RM ${d.member.amount.toLocaleString()}</div></div>
      <div class="stat warn"><div class="label"><i class="ph ph-user-minus"></i> ${t("cv_non")}</div><div class="value">${d.non_member.count}</div><div style="font-size:13px;color:#5B6B57">RM ${d.non_member.amount.toLocaleString()}</div></div>
      <div class="stat warn"><div class="label"><i class="ph ph-funnel"></i> ${t("cv_rate")}</div><div class="value">${d.conversion_rate}%</div></div></div>
    <div class="card"><div class="card-head"><h2><i class="ph ph-user-plus"></i> ${t("cv_targets")}</h2>
      <select id="conv-filter" onchange="loadConversion()">
        <option value="0">${t("show_all")}</option><option value="50">${t("only_over_50")}</option></select></div>
      <p class="hint">${t("cv_hint")}</p>${buyers}</div>`;
  const cf=document.getElementById("conv-filter"); if(cf) cf.value=min;
}
async function quickAssign(orderNo,mid){
  if(!confirm(LANG==="zh"?"確認將此訂單指派給該會員並補計積分？":"Assign this order to this member?"))return;
  const res=await (await fetch("/api/order/assign",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({order_no:orderNo,member_id:mid})})).json();
  if(res.ok){alert(`✅ +${res.points_given} / RM${Number(res.rebate_given).toFixed(2)}`);loadConversion()}else{alert(res.error||"failed")}
}
const TG_LINK="https://t.me/+RG2JZFtDkVphNmI1";
function inviteBuyer(name,fb){
  const cn=(fb||name||(LANG==="zh"?"花友":"Friend")).split(/[\s(（]/)[0];
  const msg=LANG==="zh"?`嗨 ${cn} 🌱\n\n謝謝你一直支持心田！發現你已經是我們的熟客了 ❤️\n\n想邀請你加入【心田花友俱樂部】，完全免費的第一個月體驗：\n\n🎁 花友福利\n✅ 一對一植物養護諮詢\n✅ 每月會員專屬教學直播\n✅ 花友交流群，認識更多同好\n✅ 積分換植物、生日盲盒\n✅ 消費享回饋金\n\n📱 加入方式：\n1️⃣ 回覆「+1」表示想加入\n2️⃣ 我們會發 Telegram 群連結給你\n3️⃣ 進群後完成簡單註冊即可\n\n期待在群裡見到你 🌸\n— 心田 Xin Tian`:`Hi ${cn} 🌱\n\nThank you for supporting Xin Tian! You're one of our regulars ❤️\n\nWe'd love to invite you to the [Xin Tian Flower Friends Club] — first month FREE:\n\n🎁 Benefits\n✅ 1-on-1 plant care consultation\n✅ Monthly members-only livestream\n✅ Community to meet fellow plant lovers\n✅ Redeem plants & birthday gifts with points\n✅ Spending rebate\n\n📱 How to join:\n1️⃣ Reply "+1"\n2️⃣ We'll send you the Telegram group link\n3️⃣ Complete a simple registration\n\nSee you in the group 🌸\n— Xin Tian`;
  document.getElementById("detail-content").innerHTML=`
    <h3 style="color:var(--green-dark);margin-bottom:12px">${t("invite_title")}</h3>
    <div style="background:#F7FAF6;border:1px solid var(--line);border-radius:10px;padding:16px;white-space:pre-wrap;font-size:14px;line-height:1.8;max-height:340px;overflow-y:auto">${msg}</div>
    <div class="modal-actions"><button class="btn-primary" onclick="copyInvite(this)"><i class="ph ph-copy"></i> ${t("copy_msg")}</button>
      <button class="btn-ghost" onclick="closeModal('modal-detail')">${t("close")}</button></div>
    <input type="hidden" id="invite-text" value="${msg.replace(/"/g,"&quot;")}">`;
  document.getElementById("modal-detail").classList.add("show");
}
function copyInvite(btn){
  const txt=document.getElementById("invite-text").value;
  navigator.clipboard.writeText(txt).then(()=>{btn.innerHTML=`<i class="ph ph-check"></i> ${t("copied")}`}).catch(()=>{
    const ta=document.createElement("textarea");ta.value=txt;document.body.appendChild(ta);ta.select();
    document.execCommand("copy");document.body.removeChild(ta);btn.innerHTML=`<i class="ph ph-check"></i> ${t("copied")}`;});
}

/* 待認領 */
async function loadPending(){
  const min=(document.getElementById("pending-filter")||{}).value||"50";
  const d=await (await fetch("/api/pending?min_amount="+min)).json();
  const box=document.getElementById("pending-list");
  if(!d.orders||!d.orders.length){box.innerHTML=`<div class="empty"><i class="ph ph-check-circle"></i>${t("no_record")}</div>`;return}
  box.innerHTML=d.orders.map(o=>`<div class="row-item" style="flex-direction:column;align-items:stretch">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
      <div><div class="who">${o.buyer_name||"-"}</div><div class="meta">${o.order_no} · ${o.purchase_date||""} · ${o.source||""}</div></div>
      <div class="amt">RM ${Number(o.total_amount).toFixed(0)}</div></div>
    <div class="suggest-box">
      <input class="inline-input" id="ph-${o.order_no}" placeholder="${t("fill_phone")}" style="max-width:180px">
      <input class="inline-input" id="nm-${o.order_no}" placeholder="${t("name_ph")}" style="max-width:130px">
      <button class="btn-primary btn-sm" onclick="assignPending('${o.order_no}')"><i class="ph ph-check"></i> ${t("build_claim")}</button></div></div>`).join("");
}
async function assignPending(orderNo){
  const phone=document.getElementById("ph-"+orderNo).value.trim();
  const name=document.getElementById("nm-"+orderNo).value.trim();
  if(!phone){alert(LANG==="zh"?"請填電話":"Please enter phone");return}
  const res=await (await fetch("/api/order/assign",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({order_no:orderNo,phone:phone,name:name||"(未命名)",create_if_missing:true})})).json();
  if(res.ok){alert(`✅ +${res.points_given} / RM${Number(res.rebate_given).toFixed(2)}`);loadPending()}else{alert(res.error||"failed")}
}

/* 到期提醒 */
async function loadExpiring(){
  const days=document.getElementById("expiring-days").value;
  const d=await (await fetch("/api/expiring?days="+days)).json();
  const box=document.getElementById("expiring-list");
  if(!d.members.length){box.innerHTML=`<div class="empty"><i class="ph ph-check-circle"></i>${t("no_record")}</div>`;return}
  box.innerHTML=d.members.map(m=>`<div class="row-item">
    <div><div class="who">${m.name} <span class="pill ${m.tier}">${tierLabel(m.tier)}</span></div>
      <div class="meta">${m.phone||m.fb_name||""} · ${m.expiry_date}</div></div>
    <button class="btn-primary btn-sm" onclick="renewMember(${m.member_id})"><i class="ph ph-check-circle"></i> ${t("rev_renew")}</button></div>`).join("");
}

function onLangChange(){
  const a=document.querySelector(".tab.active");
  if(a){const tb=a.dataset.tab;
    if(tb==="dashboard")loadStats();
    if(tb==="members")loadMembers();
    if(tb==="revenue")loadRevenue();
    if(tb==="conversion")loadConversion();
    if(tb==="pending")loadPending();
    if(tb==="expiring")loadExpiring();}
}

document.getElementById("btn-refresh").onclick=()=>{
  const a=document.querySelector(".tab.active").dataset.tab;
  if(a==="dashboard")loadStats();
  if(a==="members")loadMembers();
  if(a==="revenue")loadRevenue();
  if(a==="conversion")loadConversion();
  if(a==="pending")loadPending();
  if(a==="expiring")loadExpiring();
};

loadStats();

/* 會費收入 */
async function loadRevenue(){
  const d=await (await fetch("/api/revenue")).json();
  const c=d.current;
  const hist=d.history.map(h=>`<div class="log-row"><span>${h.month}</span><span>${h.n} · <strong style="color:var(--green-dark)">RM ${h.total.toFixed(2)}</strong></span></div>`).join("")||`<div class="log-row"><span>${t("no_record")}</span></div>`;
  const pr=await (await fetch("/api/payments")).json();
  const plist=pr.payments.slice(0,30).map(p=>`<div class="row-item">
    <div><div class="who">${p.name||p.member_code||p.member_id}</div>
      <div class="meta">${p.pay_date} · ${p.kind==="new"?t("rev_new"):t("rev_renew")} · ${p.months}${LANG==="zh"?"個月":"mo"} ${p.method?"· "+p.method:""}</div></div>
    <div class="amt">RM ${Number(p.amount).toFixed(2)}</div></div>`).join("")||`<div class="empty"><i class="ph ph-money"></i>${t("no_record")}</div>`;
  document.getElementById("revenue-content").innerHTML=`
    <div class="card" style="border-left:4px solid var(--blue)">
      <h2><i class="ph ph-info"></i> ${t("rev_what")}</h2>
      <p class="hint" style="margin-bottom:8px">${t("rev_desc1")}</p>
      <ul class="info-list"><li>${t("rev_step1")}</li><li>${t("rev_step2")}</li></ul>
      <p class="hint" style="margin-top:8px;font-style:italic">${t("rev_note")}</p></div>
    <div class="stat-grid">
      <div class="stat"><div class="label"><i class="ph ph-calendar"></i> ${t("rev_this_month")}（${c.month}）</div><div class="value">RM ${c.revenue.toFixed(2)}</div></div>
      <div class="stat info"><div class="label"><i class="ph ph-receipt"></i> ${t("rev_pay_count")}</div><div class="value">${c.payment_count}</div></div>
      <div class="stat"><div class="label"><i class="ph ph-user-plus"></i> ${t("rev_new_members")}</div><div class="value">${c.new_members}</div></div>
      <div class="stat"><div class="label"><i class="ph ph-arrows-clockwise"></i> ${t("rev_renewals")}</div><div class="value">${c.renewals}</div></div></div>
    <div class="card"><h2><i class="ph ph-plus-circle"></i> ${t("rev_record")}</h2>
      <div class="form-row"><label>${t("rev_member")}</label><select id="pay-member"></select></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <div class="form-row" style="flex:1;min-width:120px"><label>${t("rev_amount")}</label><input id="pay-amount" type="number" value="20"></div>
        <div class="form-row" style="flex:1;min-width:100px"><label>${t("rev_months")}</label><input id="pay-months" type="number" value="1"></div>
        <div class="form-row" style="flex:1;min-width:140px"><label>${t("rev_date")}</label><input id="pay-date" type="date"></div>
        <div class="form-row" style="flex:1;min-width:130px"><label>${t("rev_method")}</label><select id="pay-method"><option value="">-</option><option>銀行</option><option>TNG</option><option>現金</option><option>Facebook</option></select></div>
        <div class="form-row" style="flex:1;min-width:130px"><label>${t("rev_kind")}</label><select id="pay-kind"><option value="renew">${t("rev_renew")}</option><option value="new">${t("rev_new")}</option></select></div></div>
      <button class="btn-primary" onclick="submitPayment()"><i class="ph ph-check"></i> ${t("rev_save")}</button></div>
    <div class="card"><h2><i class="ph ph-chart-line-up"></i> ${t("rev_history")}</h2>${hist}</div>
    <div class="card"><h2><i class="ph ph-clock-counter-clockwise"></i> ${t("rev_recent")}</h2>${plist}</div>`;
  const mr=await (await fetch("/api/members")).json();
  document.getElementById("pay-member").innerHTML=mr.members.map(m=>`<option value="${m.member_id}">${m.name}（${m.member_code}）</option>`).join("");
  document.getElementById("pay-date").value=new Date().toISOString().slice(0,10);
}
async function submitPayment(){
  const body={member_id:parseInt(document.getElementById("pay-member").value),
    amount:parseFloat(document.getElementById("pay-amount").value),
    months:parseInt(document.getElementById("pay-months").value),
    pay_date:document.getElementById("pay-date").value,
    method:document.getElementById("pay-method").value||null,
    kind:document.getElementById("pay-kind").value};
  const res=await (await fetch("/api/payment",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)})).json();
  if(res.ok){alert((LANG==="zh"?"已記錄，會籍延至 ":"Recorded. Extended to ")+(res.expiry_date||"—"));loadRevenue()}
  else alert("failed");
}
