# -*- coding: utf-8 -*-
import sys, os, csv, io, urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app import db

SHEET="https://docs.google.com/spreadsheets/d/1iRCch_K9rd2ZHqQ8UHieeVX2A53I03p2bk0MVjoyRzI/export?format=csv"
TEST={"测试用户","测试用户2","TestUser"}
MANUS={"ice":102,"Kitty yws":108,"KAREN CHIANG":80,"Sin Ghee Tan":76,"Janice He":74,
       "Sky Tee":68,"74708 Cheng":66,"CHIN FOONG KEOW":60,"Phyllis Tan":60,"Michelle Lee":50}

db.init_db()
req=urllib.request.Request(SHEET, headers={"User-Agent":"Mozilla/5.0"})
text=urllib.request.urlopen(req, timeout=30).read().decode("utf-8-sig")
rows=list(csv.DictReader(io.StringIO(text)))
created=0
for r in rows:
    name=(r.get("会员名字") or "").strip()
    if not name or name in TEST: continue
    tg=(r.get("Telegram ID") or "").strip()
    phone=db.normalize_phone((r.get("联系号码") or "").strip()) if r.get("联系号码","").strip() else None
    expiry=(r.get("到期日期") or "").strip() or None
    status_raw=(r.get("状态") or "").strip()
    join=(r.get("加入日期") or "").strip() or None
    tier="vip" if (expiry and expiry.startswith("2099")) else "paid"
    from datetime import datetime, date
    st="active"
    if expiry and not expiry.startswith("2099"):
        try:
            if datetime.strptime(expiry,"%Y-%m-%d").date() < date.today(): st="expired"
        except ValueError: pass
    res=db.create_member(name, phone=phone, tg_id=tg, tier=tier, status=st,
                         expiry_override=expiry, join_date=join, note=(r.get("备注") or "").strip() or None)
    if res.get("ok"): created+=1
print("匯入會員:", created)

# 積分
members=db.list_members()
byname={(m["name"] or "").lower().strip(): m for m in members}
pt=0
for n,v in MANUS.items():
    m=byname.get(n.lower().strip())
    if m:
        db.add_points(m["member_id"], v, "Manus 積分匯入（起始值）", "manus_2026-10")
        pt+=v
print("匯入積分:", pt, "分（10 位）")
