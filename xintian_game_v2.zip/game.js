/* 心田花園 · 遊戲核心 v1
 * 17 種植物 / 照顧 / 觀察 / 積分 / 兌換 / 花友中心
 * 目前用本機模擬；接系統時改 API 層即可
 */

// ============ 17 種植物配置（對齊系統契約）============
const PLANTS = [
  {key:"p01", emoji:"🪴", name:"石莲花",   cat:"多肉",   star:1, stages:["幼苗","新叶","莲座"],                water:3, fert:30, light:"充足日照", tip:"介质全干才浇，勿按固定天数"},
  {key:"p02", emoji:"🌺", name:"沙漠玫瑰", cat:"块根",   star:2, stages:["幼苗","茎基膨大","分枝","开花"],      water:4, fert:30, light:"充足日照", tip:"茎基软≠缺水，可能是积水"},
  {key:"p03", emoji:"💜", name:"薰衣草",   cat:"香草",   star:2, stages:["幼苗","枝叶茂密","抽穗","开花"],      water:1, fert:14, light:"充足日照+通风", tip:"高温高湿难养，通风最重要"},
  {key:"p04", emoji:"🍃", name:"红财神",   cat:"观叶",   star:2, stages:["幼苗","新叶1","新叶2","新叶3"],      water:2, fert:30, light:"明亮散射光", tip:"红叶≠要强晒，会灼伤"},
  {key:"p05", emoji:"🌸", name:"大岩桐",   cat:"草本花卉",star:3,stages:["幼苗","新叶","花苞","开花"],         water:1, fert:14, light:"明亮散射光", tip:"浇水避开叶心，否则冠腐"},
  {key:"p06", emoji:"🌼", name:"百万小铃", cat:"半木质花卉",star:3,stages:["幼苗","分枝","开花","修剪","复花"],  water:1, fert:14, light:"充足光照",   tip:"过湿叶黄≠缺肥，先查根"},
  {key:"p07", emoji:"🌹", name:"英式月季", cat:"木本花卉",star:4,stages:["幼苗","分枝","花苞","开花","修剪"],    water:2, fert:14, light:"充足日照+通风", tip:"控水≠断水；疏叶≠剃光"},
  {key:"p08", emoji:"🪷", name:"睡莲",     cat:"水生",   star:3, stages:["种藕","浮叶","立叶","开花"],          water:0, fert:21, light:"全日照",     tip:"保持水位，养鱼不可用一般荷花肥"},
  {key:"p09", emoji:"🌾", name:"万代兰",   cat:"裸根兰花",star:4,stages:["苗","新根","新叶","花梗","开花"],      water:0, fert:10, light:"明亮散射光", tip:"裸根≠不用浇水，需每日喷雾"},
  {key:"p10", emoji:"🦋", name:"蝴蝶兰",   cat:"介质兰花",star:4,stages:["苗","新根","新叶","花梗","开花"],      water:3, fert:14, light:"明亮散射光", tip:"水苔内部干才浇，别只看表面"},
  {key:"p11", emoji:"🌷", name:"地生兰",   cat:"土壤兰花",star:3,stages:["幼苗","丛生","花梗","开花"],           water:2, fert:30, light:"半日照",     tip:"地生兰与附生兰照顾不同"},
  {key:"p12", emoji:"🌿", name:"鹿角蕨",   cat:"附生蕨", star:4, stages:["苗","盾叶","孢子叶"],                  water:1, fert:21, light:"明亮散射光", tip:"盾叶变褐可能自然老化，别乱剪"},
  {key:"p13", emoji:"🍋", name:"柠檬",     cat:"果树",   star:4, stages:["幼苗","分枝","开花","结果","成熟"],    water:2, fert:14, light:"全日照",     tip:"结果期别急施氮肥"},
  {key:"p14", emoji:"🍇", name:"青葡萄",   cat:"藤本果", star:4, stages:["藤苗","长藤","开花","结果","成熟"],    water:2, fert:14, light:"全日照",     tip:"长藤≠会结果，注意光照与氮肥"},
  {key:"p15", emoji:"🍓", name:"草莓",     cat:"草本果", star:3, stages:["幼苗","开花","结果","转红"],           water:1, fert:14, light:"充足光照",   tip:"怕冠部积水，浇水避开花心"},
  {key:"p16", emoji:"🌶️", name:"辣椒",     cat:"果菜",   star:2, stages:["幼苗","分枝","开花","结果","转色"],    water:2, fert:14, light:"全日照",     tip:"开花后落花要找原因，不是猛施肥"},
  {key:"p17", emoji:"🥬", name:"小白菜",   cat:"叶菜",   star:1, stages:["播种","发芽","幼苗","长叶","可采收"],  water:1, fert:14, light:"半日照至全日照", tip:"叶菜周期短，勤观察"},
];

// 解鎖規則
const UNLOCK = [
  {need:0, plants:["p01","p17","p03"]},
  {need:1, plants:["p04","p16","p15","p02"]},
  {need:2, plants:["p05","p06","p08"]},
  {need:3, plants:["p10","p11","p12"]},
  {need:4, species:3, plants:["p07","p09","p13","p14"]},
];

// 每日任務上限
const DAILY_LIMIT = 25;
const TASK_LIMIT = {game_login:1, plant_care:3, game_quiz:3, plant_photo:1};

// ============ 狀態 ============
let S = {
  code:"XT-0001",
  name:"enabelle khoo",
  tier:"VIP",
  points_total:745,
  points_pending:0,
  plant:null,           // 目前種植
  completed:0,          // 完成株數
  species:[],           // 完成過的種類
  observed_today:false,
  consecutive:5,
  today_points:9,       // 今日已得
  task_done:{game_login:0, plant_care:2, game_quiz:1, plant_photo:0},
  points_history:[
    {date:"10/12", reason:"答对问答", change:10},
    {date:"10/11", reason:"照顾植物", change:3},
    {date:"10/11", reason:"每日登入", change:2},
  ],
  rebate_total:15.50,
  rebate_batches:[
    {date:"10/01", reason:"消费回馈", amount:10, exp:"11/30", status:"available"},
    {date:"10/08", reason:"折抵肥料", amount:-5, exp:null, status:"used"},
  ],
  reward_requests:[],
  admin:false,          // 管理者模式
};

// 禮物（正式版讀系統 /api/member/rewards）
const REWARDS = [
  {id:1, name:"随机小植物盲盒", points:400},
  {id:2, name:"RM10 voucher",  points:500},
  {id:3, name:"随机香草/多肉",  points:600},
  {id:4, name:"心田自制肥料",   points:700},
  {id:5, name:"植物数字学解读", points:900},
  {id:6, name:"随机高值植物",   points:2000},
];

// 知識庫（正式版讀 100 條 tips）
const TIPS = [
  {t:"为什么多肉的叶子会变红？", c:"日照充足 + 日夜温差大时，植物会产生花青素，叶片就会慢慢转红，看起来更漂亮。"},
  {t:"浇水不是越多越好", c:"先摸土，干了才浇。多数植物烂根都是浇太多造成的。"},
  {t:"蛋壳不要直接放盆里", c:"未腐熟的蛋壳会招虫，建议堆肥腐熟后再用。"},
  {t:"兰花不一定要种在土里", c:"许多热带兰喜欢树皮、木炭、椰壳块这类透气介质，根需要空气。"},
  {t:"辣椒开花后落花怎么办？", c:"先看是否热害、水分不稳或养分不足，别急着猛施肥。"},
];

// ============ 工具 ============
function toast(msg){
  const t=document.getElementById("toast");
  t.textContent=msg; t.classList.add("show");
  clearTimeout(t._tm); t._tm=setTimeout(()=>t.classList.remove("show"),1800);
}
function getPlant(key){ return PLANTS.find(p=>p.key===key); }
function unlockedKeys(){
  const keys=["p01","p17","p03"];
  UNLOCK.forEach(u=>{
    if(S.completed>=u.need){
      if(u.species && new Set(S.species).size < u.species) return;
      u.plants.forEach(k=>{ if(!keys.includes(k)) keys.push(k); });
    }
  });
  return keys;
}
function availablePoints(){ return S.points_total - S.points_pending; }

// ============ 渲染：頁面骨架 ============
function renderApp(){
  document.getElementById("app").innerHTML = `
  <!-- 登入 -->
  <div class="page active" id="page-login">
    <div class="logo-big">🌱</div>
    <h1>心田花园</h1>
    <p class="sub">一边种 · 一边学 · 一边拿</p>
    <div class="login-box">
      <input id="member-code" placeholder="输入会员编号" value="XT-0001">
      <button class="btn-main" onclick="doLogin(false)">花友进入</button>
      <a class="link-admin" onclick="doLogin(true)">管理者进入</a>
    </div>
  </div>

  <!-- 花園 -->
  <div class="page" id="page-garden">
    <div class="topbar">
      <div class="t">心田花园</div>
      <div class="score" id="garden-score">0 分</div>
    </div>
    <div class="scene" id="scene">
      <img class="bg-img" src="bg.jpg" onerror="this.style.display='none'">
      <div class="plant-area" id="plant-area"></div>
    </div>
    <div id="garden-info"></div>
    <div class="actions">
      <button class="action" onclick="doCare('water')"><span class="ic">水</span><span class="lb">浇水</span></button>
      <button class="action" onclick="doCare('fert')"><span class="ic">肥</span><span class="lb">施肥</span></button>
      <button class="action" onclick="doObserve('pests')"><span class="ic">虫</span><span class="lb">除虫</span></button>
      <button class="action" onclick="doObserve('moisture')"><span class="ic">查</span><span class="lb">检查</span></button>
    </div>
    <div class="nav">
      <button class="nav-item active" onclick="go('garden')"><span class="ni">园</span><span class="nl">花园</span></button>
      <button class="nav-item" onclick="go('choose')"><span class="ni">种</span><span class="nl">种植</span></button>
      <button class="nav-item" onclick="go('reward')"><span class="ni">礼</span><span class="nl">兑换</span></button>
      <button class="nav-item" onclick="go('member')"><span class="ni">我</span><span class="nl">花友中心</span></button>
    </div>
  </div>

  <!-- 選擇種植 -->
  <div class="page" id="page-choose">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>选择要种的植物</h2></div>
    <div class="scroll" id="choose-content"></div>
  </div>

  <!-- 學習 -->
  <div class="page" id="page-learn">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>植物知识</h2></div>
    <div class="scroll" id="learn-content"></div>
  </div>

  <!-- 兌換 -->
  <div class="page" id="page-reward">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>兑换礼物</h2></div>
    <div class="scroll" id="reward-content"></div>
  </div>

  <!-- 花友中心 -->
  <div class="page" id="page-member">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>花友中心</h2></div>
    <div class="scroll" id="member-content"></div>
  </div>

  <!-- 任務 -->
  <div class="page" id="page-task">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>今日任务</h2></div>
    <div class="scroll" id="task-content"></div>
  </div>

  <!-- 管理者 -->
  <div class="page" id="page-admin">
    <div class="page-header"><button class="back" onclick="go('garden')">←</button><h2>管理者 · 花园管理</h2></div>
    <div class="scroll" id="admin-content"></div>
  </div>`;
}

// ============ 登入 ============
async function doLogin(isAdmin){
  const code=document.getElementById("member-code").value.trim();
  if(!code){ toast("请输入会员编号"); return; }
  S.code=code;
  S.admin=isAdmin;
  // 嘗試呼叫系統 API
  const r = await API.login(code);
  if(r.ok){
    await loadFromAPI();
    toast("已连接系统");
  } else {
    toast("离线模式（"+code+"）");
  }
  if(isAdmin){ go("admin"); toast("管理者模式"); }
  else { go("garden"); }
  addPoints(2,"每日登入");
}

// 從系統載入真實資料
async function loadFromAPI(){
  const me = await API.me();
  if(me){
    S.name = me.member.name;
    S.tier = me.member.tier;
    S.points_total = me.points_total;
    S.points_pending = me.points_pending_redemption;
    S.rebate_total = me.rebate_available;
  }
  const gs = await API.gameState();
  if(gs){
    S.completed = gs.completed_count || 0;
    S.species = gs.completed_species || [];
    if(gs.current_plant){
      S.plant = {
        key: gs.current_plant.plant_key,
        plantId: gs.current_plant.id,
        stageIdx: 0,
        stageName: gs.current_plant.status || "幼苗",
        day: 1, water:50, food:50, health:100
      };
    }
  }
  const rw = await API.rewards();
  if(rw && rw.rewards){
    REWARDS.length = 0;
    rw.rewards.forEach(x=>REWARDS.push({id:x.id, name:x.name, points:x.points}));
  }
}

// ============ 頁面切換 ============
function go(p){
  document.querySelectorAll(".page").forEach(e=>e.classList.remove("active"));
  const el=document.getElementById("page-"+p);
  if(el) el.classList.add("active");
  if(p==="garden") renderGarden();
  if(p==="choose") renderChoose();
  if(p==="learn") renderLearn();
  if(p==="reward") renderReward();
  if(p==="member") renderMember();
  if(p==="task") renderTask();
  if(p==="admin") renderAdmin();
}

// ============ 花園 ============
function renderGarden(){
  document.getElementById("garden-score").textContent=availablePoints()+" 分";
  const area=document.getElementById("plant-area");
  const info=document.getElementById("garden-info");
  if(!S.plant){
    area.innerHTML=`<div style="text-align:center"><div style="font-size:70px">🌱</div>
      <div style="font-size:15px;font-weight:700;color:#2E5D2A;margin-top:8px">你还没有种植物</div>
      <button class="btn-main" style="margin-top:14px;width:auto;padding:12px 28px" onclick="go('choose')">去种植</button></div>`;
    info.innerHTML=`<div class="info-card"><div style="text-align:center;font-size:13px;color:#889">完成株数：${S.completed} · 连续观察：${S.consecutive} 天</div></div>`;
    return;
  }
  const p=getPlant(S.plant.key);
  area.innerHTML=`<img class="plant-img" src="plants/${p.key}.png" onerror="this.src=''">
    <div style="font-size:90px;display:none">${p.emoji}</div>
    <div class="plant-stage">${p.name} · ${S.plant.stageName} · 第 ${S.plant.day} 天</div>`;
  info.innerHTML=`<div class="info-card">
    <div class="pname">${p.name}</div>
    <div class="bar-row"><span class="lb">水</span><div class="bar"><div class="bar-fill w" style="width:${S.plant.water}%"></div></div></div>
    <div class="bar-row"><span class="lb">肥</span><div class="bar"><div class="bar-fill f" style="width:${S.plant.food}%"></div></div></div>
    <div class="bar-row"><span class="lb">健</span><div class="bar"><div class="bar-fill h" style="width:${S.plant.health}%"></div></div></div>
  </div>`;
}

// ============ 照顧 ============
function doCare(type){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  const p=getPlant(S.plant.key);
  if(S.task_done.plant_care>=TASK_LIMIT.plant_care){ toast("今日照顾次数已满（3/3）"); }
  if(type==="water"){
    if(S.plant.water>85){ toast("植物现在不需要浇水哦 💧"); return; }
    S.plant.water=Math.min(100,S.plant.water+35);
    addPoints(1,"照顾植物"); S.task_done.plant_care++;
    toast("浇水完成 +1 分");
    splashWater();
  } else if(type==="fert"){
    S.plant.food=Math.min(100,S.plant.food+30);
    addPoints(1,"照顾植物"); S.task_done.plant_care++;
    toast("施肥完成 +1 分");
  }
  // 成長判斷
  maybeGrow();
  renderGarden();
}
function splashWater(){
  const area=document.getElementById("plant-area");
  for(let i=0;i<3;i++){
    const d=document.createElement("div");
    d.className="drop"; d.style.left=(35+i*12)+"%";
    d.style.animationDelay=(i*0.15)+"s";
    area.appendChild(d);
    setTimeout(()=>d.remove(),1800);
  }
}
function maybeGrow(){
  const p=getPlant(S.plant.key);
  // 簡單：水肥都 >70 且天數到，就進階
  const needDay=(S.plant.stageIdx+1)*2;
  if(S.plant.water>70 && S.plant.food>70 && S.plant.day>=needDay){
    if(S.plant.stageIdx < p.stages.length-1){
      S.plant.stageIdx++;
      S.plant.stageName=p.stages[S.plant.stageIdx];
      addPoints(5,"植物成长");
      toast("🌱 植物长大了："+S.plant.stageName);
      // 完成判斷
      if(S.plant.stageIdx===p.stages.length-1 && S.plant.day>=p.stages.length*2){
        completePlant();
      }
    }
  }
}
function completePlant(){
  const p=getPlant(S.plant.key);
  toast("🎉 完成一株 "+p.name+"！");
  S.completed++;
  if(!S.species.includes(p.key)) S.species.push(p.key);
  S.plant=null;
  setTimeout(()=>go("choose"),1200);
}

// ============ 觀察 ============
async function doObserve(type){
  if(!S.plant){ toast("先种一株植物吧"); return; }
  if(S.observed_today){ toast("今天已经检查过了，明天再来 🌿"); return; }
  // 呼叫系統 API
  const res = await API.observe(S.plant.plantId, type);
  S.observed_today=true;
  if(res && res.consecutive_days) S.consecutive = res.consecutive_days;
  else S.consecutive++;
  toast("今日检查完成（连续 "+S.consecutive+" 天）");
  if(res && res.streak_reward){ addPoints(20,"连续观察"); toast("🎉 连续7天观察 +20 分！"); }
  else if(!res && S.consecutive%7===0){ addPoints(20,"连续观察"); toast("🎉 连续7天观察 +20 分！"); }
}

// ============ 選擇種植 ============
function renderChoose(){
  const un=unlockedKeys();
  let h=`<div class="card"><div class="lbl">已完成 ${S.completed} 株 · 已解锁 ${un.length} / 17 种</div>
    <div style="font-size:12px;color:#889;line-height:1.6">完成 1 株解锁 4 种，完成 2 株再解锁 3 种，完成 3 株再解锁 3 种，完成 4 株（≥3 种不同）解锁全部。</div></div>
    <div class="plant-grid">`;
  PLANTS.forEach(p=>{
    const ok=un.includes(p.key);
    const lock=(S.plant&&S.plant.key===p.key)?"✅":"";
    h+=`<div class="plant-cell ${ok?'':'locked'}" onclick="${ok?`startPlant('${p.key}')`:`toast('未解锁')`}">
      <div class="pi"><img src="plants/${p.key}.png" style="width:44px;height:44px;object-fit:contain" onerror="this.outerHTML='<div style=font-size:30px>${p.emoji}</div>'"></div>
      <div class="pn">${p.name}</div>
      <div class="ps">${"★".repeat(p.star)}</div>
      ${ok?'':`<div class="lock">🔒</div>`}
    </div>`;
  });
  h+=`</div>`;
  document.getElementById("choose-content").innerHTML=h;
}
async function startPlant(key){
  if(S.plant){ toast("一次只能种一株，先完成现在的植物"); return; }
  const p=getPlant(key);
  // 呼叫系統 API
  const res = await API.startPlant(key, uuid());
  S.plant={key:key, plantId:(res&&res.plant_id)||null, stageIdx:0, stageName:p.stages[0], day:1, water:50, food:50, health:100};
  toast("种下了 "+p.name+" 🌱");
  go("garden");
}

// ============ 學習 ============
function renderLearn(){
  let h=`<div class="card"><div class="lbl">每日植物小知识 · 阅读可得 2 分</div></div>`;
  TIPS.forEach(t=>{
    h+=`<div class="card"><div style="font-size:14px;font-weight:700;color:#2E5D2A;margin-bottom:7px">${t.t}</div>
      <div style="font-size:12.5px;color:#5B6B57;line-height:1.7">${t.c}</div></div>`;
  });
  if(S.plant){
    const p=getPlant(S.plant.key);
    h+=`<div class="card" style="background:#EAF3E4"><div style="font-size:13px;font-weight:700;color:#2E5D2A">🌿 ${p.name} 养护重点</div>
      <div style="font-size:12.5px;color:#3A4A36;line-height:1.7;margin-top:6px">${p.tip}</div></div>`;
  }
  document.getElementById("learn-content").innerHTML=h;
}

// ============ 兌換 ============
function renderReward(){
  let h=`<div class="card"><div class="lbl">可用积分</div>
    <div style="font-size:25px;font-weight:700;color:#5E8A45">${availablePoints()}</div>
    <div style="font-size:11.5px;color:#889;margin-top:4px">总积分 ${S.points_total} · 待审核 ${S.points_pending} · 每人每月限换 1 件</div></div>`;
  REWARDS.forEach(r=>{
    const can=availablePoints()>=r.points;
    h+=`<div class="reward-item"><div><div class="rn">${r.name}</div><div class="rp">${r.points} 分</div></div>
      <button class="btn-redeem" ${can?"":"disabled"} onclick="doRedeem(${r.id})">申请</button></div>`;
  });
  if(S.reward_requests.length){
    h+=`<div class="section-title">我的申请</div>`;
    S.reward_requests.forEach(rq=>{
      h+=`<div class="card" style="padding:12px 15px"><div class="list-item" style="border:none;padding:0">
        <span>${rq.name} · ${rq.points} 分</span><span class="tag-avail">待审核</span></div></div>`;
    });
  }
  document.getElementById("reward-content").innerHTML=h;
}
async function doRedeem(id){
  const r=REWARDS.find(x=>x.id===id);
  if(availablePoints()<r.points){ toast("积分不足"); return; }
  if(S.reward_requests.length>=1){ toast("每人每月限换 1 件"); return; }
  const res = await API.redeem(id, uuid());
  S.points_pending+=r.points;
  S.reward_requests.push({id:id,name:r.name,points:r.points,status:"pending"});
  toast("已提交申请："+r.name);
  renderReward();
}

// ============ 花友中心 ============
function renderMember(){
  let h=`<div class="card"><div class="lbl">${S.code} · ${S.name} · ${S.tier}</div>
    <div class="stat-nums">
      <div><div class="n">${S.points_total}</div><div class="s">总积分</div></div>
      <div><div class="n">${S.points_pending}</div><div class="s">待审核</div></div>
      <div><div class="n">${availablePoints()}</div><div class="s">可用积分</div></div>
    </div></div>
    <div class="section-title">积分记录</div><div class="card">`;
  S.points_history.slice(0,8).forEach(p=>{
    h+=`<div class="list-item"><span>${p.reason} <span style="color:#AAB;font-size:10.5px">${p.date}</span></span>
      <span class="${p.change>=0?'pos':'neg'}">${p.change>=0?'+':''}${p.change}</span></div>`;
  });
  h+=`</div><div class="section-title">回馈金 <span class="pos">RM${S.rebate_total.toFixed(2)}</span></div><div class="card">`;
  S.rebate_batches.forEach(b=>{
    h+=`<div class="list-item"><span>${b.reason} <span style="color:#AAB;font-size:10.5px">${b.date}${b.exp?' · 至 '+b.exp:''}</span></span>
      <span class="${b.amount>=0?'pos':'neg'}">${b.amount>=0?'+':''}RM${Math.abs(b.amount).toFixed(2)}
      ${b.status==='available'?'<span class="tag-avail">可用</span>':'<span class="tag-exp">已用</span>'}</span></div>`;
  });
  h+=`</div>
    <div class="card" style="text-align:center">
      <button class="btn-main" onclick="go('task')">查看今日任务</button>
    </div>`;
  document.getElementById("member-content").innerHTML=h;
}

// ============ 任務 ============
function renderTask(){
  const done=S.task_done;
  let h=`<div class="card"><div class="lbl">今日已得</div>
    <div style="font-size:25px;font-weight:700;color:#5E8A45">${S.today_points} / ${DAILY_LIMIT} 分</div></div>
    <div class="card">`;
  const rows=[
    ["game_login","每日登入",2,done.game_login,TASK_LIMIT.game_login],
    ["plant_care","照顾植物",1,done.plant_care,TASK_LIMIT.plant_care],
    ["game_quiz","答对问答",5,done.game_quiz,TASK_LIMIT.game_quiz],
    ["plant_photo","分享植物",10,done.plant_photo,TASK_LIMIT.plant_photo],
  ];
  rows.forEach(([k,n,pt,d,l])=>{
    const full=d>=l;
    h+=`<div class="task-item"><span class="${full?'task-done':'task-todo'}">${full?'✓':'○'} ${n}</span>
      <span class="${full?'task-done':'task-todo'}">${d}/${l} · +${pt}</span></div>`;
  });
  h+=`</div><div class="card"><div class="lbl">连续观察</div>
    <div style="font-size:20px;font-weight:700;color:#5E8A45">${S.consecutive} 天</div>
    <div style="font-size:11.5px;color:#889;margin-top:4px">每连续 7 天 +20 分（不重叠周期）</div></div>`;
  document.getElementById("task-content").innerHTML=h;
}

// ============ 管理者 ============
function renderAdmin(){
  let h=`<div class="card"><div class="lbl">管理者模式</div>
    <div style="font-size:12.5px;color:#5B6B57;line-height:1.7">可查看任何会员的花园（只读诊断），或建立独立测试花园（不影响真实会员数据）。</div></div>
    <div class="section-title">会员花园（只读）</div>
    <div class="card"><div class="list-item"><span>XT-0001 enabelle</span><button class="btn-sm" onclick="toast('只读查看')">查看</button></div>
      <div class="list-item"><span>XT-0025 Kitty yws</span><button class="btn-sm" onclick="toast('只读查看')">查看</button></div>
      <div class="list-item"><span>XT-0017 Phyllis Tan</span><button class="btn-sm" onclick="toast('只读查看')">查看</button></div></div>
    <div class="section-title">测试花园</div>
    <div class="card"><div class="list-item"><span>我的测试花园</span><button class="btn-sm" onclick="toast('已进入测试花园（模拟，不扣真实积分）')">进入</button></div>
      <div class="list-item"><span>孩子的花园</span><button class="btn-sm" onclick="toast('已进入（模拟）')">进入</button></div></div>
    <div class="card" style="text-align:center"><button class="btn-main" onclick="go('garden')">回到我的花园</button></div>`;
  document.getElementById("admin-content").innerHTML=h;
}

// ============ 積分 ============
function addPoints(n,reason){
  if(S.today_points>=DAILY_LIMIT){ return; }
  const real=Math.min(n, DAILY_LIMIT-S.today_points);
  S.points_total+=real; S.today_points+=real;
  S.points_history.unshift({date:"今天",reason:reason,change:real});
}

// ============ 啟動 ============
renderApp();
