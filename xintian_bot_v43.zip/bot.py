#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
心田花友 Bot · XintianGardenBot
功能：欢迎、查积分、查回馈金、游戏入口、签到、活动上报
部署：放主機 /opt/xintian/bot/ 用 systemd 或 process 運行
"""
import os
import json
import asyncio
import logging
import random
from datetime import datetime, timezone, timedelta

import httpx
from telegram import (Update, InlineKeyboardButton, InlineKeyboardMarkup,
                      WebAppInfo, ReplyKeyboardMarkup, KeyboardButton,
                      ReplyKeyboardRemove)
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("xintian-bot")


# ===== 讀取環境設定檔 =====
def load_env_file(path):
    """從 /etc/xintian-bot.env 讀取 KEY=VALUE"""
    if not os.path.exists(path):
        return
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

load_env_file("/etc/xintian-bot.env")
load_env_file(os.path.join(os.path.dirname(__file__), ".env"))

# ===== 設定（從環境變數讀）=====
BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
BOT_KEY = os.environ.get("XINTIAN_BOT_API_KEY", "") or os.environ.get("XINTIAN_BOT_KEY", "")
API_BASE = os.environ.get("XINTIAN_API_BASE", "https://member.xintian.com.my")
GAME_URL = os.environ.get("XINTIAN_GAME_URL", "https://member.xintian.com.my/game-stage2/")
MEMBER_GROUP_ID = os.environ.get("XINTIAN_MEMBER_GROUP", "")   # 會員群 chat id
GROUP_INVITE_URL = os.environ.get("XINTIAN_GROUP_INVITE",
                                  "https://t.me/+RG2JZFtDkVphNmI1")  # 會員群邀請連結
MALAYSIA_TZ = timezone(timedelta(hours=8))

# ===== AI（Gemini）設定 =====
import base64
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-lite-latest")
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
AI_ENABLED = bool(GEMINI_API_KEY)

# 全域問句關鍵字（群/私聊共用）
Q_WORDS_ALL = ["?", "？", "什么", "什麼", "怎么", "怎麼", "为什么", "為什麼",
               "如何", "哪有", "哪里", "哪裡", "请问", "請問",
               "吗", "嗎", "是否", "对不对", "對不對",
               "有病", "有害虫", "有蟲", "怎么了", "怎麼了", "怎么办", "怎麼辦",
               "这是你", "這是你", "是你种", "是你種", "谁种", "誰種",
               "识别", "識別", "叫什么", "叫什麼", "正常吗", "正常嗎",
               "可以吗", "可以嗎", "会不会", "會不會", "枯", "黄", "黃", "烂", "爛"]

# ===== 圖片判斷緩衝（v22：動態等待，寫字慢的花友）=====
IMG_WAIT_SECONDS = int(os.environ.get("XINTIAN_IMG_WAIT_SECONDS", "30"))
PENDING_MEDIA = {}   # key -> {"msg","chat_type","uid","name","username","task","ts"}
MEDIA_TASKS = {}     # key -> asyncio.Task

# ===== 心田產品知識庫（肥料/藥劑）=====
KNOWLEDGE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "knowledge", "xintian_products.md")

def load_knowledge():
    try:
        with open(KNOWLEDGE_FILE, encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        log.warning("載入知識庫失敗: %s", e)
        return ""

XINTIAN_KNOWLEDGE = load_knowledge()

AI_SYSTEM_PROMPT = (
    "你是「心田花園管家」，馬來西亞園藝店 Xin Tian（心田）的植物助理，"
    "也是心田老師的助理。用繁體中文、親切、簡短（80 字內）回答植物照顧問題。"
    "說話像店裡的人，不要說自己是 AI、不要提機器人。\n\n"
    "【重要】你必須只輸出一個 JSON 物件，不要有其他文字、不要 markdown 圍欄：\n"
    '{"can_answer": true 或 false, "reply": "給花友的回覆"}\n\n'
    "can_answer=true 的情況：一般照顧問題（澆水、光照、施肥、換盆、常見蟲害、"
    "植物辨識、開花結果等），你有把握時。reply 用「心田老師提醒：…」開頭或自然語氣，"
    "內容具體、親切，不要加任何「請稍等」「轉人工」之類的話。\n"
    "can_answer=false 的情況：需要專業用藥劑量、嚴重病害診斷、會員/付款/續費/投訴/"
    "與植物無關的問題，或你不確定時。此時 reply 留空字串。\n\n"
    "【極重要】花友問的是「真實世界的植物照顧」，不是在問手機遊戲。"
    "絕對不要提「檢查」「移位」「除蟲」「澆水按鈕」「遊戲裡的植物」"
    "這類遊戲操作，也不要叫花友去遊戲裡做任何事。"
    "直接給真實園藝建議（實際的光照、澆水、通風、施肥、修剪、病蟲處理）。\n\n"
    "【心田產品與照顧知識庫】以下是心田店內實際產品與施肥原則，"
    "請在「適合且有幫助」時自然帶出推薦（先給照顧建議，最後一句輕帶產品，"
    "不主動報價、不硬銷、不承諾效果、只推薦知識庫裡有的品項）：\n"
    + XINTIAN_KNOWLEDGE
)


def now_my():
    return datetime.now(MALAYSIA_TZ)


# ===== 系統 API =====
async def api_get(path, params=None):
    if not BOT_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(API_BASE + path, params=params,
                            headers={"X-Xintian-Bot-Key": BOT_KEY})
            return r.json() if r.status_code == 200 else None
    except Exception as e:
        log.warning("api_get %s: %s", path, e)
        return None


async def api_post(path, body):
    if not BOT_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.post(API_BASE + path, json=body,
                             headers={"X-Xintian-Bot-Key": BOT_KEY})
            return r.json() if r.status_code == 200 else None
    except Exception as e:
        log.warning("api_post %s: %s", path, e)
        return None


async def api_post_full(path, body):
    """回傳 (status_code, json)；用於需要判斷非 200 結果的接口（發件隊列）。"""
    if not BOT_KEY:
        return (0, None)
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.post(API_BASE + path, json=body,
                             headers={"X-Xintian-Bot-Key": BOT_KEY})
            try:
                return (r.status_code, r.json())
            except Exception:
                return (r.status_code, None)
    except Exception as e:
        log.warning("api_post_full %s: %s", path, e)
        return (0, None)





# ===== AI 看圖 / 看文字回答（Gemini）=====
def _parse_ai_json(raw):
    """解析 AI 回傳的 JSON → (can_answer, reply)。解析失敗回 (True, raw)。"""
    if not raw:
        return (False, "")
    t = raw.strip()
    if t.startswith("```"):
        t = t.strip("`")
        if t.lower().startswith("json"):
            t = t[4:]
        t = t.strip()
    try:
        i, j = t.find("{"), t.rfind("}")
        if i >= 0 and j > i:
            obj = json.loads(t[i:j + 1])
            can = obj.get("can_answer")
            rep = (obj.get("reply") or "").strip()
            if can is None:
                return (True, t)
            if not can:
                # 不能回答，但若 AI 有給「安撫/引導」的句子 → 直接回那句
                if rep:
                    return (True, rep)
                return (False, "")
            return (True, rep)
    except Exception:
        pass
    # 解析不到 → 當作可回答（去掉可能的圍欄）
    return (True, t)


async def ask_gemini(text, image_bytes=None, mime="image/jpeg", timeout=20):
    """呼叫 Gemini；回傳 (can_answer, reply)。失敗回 (False, "")。"""
    if not GEMINI_API_KEY:
        return None
    try:
        parts = []
        if image_bytes:
            parts.append({
                "inline_data": {
                    "mime_type": mime,
                    "data": base64.b64encode(image_bytes).decode("ascii"),
                }
            })
        prompt = text or "請判斷這張植物照片的狀況並給建議。"
        parts.append({"text": prompt})
        body = {
            "system_instruction": {"parts": [{"text": AI_SYSTEM_PROMPT}]},
            "contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"temperature": 0.4, "maxOutputTokens": 400},
        }
        url = GEMINI_URL.format(model=GEMINI_MODEL)
        headers = {
            "x-goog-api-key": GEMINI_API_KEY,
            "Content-Type": "application/json",
        }
        data = None
        for attempt in range(3):
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.post(url, json=body, headers=headers)
            if r.status_code == 200:
                data = r.json()
                break
            if r.status_code in (503, 429, 500):
                log.info("gemini %s 塞車/限流，重試 %s/3", r.status_code, attempt + 1)
                await asyncio.sleep(2 * (attempt + 1))
                continue
            log.warning("gemini %s: %s", r.status_code, r.text[:200])
            return (False, "")
        if data is None:
            log.warning("gemini 重試後仍失敗")
            return (False, "")
        cands = data.get("candidates") or []
        if not cands:
            return (False, "")
        out = []
        for pt in cands[0].get("content", {}).get("parts", []):
            if pt.get("text"):
                out.append(pt["text"])
        raw = "\n".join(out).strip()
        return _parse_ai_json(raw)
    except Exception as e:
        log.warning("ask_gemini: %s", e)
        return (False, "")


async def download_media_bytes(bot, msg, max_bytes=5 * 1024 * 1024):
    """下載圖片/影片縮圖 bytes；超過大小回 None。"""
    try:
        media = None
        if msg.photo:
            media = msg.photo[-1]
        elif msg.video and msg.video.thumbnail:
            media = msg.video.thumbnail
        elif msg.animation and msg.animation.thumbnail:
            media = msg.animation.thumbnail
        if media is None:
            return None
        f = await bot.get_file(media.file_id)
        data = await f.download_as_bytearray()
        if len(data) > max_bytes:
            return None
        return bytes(data)
    except Exception as e:
        log.warning("download_media_bytes: %s", e)
        return None




# ===== v22：圖片動態等待（30 秒，有文字提前處理）=====
def _media_key(msg):
    return f"{msg.chat_id}:{msg.from_user.id}"

async def _after_media_wait(context, key):
    """等待結束（期間沒補文字）→ 判斷為「分享」（群）或問選單（私聊）"""
    try:
        await asyncio.sleep(IMG_WAIT_SECONDS)
    except asyncio.CancelledError:
        return
    pend = PENDING_MEDIA.pop(key, None)
    MEDIA_TASKS.pop(key, None)
    if not pend:
        return
    msg = pend["msg"]
    uid = pend["uid"]
    name = pend["name"]
    try:
        if pend["chat_type"] == "group":
            # 群：30 秒沒補文字 → 視為分享 +2 + 讚美
            res = await report_plant_photo(msg, uid, context.bot, intent="share")
            if res and res.get("ok") and not res.get("repeated"):
                pts = res.get("points", 2)
                praise = random.choice([
                    "哇，養得真好！🌿", "好美的植物，看著就療癒 🌸",
                    "這株照顧得很棒！🌱", "開花開果就是最開心的時刻 🎉",
                    "好美的畫面，感謝分享 🌷",
                ])
                await context.bot.send_message(
                    chat_id=msg.chat_id,
                    text=f"🌿 {name} {praise} +{pts} 分 🌸\n跟大家分享一下你怎麼養的吧～",
                    reply_to_message_id=msg.message_id,
                    allow_sending_without_reply=True)
            elif res and res.get("repeated"):
                await context.bot.send_message(
                    chat_id=msg.chat_id,
                    text=f"🌿 {name} 今天已經分享過啦，明天再來 🌸",
                    reply_to_message_id=msg.message_id,
                    allow_sending_without_reply=True)
        else:
            # 私聊：30 秒沒補文字 → 問意圖選單
            PENDING_IMAGES[str(uid)] = {"msg": msg, "chat_type": "private",
                                        "ts": _now_epoch()}
            await context.bot.send_message(chat_id=msg.chat_id, text=INTENT_MENU)
    except Exception as e:
        log.warning("_after_media_wait: %s", e)

def _schedule_media_wait(context, msg, uid, name, username, chat_type):
    key = _media_key(msg)
    PENDING_MEDIA[key] = {"msg": msg, "chat_type": chat_type, "uid": uid,
                          "name": name, "username": username, "ts": _now_epoch()}
    old = MEDIA_TASKS.pop(key, None)
    if old:
        old.cancel()
    MEDIA_TASKS[key] = asyncio.create_task(_after_media_wait(context, key))
    log.info("圖片等待 %ss 後判斷 (chat=%s)", IMG_WAIT_SECONDS, chat_type)

def _cancel_media_wait(msg):
    key = f"{msg.chat_id}:{msg.from_user.id}"
    t = MEDIA_TASKS.pop(key, None)
    if t:
        t.cancel()
    PENDING_MEDIA.pop(key, None)




# ===== v22/v23：媒體到達的統一處理（等待 + AI）=====
async def handle_group_media(context, msg, text, uid, name):
    """群裡收到 圖片/影片（有無文字）。"""
    caption = text
    is_q = bool(caption) and any(k in caption for k in Q_WORDS_ALL)
    if is_q:
        _cancel_media_wait(msg)
        await _group_question_flow(context, msg, caption, uid, name)
        return True
    if caption:
        # 有文字但不像問句 → 直接當分享
        _cancel_media_wait(msg)
        await _group_share_flow(context, msg, uid, name)
        return True
    # 無文字 → 動態等 30 秒
    _schedule_media_wait(context, msg, uid, name, msg.from_user.username or "", "group")
    return True

async def _group_share_flow(context, msg, uid, name):
    res = await report_plant_photo(msg, uid, context.bot, intent="share")
    if res and res.get("ok") and not res.get("repeated"):
        pts = res.get("points", 2)
        praise = random.choice([
            "哇，養得真好！🌿", "好美的植物，看著就療癒 🌸",
            "這株照顧得很棒！🌱", "開花開果就是最開心的時刻 🎉",
            "好美的畫面，感謝分享 🌷",
        ])
        try:
            await msg.reply_text(f"🌿 {name} {praise} +{pts} 分 🌸\n跟大家分享一下你怎麼養的吧～")
        except Exception:
            pass
    elif res and res.get("repeated"):
        try:
            await msg.reply_text(f"🌿 {name} 今天已經分享過啦，明天再來 🌸")
        except Exception:
            pass

async def _group_question_flow(context, msg, caption, uid, name):
    """群裡提問：先試 AI 回答；AI 不行才轉人工。"""
    # 先上報媒體（獎勵用，不給分）
    await report_plant_photo(msg, uid, context.bot, intent="question")

    # AI 嘗試回答
    ai_ans = None
    if AI_ENABLED:
        img = await download_media_bytes(context.bot, msg) if (msg.photo or msg.video or msg.animation) else None
        log.info("🤖 呼叫 AI（群圖/文字）caption=%r 帶圖=%s", caption, bool(img))
        can, ai_ans = await ask_gemini(caption, img)
        log.info("🤖 AI can_answer=%s 回覆=%r", can, (ai_ans or "(空)")[:200])
    else:
        log.info("⚠️ AI_ENABLED=False，跳過 AI")
        can = False

    if can and ai_ans:
        # AI 答得出來 → 直接回（引用原提問 + HTML mention）
        sent = False
        html_text = build_mention_text(msg.chat_id, uid, name, ai_ans)
        try:
            await context.bot.send_message(
                chat_id=msg.chat_id,
                text=html_text,
                parse_mode="HTML",
                reply_to_message_id=msg.message_id,
                allow_sending_without_reply=True)
            sent = True
        except Exception as e:
            log.warning("群 AI 回覆(引用)失敗: %s，改為不引用重試", e)
        if not sent:
            try:
                await context.bot.send_message(chat_id=msg.chat_id, text=ai_ans)
                sent = True
            except Exception as e:
                log.exception("群 AI 回覆(普通)也失敗: %s", e)
        log.info("✅ 群 AI 回覆已送出=%s", sent)
        if sent:
            await archive_ai_qa(msg.chat_id, uid, name,
                                (msg.from_user.username or ""),
                                msg.message_id, caption, ai_ans)
        return

    # 轉人工
    try:
        await msg.reply_text("🌿 你的問題比較特別，心田老師會親自回覆你，請稍等 🌸")
    except Exception:
        pass
    try:
        q_event = f"xintian-question-{uid}-{msg.message_id}"
        res_q = await api_post("/api/bot/messages", {
            "event_id": q_event,
            "chat_id": str(msg.chat_id),
            "tg_user_id": uid,
            "direction": "incoming",
            "text": caption or "(附圖提問)",
            "display_name": name,
            "username": (msg.from_user.username or ""),
            "telegram_message_id": str(msg.message_id),
            "occurred_at": now_my().isoformat(),
            "needs_human": True,
            "human_reason": "植物問題，需人工回答",
        })
        if res_q and res_q.get("ok") and (msg.photo or msg.video or msg.animation):
            await upload_question_image(msg, uid, context.bot, q_event)
    except Exception:
        pass


# ===== 待處理圖片暫存（發圖無文字 → 先問意圖）=====
PENDING_IMAGES = {}   # user_id -> {"msg": msg, "chat_type": "private"/"group", "ts": epoch}
PENDING_TTL = 900     # 15 分鐘

INTENT_MENU = (
    "🌿 收到你的照片了！請讓我知道具體你面臨的問題：\n\n"
    "1️⃣ 植物問題（請寫出問題）\n"
    "2️⃣ 已匯款續費會員\n"
    "3️⃣ 其他\n\n"
    "回覆數字即可，我來幫你處理 🌸"
)

def _now_epoch():
    return datetime.now(timezone.utc).timestamp()

def _set_pending(uid, msg, chat_type):
    PENDING_IMAGES[str(uid)] = {"msg": msg, "chat_type": chat_type, "ts": _now_epoch()}
    # 清過期
    for k in list(PENDING_IMAGES.keys()):
        if _now_epoch() - PENDING_IMAGES[k]["ts"] > PENDING_TTL:
            PENDING_IMAGES.pop(k, None)

def _pop_pending(uid):
    return PENDING_IMAGES.pop(str(uid), None)

def _is_menu_choice(text):
    t = (text or "").strip()
    return t in ["1", "2", "3", "１", "２", "３"]

async def _file_pending_as_question(bot, pend, uid, name, username, answer_text):
    """花友選 1 → 用暫存的圖 + 選項文字上報提問（進系統 + 上傳圖）"""
    msg = pend["msg"]
    today_iso = now_my().isoformat()
    eid = f"xintian-question-{uid}-{msg.message_id}"
    if pend["chat_type"] == "private":
        eid = f"xintian-question-pm-{uid}-{msg.message_id}"
    try:
        await report_plant_photo(msg, uid, bot, intent="question")
    except Exception:
        pass
    q_text = answer_text or "(附圖提問)"
    res = await api_post("/api/bot/messages", {
        "event_id": eid,
        "chat_id": str(msg.chat_id),
        "tg_user_id": str(uid),
        "direction": "incoming",
        "text": q_text,
        "display_name": name or "花友",
        "username": username or "",
        "telegram_message_id": str(msg.message_id),
        "occurred_at": today_iso,
        "needs_human": True,
        "human_reason": "植物問題，需人工回答",
    })
    if res and res.get("ok"):
        await upload_question_image(msg, uid, bot, eid)
    return res


# ===== 補填生日（綁定後若未填）=====
PENDING_BIRTHDAY = {}   # uid -> {"msg": msg, "ts": epoch}

async def submit_birthday(tg_user_id, contact_user_id, phone, birthday):
    """呼叫 POST /api/bot/members/birthday"""
    if not BOT_KEY:
        return None
    try:
        return await api_post("/api/bot/members/birthday", {
            "tg_user_id": str(tg_user_id),
            "contact_user_id": str(contact_user_id),
            "phone": phone,
            "birthday": birthday,
        })
    except Exception as e:
        log.warning("submit_birthday: %s", e)
        return None

def _parse_birthday(t):
    """解析生日輸入 → YYYY-MM-DD。支援 1990-08-26 / 1990/8/26 / 19900826 / 26-08-1990"""
    import re
    t = (t or "").strip()
    m = re.match(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$", t)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m2 = re.match(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$", t)
        if m2:
            d, mo, y = int(m2.group(1)), int(m2.group(2)), int(m2.group(3))
        else:
            m3 = re.match(r"^(\d{4})(\d{2})(\d{2})$", t)
            if not m3:
                return None
            y, mo, d = int(m3.group(1)), int(m3.group(2)), int(m3.group(3))
    if not (1900 <= y <= 2100 and 1 <= mo <= 12 and 1 <= d <= 31):
        return None
    return f"{y:04d}-{mo:02d}-{d:02d}"


def ask_birthday_kb():
    return None


# ===== G. HTML mention（用 tg_user_id 做真標記）=====
def _html_escape(t):
    return (str(t or "")
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

def build_mention_text(chat_id, uid, display_name, body):
    """群回覆：用 <a href="tg://user?id=...">名字</a> 真 mention，訊息內容已轉義。"""
    try:
        who = _html_escape(display_name or "花友")
        return f'🌿 <a href="tg://user?id={uid}">{who}</a> 回覆你的問題：\n{_html_escape(body)}'
    except Exception:
        return None


# ===== E. AI 問答歸檔（提問 + AI 回答）=====
async def archive_ai_qa(chat_id, uid, name, username, telegram_message_id,
                        question_text, ai_reply, is_private=False):
    """把「花友提問」與「AI 回答」各記一筆到 /api/bot/messages（needs_human=false）。"""
    if not BOT_KEY:
        return
    try:
        prefix = "xintian-aiq-pm" if is_private else "xintian-aiq"
        q_event = f"{prefix}-{uid}-{telegram_message_id}"
        now = now_my().isoformat()
        # 1) 提問（incoming）
        await api_post("/api/bot/messages", {
            "event_id": q_event,
            "chat_id": str(chat_id),
            "tg_user_id": str(uid),
            "direction": "incoming",
            "text": question_text or "(提問)",
            "display_name": name or "花友",
            "username": username or "",
            "telegram_message_id": str(telegram_message_id),
            "occurred_at": now,
            "needs_human": False,
            "human_reason": "",
        })
        # 2) AI 回答（outgoing，關聯原提問）
        if ai_reply:
            await api_post("/api/bot/messages", {
                "event_id": (f"{prefix}-ans-{uid}-{telegram_message_id}")[:150],
                "chat_id": str(chat_id),
                "tg_user_id": str(uid),
                "direction": "outgoing",
                "text": ai_reply,
                "display_name": name or "花友",
                "username": username or "",
                "telegram_message_id": "",
                "occurred_at": now,
                "needs_human": False,
                "human_reason": "",
                "reply_to_event": q_event,
            })
        log.info("🗂️ AI 問答已歸檔 event=%s", q_event)
    except Exception as e:
        log.warning("archive_ai_qa: %s", e)


# ===== 遊戲 FAQ =====
GAME_FAQ = {
  "怎么玩": "🌱 心田花园怎么玩\n\n1. 点「进入心田花园」种一株植物\n2. 每天回来照顾它（浇水/施肥/除虫/检查）\n3. 植物会慢慢长大，完成后解锁更多品种\n4. 照顾和答题都能拿积分，积分可兑换礼物 🌸\n\n有不懂的随时问我～",
  "怎么种": "🌱 点「进入心田花园」→ 选一株植物 → 就种下了。\n新手可以先种：石莲花、小白菜、薰衣草，都比较简单 🌿",
  "怎么积分": "⭐ 积分怎么拿\n\n• 每天签到 +5\n• 群互动 +2\n• 答对植物问答 +5\n• 游戏里照顾植物 +1\n• 分享植物照片 +10\n• 推荐新花友 +20\n\n每天上限 25 分，积分永久累积不归零 🌸",
  "怎么兑换": "🎁 积分满 300 就能兑换：\n随机小植物盲盒 400 / RM10 voucher 500 /\n香草多肉 600 / 自制肥料 700 /\n植物数字学解读 900 / 高值植物 2000\n\n在花园里点「兑换」提交申请，我们会审核 🌿",
  "怎么浇水": "💧 遊戲裡澆水看植物需不需要：\n水分低于 80% 才能浇，一天一次。\n多肉不用天天浇，叶菜要常保湿哦 🌿",
  "怎么施肥": "🌾 遊戲裡施肥要选对肥料！\n每种植物需要的肥料不同，\n进入花园点「施肥」→ 选正确的肥料组合 🌸\n（真实养护时肥料要 2 星期轮流使用）",
  "游戏生病": "🐛 遊戲裡的植物生病了？\n先点「检查」看状态报告，\n如果是因为位置不对（光照/通风），用「移位」调整。\n有害虫就点「除虫」，选正确的处理方式 🌿",
  "游戏枯萎": "🥀 遊戲裡的植物打蔫了？\n通常是缺水或缺养分，先点「检查」看看。\n放心，游戏里的植物不会死，只会打蔫，照顾回来就好 🌸",
}

# 遊戲相關詞（必須同時出現，避免誤觸真實植物問題）
GAME_HINTS = ["游戏", "遊戲", "花园", "花園", "心田花園", "心田花园", "进去种", "進去種", "app", "APP"]

def match_faq(text):
    """只有在「明確提到遊戲」時才回遊戲 FAQ，避免搶走真實植物問題。"""
    if not any(g in text for g in GAME_HINTS):
        return None
    for k, v in GAME_FAQ.items():
        if k in text:
            return v
    return None

# ===== /start 歡迎 =====
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    name = update.effective_user.first_name or "花友"
    async def _send(t, **kw):
        if update.callback_query:
            await update.callback_query.edit_message_text(t, **kw)
        else:
            await update.message.reply_text(t, **kw)
    text = (
        f"🌿 *歡迎來到心田花友俱樂部*\n"
        f"Hello，{name}！我是心田花園管家 🌱\n\n"
        f"請選擇你要的服務：\n"
        f"🔗 已是會員 → 綁定你的 TG\n"
        f"🎁 消費滿 RM50 → 申請體驗\n"
        f"💳 已付款 / 會員到期 → 提交續費\n\n"
        f"（其他查詢：輸入 積分 / 回饋金 / 遊戲）"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 綁定已有會員", callback_data="member_bind")],
        [InlineKeyboardButton("🎁 申請體驗會員", callback_data="trial_apply")],
        [InlineKeyboardButton("💳 提交續費", callback_data="renew_submit")],
        [InlineKeyboardButton("🌱 進入心田花園", web_app=WebAppInfo(url=GAME_URL))],
    ])
    await _send(text, parse_mode="Markdown", reply_markup=kb)


# ===== 查积分 =====
async def cmd_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid = str(update.effective_user.id)
    data = await api_get("/api/bot/member", {"tg_user_id": tid})
    async def _send(t, **kw):
        if update.callback_query:
            await update.callback_query.edit_message_text(t, **kw)
        else:
            await update.message.reply_text(t, **kw)
    if not data or not data.get("member"):
        await _send("我还不知道你是谁呢～\n先输入 *绑定*，或用你的会员电话绑定一下 🌿",
                    parse_mode="Markdown")
        return
    m = data["member"]
    tier_map = {"friend": "花友", "paid": "付費會員", "vip": "VIP", "elder": "元老"}
    tier = tier_map.get((m.get("tier") or "").lower(), m.get("tier") or "—")
    active = m.get("membership_active")
    expiry = m.get("expiry_date") or ""
    if active is True:
        status_line = f"✅ 會籍：有效（{tier}）" + (f"\n📅 到期日：{expiry}" if expiry else "\n📅 到期日：永久")
    elif active is False:
        status_line = f"⚠️ 會籍：已到期（{tier}）" + (f"\n📅 到期日：{expiry}" if expiry else "")
    else:
        status_line = f"👤 身份：{tier}"
    text = (
        f"🌿 *{m.get('name','花友')}* 的賬戶\n"
        f"─────────────\n"
        f"{status_line}\n"
        f"⭐ 總積分：{m.get('points_total',0)}\n"
        f"✅ 可用積分：{m.get('points_available',0)}\n"
        f"💰 回饋金：RM{float(m.get('rebate_available',0)):.2f}\n"
        f"─────────────\n"
        f"想兌換禮物？進入花園看看吧 🌸"
    )
    if active is False:
        text += "\n\n💡 會籍已到期，續費後即可恢復會員權益（輸入「續費」或按 /start）🌿"
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("🌱 进入心田花园", web_app=WebAppInfo(url=GAME_URL))
    ]])
    await _send(text, parse_mode="Markdown", reply_markup=kb)


# ===== 签到 =====
async def do_checkin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid = str(update.effective_user.id)
    today = now_my().strftime("%Y-%m-%d")
    body = {
        "event_id": f"xintian-bot-checkin-{tid}-{today.replace('-','')}",
        "tg_user_id": tid,
        "task_key": "checkin",
        "proof_id": f"checkin:{tid}:{today}",
        "occurred_at": now_my().isoformat(),
        "verified": True,
        "verification_ref": f"telegram:{update.effective_message.message_id}",
        "progress": {}
    }
    res = await api_post("/api/bot/activities", body)
    if res and res.get("ok"):
        pts = res.get("points", 0)
        total = res.get("points_total", "")
        rep = "（今天已签到）" if res.get("repeated") else ""
        msg = f"✅ 签到成功 +{pts} 分 {rep}"
        if total != "":
            msg += f"\n目前共 {total} 分 🌿"
    else:
        msg = "签到需要先绑定会员哦～\n请用 *绑定* 完成绑定 🌿"
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(msg, parse_mode="Markdown")
    else:
        await update.message.reply_text(msg, parse_mode="Markdown")


# ===== 訊息處理 =====
async def on_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        await _on_message_inner(update, ctx)
    except Exception as e:
        log.exception("on_message 未預期錯誤: %s", e)


async def _on_message_inner(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    # 只處理私聊（群訊息交給 on_group_message）
    if update.effective_chat and update.effective_chat.type != "private":
        return
    text = (update.message.text or update.message.caption or "").strip()
    msg = update.message
    log.info("📩 私聊訊息 uid=%s text=%r photo=%s", update.effective_user.id, text[:60], bool(msg.photo))
    uid_s = str(update.effective_user.id)
    name_s = update.effective_user.first_name or "花友"
    uname_s = update.effective_user.username or ""

    # --- 處理「電話聯繫卡」（綁定會員用）---
    if msg.contact:
        contact = msg.contact
        phone = (contact.phone_number or "").strip()
        if phone and not phone.startswith("+"):
            phone = "+" + phone.lstrip("0") if phone.startswith("0") else "+" + phone
        c_uid = str(contact.user_id) if contact.user_id else uid_s
        log.info("📇 contact.user_id=%s -> 使用 c_uid=%s", contact.user_id, c_uid)
        log.info("📇 收到聯繫卡 phone=%s contact_user_id=%s", phone, c_uid)
        # 移除「分享電話」鍵盤
        try:
            await update.message.reply_text("收到你的號碼，處理中…",
                                            reply_markup=ReplyKeyboardRemove())
        except Exception:
            pass
        if c_uid and c_uid != uid_s:
            await update.message.reply_text(
                "⚠️ 請按按鈕分享 *你自己的* 電話號碼（不要分享他人的）🌿")
            return
        res = await api_post("/api/bot/members/bind", {
            "tg_user_id": uid_s,
            "contact_user_id": c_uid,
            "phone": phone,
        })
        if res and res.get("ok", True) and not res.get("error"):
            m = (res.get("member") or {})
            nm = m.get("name") or name_s
            bd = m.get("birthday") or res.get("birthday")
            code = m.get("member_code") or res.get("member_code") or ""
            tier = m.get("tier") or res.get("tier") or ""
            # 回傳缺欄位 → 再查一次會員資料
            if not code or not tier or not bd:
                try:
                    info = await api_get("/api/bot/member", {"tg_user_id": uid_s})
                    mm = (info or {}).get("member") or {}
                    nm = mm.get("name") or nm
                    code = code or mm.get("member_code") or ""
                    tier = tier or mm.get("tier") or ""
                    if not bd:
                        bd = mm.get("birthday")
                except Exception:
                    pass
            tier_map = {"friend": "花友", "paid": "付費會員", "vip": "VIP", "elder": "元老"}
            tier_show = tier_map.get((tier or "").lower(), tier)
            if code and tier_show:
                id_line = f"你是 {code}（{tier_show}）"
            elif code:
                id_line = f"你是 {code}"
            elif tier_show:
                id_line = f"你的身份：{tier_show}"
            else:
                id_line = "你已是心田會員"
            kb_join = InlineKeyboardMarkup([[
                InlineKeyboardButton("🌸 加入心田花友群", url=GROUP_INVITE_URL)
            ], [
                InlineKeyboardButton("🌱 進入心田花園", web_app=WebAppInfo(url=GAME_URL))
            ]])
            await update.message.reply_text(
                f"✅ 綁定成功！歡迎 {nm} 🌿\n"
                f"{id_line}\n\n"
                f"點下方按鈕加入花友群 👇",
                reply_markup=kb_join)
            if not bd:
                PENDING_BIRTHDAY[uid_s] = {"phone": phone, "ts": _now_epoch()}
                await update.message.reply_text(
                    "🎂 為了你的生日福利，請輸入你的生日（例：1990-08-26）🌿")
            else:
                await update.message.reply_text(
                    "你的資料已完整，祝養花愉快 🌸\n（查詢：輸入「積分」或「回饋金」）")
        else:
            await update.message.reply_text(
                "⚠️ 找不到對應會員或電話不符，已轉交客服為你核對 🌸")
            try:
                await api_post("/api/bot/messages", {
                    "event_id": f"xintian-bindfail-{uid_s}-{msg.message_id}",
                    "chat_id": uid_s, "tg_user_id": uid_s,
                    "direction": "incoming",
                    "text": f"綁定失敗：電話 {phone}",
                    "display_name": name_s, "username": uname_s,
                    "telegram_message_id": str(msg.message_id),
                    "occurred_at": now_my().isoformat(),
                    "needs_human": True,
                    "human_reason": "綁定失敗，需人工核對",
                })
            except Exception:
                pass
        return

    # --- 先處理「補填生日」回應 ---
    bpend = PENDING_BIRTHDAY.get(uid_s)
    if bpend:
        bd = _parse_birthday(text)
        if bd:
            PENDING_BIRTHDAY.pop(uid_s, None)
            res = await submit_birthday(uid_s, uid_s, bpend.get("phone", ""), bd)
            if res and (res.get("ok") or res.get("birthday")):
                await update.message.reply_text(
                    f"🎂 生日已登記：{bd}\n祝福你的植物和你一起健康成長 🌿")
            else:
                await update.message.reply_text(
                    "⚠️ 生日登記失敗，請稍後再試或聯絡客服 🌸")
            return
        else:
            # 不是有效日期 → 不當生日處理，繼續往下（避免卡住）
            if len(text) >= 6:
                PENDING_BIRTHDAY.pop(uid_s, None)

    # --- 先處理「意圖選單」回應（發圖無文字後，花友回 1/2/3）---
    pend = PENDING_IMAGES.get(uid_s)
    if pend and _is_menu_choice(text):
        _pop_pending(uid_s)
        choice = text.strip().translate(str.maketrans("１２３", "123"))
        if choice == "1":
            await update.message.reply_text("🌿 好的，正在為你查看…")
            # AI 先答（用暫存圖）
            answered = False
            if AI_ENABLED:
                img = await download_media_bytes(ctx.bot, pend.get("msg"))
                can, ai_ans = await ask_gemini("請看這張植物照片並提供建議。", img)
                if can and ai_ans:
                    await update.message.reply_text(ai_ans)
                    answered = True
            if not answered:
                await _file_pending_as_question(ctx.bot, pend, uid_s, name_s, uname_s,
                                                "(附圖提問)")
                await update.message.reply_text(
                    "🌿 你的問題比較特別，心田老師會親自回覆你，請稍等 🌸")
        elif choice == "2":
            await update.message.reply_text(
                "💳 續費會員：請把 *匯款收據* 發給我，或到會員系統提交續費證明 🌿\n"
                "（心田老師會核對後為你開通）", parse_mode="Markdown")
        else:
            await update.message.reply_text("🌿 好的，請直接說你要問的問題或需求，我幫你轉給心田老師 🌸")
        return

    if any(k in text for k in ["积分", "積分", "回馈金", "回饋金", "回款金", "rebate", "points", "积分查询"]):
        await cmd_points(update, ctx)
    elif any(k in text for k in ["签到", "簽到", "打卡", "checkin"]):
        await update.message.reply_text(
            "✅ 签到是在 *会员群* 里进行的哦～\n\n"
            "每天早上我会在群里提醒，\n"
            "你在群里发「早安」「打卡」或「签到」就完成签到了 🌿",
            parse_mode="Markdown")
    elif any(k in text for k in ["绑定", "綁定", "bind"]):
        await update.message.reply_text(
            "请发送你的会员电话（例如 0122542466），我帮你绑定 🌿")
    elif any(k in text for k in ["游戏", "遊戲", "花园", "花園", "game"]):
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🌱 进入心田花园", web_app=WebAppInfo(url=GAME_URL))
        ]])
        await update.message.reply_text("点下方按钮进入你的花园 🌸", reply_markup=kb)
    elif text.lower() in ["hi", "hello", "你好", "早安", "嗨"]:
        await cmd_start(update, ctx)
    else:
        # 遊戲 FAQ
        faqans = match_faq(text)
        if faqans:
            await update.message.reply_text(faqans, parse_mode="Markdown")
            return
        # 圖片/影片「無文字」→ 動態等 30 秒（等花友補文字；沒補才問意圖）
        if (msg.photo or msg.video or msg.animation) and not text:
            _schedule_media_wait(ctx, msg, uid_s, name_s, uname_s, "private")
            return
        # 植物問題 → AI 優先回答；答不了才轉人工（私聊問 → 私聊答）
        uid = str(update.effective_user.id)
        name = update.effective_user.first_name or "花友"
        msg = update.message
        try:
            if msg.photo or msg.video or msg.animation:
                await report_plant_photo(msg, uid, ctx.bot, intent="question")
        except Exception:
            pass
        # AI 嘗試回答（有圖就帶圖）
        if AI_ENABLED:
            img = await download_media_bytes(ctx.bot, msg) if (msg.photo or msg.video or msg.animation) else None
            log.info("🤖 呼叫 AI（私聊）text=%r 帶圖=%s", text, bool(img))
            can, ai_ans = await ask_gemini(text, img)
            log.info("🤖 AI can_answer=%s 回覆=%r", can, (ai_ans or "(空)")[:200])
            if can and ai_ans:
                await update.message.reply_text(ai_ans)
                await archive_ai_qa(update.effective_chat.id, uid, name_s,
                                    uname_s, msg.message_id, text, ai_ans,
                                    is_private=True)
                return
        try:
            pm_event = f"xintian-question-pm-{uid}-{msg.message_id}"
            res_pm = await api_post("/api/bot/messages", {
                "event_id": pm_event,
                "chat_id": uid,
                "tg_user_id": uid,
                "direction": "incoming",
                "text": text or "(私聊提問)",
                "display_name": name,
                "username": (update.effective_user.username or ""),
                "telegram_message_id": str(msg.message_id),
                "occurred_at": now_my().isoformat(),
                "needs_human": True,
                "human_reason": "植物問題，需人工回答（私聊）",
            })
            if res_pm and res_pm.get("ok") and (msg.photo or msg.video or msg.animation):
                await upload_question_image(msg, uid, ctx.bot, pm_event)
        except Exception:
            pass
        await update.message.reply_text(
            "🌿 收到你的問題！\n如果我能答會直接告訴你；\n"
            "太複雜的話，我會轉給心田老師回你 🌸")




import hashlib

async def report_plant_photo(msg, uid, bot, intent="share"):
    """群圖片/影片分享：下載 + SHA256 + 上報 /api/bot/plant-photos（含 intent）
    回傳 dict；失敗回 None。成功時含 photo_sha256 / photo_file_id 供後續提問存圖用。"""
    if not BOT_KEY:
        return None
    try:
        # 照片取最大尺寸；影片取 video
        media = None
        if msg.photo:
            media = msg.photo[-1]
        elif msg.video:
            media = msg.video
        elif msg.animation:
            media = msg.animation
        if media is None:
            return None
        file = await bot.get_file(media.file_id)
        data = await file.download_as_bytearray()
        sha = hashlib.sha256(bytes(data)).hexdigest()
        body = {
            "chat_id": str(msg.chat_id),
            "message_id": str(msg.message_id),
            "tg_user_id": uid,
            "photo_unique_id": media.file_unique_id,
            "photo_sha256": sha,
            "occurred_at": now_my().isoformat(),
            "verification_ref": f"telegram:{msg.chat_id}:{msg.message_id}",
            "intent": intent
        }
        res = await api_post("/api/bot/plant-photos", body)
        if isinstance(res, dict):
            res.setdefault("photo_sha256", sha)
            res.setdefault("photo_file_id", media.file_id)
        return res
    except Exception as e:
        log.warning("report_plant_photo failed: %s", e)
        return None

async def upload_question_image(msg, uid, bot, event_id):
    """上傳提問圖片到 /api/bot/message-images（multipart）。
    先上報 /api/bot/messages 成功後才呼叫。支援多張（≤10），單張 ≤5MB。"""
    if not BOT_KEY:
        return
    try:
        photos = []
        if msg.photo:
            photos = [msg.photo[-1]]          # 只取最大尺寸那張
        elif msg.video and msg.video.thumbnail:
            photos = [msg.video.thumbnail]
        elif msg.animation and msg.animation.thumbnail:
            photos = [msg.animation.thumbnail]
        if not photos:
            return
        for photo in photos[:10]:
            try:
                file = await bot.get_file(photo.file_id)
                data = await file.download_as_bytearray()
                if len(data) > 5 * 1024 * 1024:
                    log.info("提問圖片超過 5MB，跳過 event=%s", event_id)
                    continue
                meta = json.dumps({
                    "question_event_id": event_id,
                    "chat_id": str(msg.chat_id),
                    "tg_user_id": str(uid),
                }, ensure_ascii=False)
                files = {
                    "metadata": (None, meta, "application/json"),
                    "file": ("image.jpg", bytes(data), "image/jpeg"),
                }
                async with httpx.AsyncClient(timeout=30) as c:
                    r = await c.post(API_BASE + "/api/bot/message-images",
                                     data=None, files=files,
                                     headers={"X-Xintian-Bot-Key": BOT_KEY})
                log.info("message-images event=%s -> %s", event_id, r.status_code)
            except Exception as e:
                log.warning("upload_question_image 單張失敗: %s", e)
    except Exception as e:
        log.warning("upload_question_image: %s", e)


# ===== 群訊息處理（簽到 / 互動 / 群id / 照片）=====
async def on_group_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        await _on_group_message_inner(update, ctx)
    except Exception as e:
        log.exception("on_group_message 未預期錯誤: %s", e)


async def _on_group_message_inner(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg:
        return
    uid = str(msg.from_user.id)
    name = msg.from_user.first_name or "花友"
    today = now_my().strftime("%Y-%m-%d")
    text = (msg.text or "").strip()
    log.info("📩 群訊息 chat=%s uid=%s text=%r photo=%s",
             msg.chat_id, uid, text[:60], bool(msg.photo))

    # --- 管理員查群 ID ---
    if text in ["群id", "群ID", "chatid", "群号", "群號"]:
        await msg.reply_text(f"本群 ID：`{msg.chat_id}`\n請把這串給心田管理員設定 🌿",
                             parse_mode="Markdown")
        return

    # --- 照片/影片訊息（v22：動態等待 30 秒；v23：AI 回答）---
    if msg.photo or msg.video or msg.animation or msg.caption:
        caption = (msg.caption or "").strip()
        await handle_group_media(ctx, msg, caption, uid, name)
        return

    if not text:
        return

    # --- 群裡純文字提問 → AI 優先，答不了才轉人工 ---
    if len(text) >= 3 and any(k in text for k in Q_WORDS_ALL):
        log.info("❓ 判定為群提問 → 進 AI")
        ai_ans = None
        if AI_ENABLED:
            log.info("🤖 呼叫 AI（群純文字）text=%r", text)
            can, ai_ans = await ask_gemini(text)
            log.info("🤖 AI can_answer=%s 回覆=%r", can, (ai_ans or "(空)")[:200])
        else:
            log.info("⚠️ AI_ENABLED=False，跳過 AI")
            can, ai_ans = False, ""
        if can and ai_ans:
            sent = False
            html_text = build_mention_text(msg.chat_id, uid, name, ai_ans)
            try:
                await ctx.bot.send_message(
                    chat_id=msg.chat_id, text=html_text, parse_mode="HTML",
                    reply_to_message_id=msg.message_id,
                    allow_sending_without_reply=True)
                sent = True
            except Exception as e:
                log.warning("群 AI 回覆(引用)失敗: %s，改為不引用重試", e)
            if not sent:
                try:
                    await ctx.bot.send_message(chat_id=msg.chat_id, text=ai_ans)
                    sent = True
                except Exception as e:
                    log.exception("群 AI 回覆(普通)也失敗: %s", e)
            log.info("✅ 群 AI 回覆已送出=%s", sent)
            if sent:
                await archive_ai_qa(msg.chat_id, uid, name,
                                    (msg.from_user.username or ""),
                                    msg.message_id, text, ai_ans)
            return
        try:
            await msg.reply_text(
                f"🌿 你的問題比較特別，心田老師會親自回覆你，請稍等 🌸")
        except Exception:
            pass
        try:
            await api_post("/api/bot/messages", {
                "event_id": f"xintian-question-{uid}-{msg.message_id}",
                "chat_id": str(msg.chat_id),
                "tg_user_id": uid,
                "direction": "incoming",
                "text": text,
                "display_name": name,
                "username": (msg.from_user.username or ""),
                "telegram_message_id": str(msg.message_id),
                "occurred_at": now_my().isoformat(),
                "needs_human": True,
                "human_reason": "植物問題，需人工回答",
            })
        except Exception:
            pass
        return

    # --- 積分 / 回饋金查詢（群裡也可查）---
    if any(k in text for k in ["我的积分", "我的積分", "查积分", "查積分",
                               "我的回馈金", "我的回饋金", "查回馈金", "查回饋金"]):
        try:
            data = await api_get("/api/bot/member", {"tg_user_id": uid})
            if data and data.get("member"):
                m = data["member"]
                await msg.reply_text(
                    f"🌿 {m.get('name','花友')} 的賬戶\n"
                    f"─────────────\n"
                    f"⭐ 總積分：{m.get('points_total',0)}\n"
                    f"✅ 可用積分：{m.get('points_available',0)}\n"
                    f"💰 回饋金：RM{float(m.get('rebate_available',0)):.2f}",
                    reply_to_message_id=msg.message_id,
                    allow_sending_without_reply=True)
            else:
                await msg.reply_text("🌿 我還不知道你是誰～請私聊我輸入「綁定」哦 🌸",
                                     reply_to_message_id=msg.message_id,
                                     allow_sending_without_reply=True)
        except Exception:
            pass
        return

    # --- 簽到：早安 / 打卡 / 签到 ---
    if any(k in text for k in ["早安", "打卡", "签到", "簽到", "morning"]) and len(text) <= 12:
        body = {
            "event_id": f"xintian-group-checkin-{uid}-{today.replace('-','')}",
            "tg_user_id": uid,
            "task_key": "checkin",
            "proof_id": f"checkin:{uid}:{today}",
            "occurred_at": now_my().isoformat(),
            "verified": True,
            "verification_ref": f"telegram:{msg.message_id}",
            "progress": {}
        }
        res = await api_post("/api/bot/activities", body)
        if res and res.get("ok") and not res.get("repeated"):
            try:
                await msg.reply_text(f"✅ {name} 早安打卡成功 +{res.get('points',5)} 分 🌿")
            except Exception:
                pass
        return

    # --- 一般群互動（+2，不回應）---
    if len(text) >= 4:
        body = {
            "event_id": f"xintian-interact-{uid}-{msg.message_id}",
            "tg_user_id": uid,
            "task_key": "interaction",
            "proof_id": f"interaction:{uid}:{msg.message_id}",
            "occurred_at": now_my().isoformat(),
            "verified": True,
            "verification_ref": f"telegram:{msg.message_id}",
            "progress": {}
        }
        await api_post("/api/bot/activities", body)



# ===== 每日早安（08:30 馬來西亞時間）=====
GROUP_CHAT_ID = os.environ.get("XINTIAN_GROUP_ID", "")

async def daily_morning(context: ContextTypes.DEFAULT_TYPE):
    if not GROUP_CHAT_ID:
        return
    try:
        await context.bot.send_message(
            chat_id=GROUP_CHAT_ID,
            text="🌱 早安，花友们！\n\n新的一天，你的植物也在等你 🌿\n\n"
                 "记得在群里发「早安」或「打卡」签到，+5 积分哦～\n"
                 "今天也一起把绿意带回家 🌸")
    except Exception as e:
        log.warning("morning failed: %s", e)

# ===== callback =====
async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if q.data == "check_points":
        await q.answer()
        await cmd_points(update, ctx)
    elif q.data == "checkin":
        await do_checkin(update, ctx)
    elif q.data in ("bind", "member_bind"):
        await q.answer()
        try:
            await q.edit_message_text(
                "🔗 *綁定已有會員*\n\n"
                "請點下方按鈕 *分享你的電話號碼*，\n"
                "我會用它找到你的會員資料並綁定 🌿\n\n"
                "（若尚未在 FB 付款成為會員，請選「申請體驗」）",
                parse_mode="Markdown")
        except Exception:
            pass
        kb = ReplyKeyboardMarkup(
            [[KeyboardButton("📱 分享我的電話號碼", request_contact=True)]],
            one_time_keyboard=True, resize_keyboard=True)
        await q.message.reply_text("請按下方按鈕 👇", reply_markup=kb)
    elif q.data == "trial_apply":
        await q.answer()
        await q.edit_message_text(
            "🎁 *申請體驗會員*\n\n"
            "條件：單筆消費滿 RM50、未曾領取過體驗。\n\n"
            "請分享你的 *電話聯繫卡*，我會為你核對訂單 🌿\n"
            "（核對功能即將開放，目前請先聯絡客服）",
            parse_mode="Markdown")
    elif q.data == "renew_submit":
        await q.answer()
        await q.edit_message_text(
            "💳 *提交續費*\n\n"
            "請提供：\n"
            "1️⃣ 付款憑證（截圖）\n"
            "2️⃣ 金額\n"
            "3️⃣ 付款日期\n"
            "4️⃣ 交易編號\n\n"
            "提交後會由店員核對到賬，確認後為你延長會籍 🌿\n"
            "（提交功能即將開放，目前請先私聊客服）",
            parse_mode="Markdown")


# ===== 新成員歡迎 =====
async def on_new_member(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    for m in update.message.new_chat_members:
        if m.is_bot:
            continue
        name = m.first_name or "花友"
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🌱 进入心田花园", web_app=WebAppInfo(url=GAME_URL))
        ]])
        await update.message.reply_text(
            f"🎉 歡迎 {name} 加入心田花友俱樂部！🌿\n\n"
            f"這裡有植物照顧知識、花友交流、會員專屬福利 🌸\n\n"
            f"💡 貼心提醒（請私聊我查詢）：\n"
            f"• 查積分 → 私聊輸入「積分」\n"
            f"• 查回饋金 → 私聊輸入「回饋金」\n"
            f"• 進遊戲 → 私聊輸入「遊戲」\n\n"
            f"有任何植物問題，也歡迎在群裡問我 🌱",
            reply_markup=kb)


def main():
    if not BOT_TOKEN:
        print("缺少 TG_BOT_TOKEN"); return
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("points", cmd_points))
    app.add_handler(CommandHandler("checkin", do_checkin))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, on_new_member))
    # 群訊息（文字 + 照片）
    app.add_handler(MessageHandler(filters.ChatType.GROUPS & ~filters.COMMAND & (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.ANIMATION | filters.CAPTION | filters.VOICE), on_group_message))
    # 私聊
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.ANIMATION | filters.CAPTION | filters.CONTACT) & ~filters.COMMAND, on_message))
    app.add_handler(CommandHandler("help", cmd_start))
    from telegram.ext import CallbackQueryHandler
    app.add_handler(CallbackQueryHandler(on_callback))
    import datetime as _dt
    if app.job_queue:
        app.job_queue.run_repeating(poll_send_jobs, interval=SEND_POLL_SECONDS, first=10)
        log.info("發件隊列輪詢啟動：每 %ss 一次", SEND_POLL_SECONDS)
        app.job_queue.run_daily(daily_morning, time=_dt.time(hour=0, minute=30))
        log.info("每日早安排程 08:30 MYT，群ID=%s", GROUP_CHAT_ID or "(未設)")
    log.info("心田 Bot 啟動中… @XintianGardenBot")
    app.run_polling(allowed_updates=Update.ALL_TYPES)



# ===== 發件隊列（claim → start → Telegram 發送 → result）=====
SEND_POLL_SECONDS = int(os.environ.get("XINTIAN_SEND_POLL_SECONDS", "5"))

async def poll_send_jobs(context: ContextTypes.DEFAULT_TYPE):
    """每 5 秒領取一張待發送回覆；成功才發 TG，之後回報 result。"""
    if not BOT_KEY:
        return
    try:
        code, res = await api_post_full("/api/bot/send-jobs/claim", {})
        if code != 200 or not isinstance(res, dict) or not res.get("ok"):
            return
        job = res.get("job")
        if not job:
            return
        job_id = job.get("job_id") or ""
        lease_token = job.get("lease_token") or ""
        chat_id = job.get("chat_id")
        text = job.get("text") or ""
        reply_to = job.get("reply_to_message_id") or ""
        uid = job.get("tg_user_id") or ""
        dname = job.get("display_name") or ""
        if not job_id or not lease_token or chat_id is None or not text:
            log.warning("send-job 缺欄位: %s", job)
            return
        kind = (job.get("kind") or "reply").lower()
        # 群回覆：引用原提問 + tag 花友（讓群裡看得清是回給誰）
        # kind=honour（獲獎公告）→ 原樣發送，不加任何前綴
        is_group = str(chat_id).startswith("-")
        if kind != "honour" and is_group:
            who = f"@{dname} " if dname else ""
            text = f"🌿 {who}回覆你的問題：\n{text}"

        # 2) 取得發送許可（不可省略）
        code2, res2 = await api_post_full("/api/bot/send-jobs/start",
                                          {"job_id": job_id, "lease_token": lease_token})
        if code2 != 200 or not isinstance(res2, dict) or not res2.get("ok") or not res2.get("send_allowed"):
            log.info("send-job %s 未取得發送許可 (code=%s)", job_id, code2)
            return

        # 3) 發送到 Telegram（純文本）
        tg_msg_id = ""
        status = "sent"
        err = ""
        try:
            kw = {}
            if is_group and reply_to:
                try:
                    kw["reply_to_message_id"] = int(reply_to)
                    kw["allow_sending_without_reply"] = True
                except Exception:
                    kw.pop("reply_to_message_id", None)
            sent = await context.bot.send_message(chat_id=chat_id, text=text, **kw)
            tg_msg_id = str(sent.message_id)
        except Exception as e:
            status = "failed"
            err = str(e)[:300]
            log.warning("send-job %s TG 發送失敗: %s", job_id, e)

        # 4) 回報 result
        body = {
            "job_id": job_id,
            "lease_token": lease_token,
            "status": status,
            "telegram_message_id": tg_msg_id,
            "error": err,
        }
        code3, res3 = await api_post_full("/api/bot/send-jobs/result", body)
        if status == "sent" and (code3 != 200 or not (isinstance(res3, dict) and res3.get("ok"))):
            # TG 已送出但回報失敗 → 只重試同一份 result（不重發 TG）
            log.warning("send-job %s TG 已送出但回報失敗 (code=%s)，重試 result", job_id, code3)
            for _ in range(3):
                await asyncio.sleep(3)
                code3, res3 = await api_post_full("/api/bot/send-jobs/result", body)
                if code3 == 200 and isinstance(res3, dict) and res3.get("ok"):
                    break
        if status == "sent":
            log.info("send-job %s 已送達 chat=%s msg=%s", job_id, chat_id, tg_msg_id)
    except Exception as e:
        log.warning("poll_send_jobs: %s", e)

if __name__ == "__main__":
    main()
