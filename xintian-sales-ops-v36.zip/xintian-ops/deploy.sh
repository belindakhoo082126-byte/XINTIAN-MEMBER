#!/bin/bash
# 心田營運儀表板 — 部署腳本（在主機執行）
set -e
DIR=/opt/xintian/ops
mkdir -p $DIR
cd $DIR

echo "1. 建立 venv（若無）"
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q -r requirements.txt

echo "2. 建立 systemd 服務"
cat > /etc/systemd/system/xintian-ops.service << 'SVC'
[Unit]
Description=Xin Tian Ops Dashboard
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/xintian/ops
ExecStart=/opt/xintian/ops/venv/bin/python -m uvicorn backend.main:app --host 0.0.0.0 --port 10006
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVC

systemctl daemon-reload
systemctl enable xintian-ops
systemctl restart xintian-ops
sleep 3
systemctl status xintian-ops --no-pager | head -6
echo "✅ 完成。請到 Nginx 加 /ops/ 路徑。"
