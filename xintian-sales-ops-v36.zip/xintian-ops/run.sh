#!/bin/bash
cd "$(dirname "$0")"
exec python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 10006
